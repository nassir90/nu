<?php require("php/util.php")?>

<!DOCTYPE html>

<head>
	<title>Topikos e vol</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="../style.css">
</head>
<body>
	<header><h1>Topikos e vol</h1></header>
	<section>
	
	<center><p><em>"Te kanob spikön dö ut kel labob plak ona. Votiko, no sinifons vöds obik bosi"</em></p></center>
	
	<p>Dabinons dils lifa kels laboy plaki onas. Onis kolkömoy nomädiko. Fidoy, slipoy, yurinoy, as sams. Dins at binons materöfiks, e nek kanon kodön das suemol onis ma veg difik.</p>
	
	<p>I dabinons dils lifa kels no laboy plaki onas. Ni logoy dinis at me logs okik, ni liloy onis me liläms okik: kredob das suemol uti keli cedob. If viloy suemön dinis at, mutoy sukön numi in vüresod, in bukabums u in gaseds. Ven no laboy plaki dina, no kanoy konfidön tikamagotis keli emekoy dü lif okik. If spikoy dö dins somik, nen sukam, ceds ols binons vemo nefrutik!</p>
	
	<p>Säkäd binon das pösods soga nulädik kredons das binons dils volanefa! Ob mutob sagön das grups no binons dämiks. Ün vönäd, ed ün timül at in tops vönaoloveik, pösods tikons das binons dils grupa <b>topik</b>. Dif gretik dabinons demü volaceds tel is. If tikoy das binoy dil grup topik, kanoy konfidön tikamagotis okik. Defs nefa binonsöv dämik pro ol. No jäfäloyöv utis kel no labons demäd. Too, if tikoy das binoy dil grupa <b>vola</b>, logoy säkädis.</p>
	
	<p>In sog somik, liloy kleiliko noidi täläkta dobiko pepladöl. Klüliko, dabinons ai pösods laodiälik, ab no kanoy noön das in sog nulädik, vögs täläkta somik binons mödikums mö gretos. Ad obi suemön, vegolös lü el 'Instagram' ud el 'Twitter'. Ologoy nunis se vol lölik - de dins jeikiks kel jenons aldelo. Mögos das otikolöv das volanef padolon! Ab atos binon luspet. Ogevegolöv lü lif nomädik olik, e nos ucenon. Jenots at no kanons ceinön oli, e no kanol ceinön jenotis at tö cem olik. Sog elienetikon.</p>
	
	<p>I, jinos obe das volaced at emekon stüli tatas keli logoy in vol adelo. Ven no tikoy das te topikos binon veütik pro ol, primoy tikön das foginans kanons reigön oli. If tikamagot de tat nedabinotik binon veütikum ka topikos e topikans, kis kodonöv das primoy reigön topikosi okik? Nos.</p>
	</section>
	
	<section>
	<?php print(file_to_table("template/outthere/message-vol-vocab.txt"))?>
	</section>
	
	<footer><a href="../index.html">Home</a></footer>
</body>
