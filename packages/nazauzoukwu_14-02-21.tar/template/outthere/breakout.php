<!DOCTYPE html>

<head>
	<title>Break out</title>
	<link rel="stylesheet" href="../simple.css">
	<meta charset="utf-8">
	
	<!--
		Thesis: By focusing all your effort into one area of life, you delude yourself into thinking that that is the only worthwhile activity, and deprive yourself of other sources of fulfillment or contentment. It's for this reason that having multiple side hobies is a good idea.
		Supporting points to be presented: You'll never know whether or not you'll enjoy something until you've tried it. The more you learn, the more the world makes sense - the feeling of becoming more intellegent is satisfying.
		Opposing points to be dealt with: I'm already happy. I am philosophically opposed to the idea of self improvement.
		Conclusion to be reasoned towards: Learn to cook, read latin or exposes
	!-->
	
</head>

<body>
	<h1>Break out <small>(or go deeper, depending on who you ask)</small></h1> 
	
	<center><p><em>"Jack of all trades, master of none, but <b>better</b> than master of one"</em></p></center>
	
	<p>By putting all of your focus into a minute area of life, you delude yourself into thinking that it's the only worthwhile activity and deprive yourself of other sources of contentment. It's for this reason that I've prefaced my argument with the old proverb that you see above. I think that it's true.</p>
	
	<p>There are so many "sources of information" in the world to keep you learning for long time. Even in specific domains, it's likely that you'll find a plethora of styles, techniques and schools of thought. With each new branch learned, the domain begins to make more sense. In fact, there are domains in which the information you learn is inferrential, so your knowledge on the subject can seep into other parts of life.</p>
	
	<p>Perhaps your domain is programming. Hell, perhaps you're obsessed with <b>just one</b> programming language. In this case, a path is already set up for you. For a programmer as such, the next logical step is to learn another programming language! As you learn more languages and tools, you'll reach a point where you're not just a programmer but a system administrator. As you go up the domain, things that were seemingly unrelated to the branch you began with may seem attractive. Maybe you'll move from windows to linux. Maybe linux will make you adopt a more minimalist philopophy. Maybe you'll start a garden. The point is: expanding your skills an abilities can take you places. That's  a fact</p>
	
	<p>The act of learning and expanding in this way is addictive, as I've implied. Education propagates itself, there's a reason why they say that the culmination of knowledge is knowing that you know nothing. The more you learn, the more questions you'll want to ask and the more areas of life that you'll want to expand to.</p>
	
	<p>The best thing about going on this path it's not even that hard. As a rule of thumb: remove, don't add. Spend less time in that one area of life. You might realise that you're sleep deprived, and that no change can occur when you're in such a state. After sleeping, you may have the energy to start doing something else. It's that easy.</p>
	
	<p>Maybe your still not sold. Perhaps you're already happy. In that case ignore this article. If the benefits don't seem worth sacrificing the domain you specialise in, by all means stay put. The door is always open. In fact, maybe you're philosophically opposed to any form of self improvement. At one point I'll write an article for you lot, but untill then, adios.</p>
	
	<p><small>(P.S. don't read self help books. Or more articles like this one. Get in quick and get out. There's a book called "Help Me!" that talks about a woman that fell into this trap)</small></p>
	
	<hr>
	
	<a href="index.html">Home</a>
</body>
