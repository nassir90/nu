<!DOCTYPE html>
<head>
	<link rel="stylesheet" href="../simple.css">
	<title>Mode of spread of the spanish flu</title>
</head>
<body>
	<h1>Mode of spread of the spanish flu</h1>
	
	<h2>Summary of the Experiment in Public Health Report</h2>
	
	<p>Perhaps the most interesting epidemiological studies conducted during the 1918-1919 pandemic were the human experiments conducted by the Public Health Service and the U.S. Navy under the supervision of Milton Rosenau on Gallops Island, the quarantine station in Boston Harbor, and on Angel Island, its counterpart in San Francisco</p>

	<p>The experiment began with 100 volunteers from the Navy who had no history of influenza. Rosenau was the first to report on the experiments conducted at Gallops Island in November and December 1918. His first volunteers received first one strain and then several strains of Pfeiffer bacillus by spray and swab into their noses and throats and then into their eyes.</p>

	<p>When that procedure failed to produce disease, others were inoculated with mixtures of other organisms isolated from the throats and noses of influenza patients. Next, some volunteers received injections of blood from influenza patients.</p>

	<p>Finally, 13 of the volunteers were taken into an influenza ward and exposed to 10 influenza patients each. Each volunteer was to shake hands with each patient, to talk with him at close range, and to permit him to cough directly into his face.</p>

	<p>None of the volunteers in these experiments developed influenza. Rosenau was clearly puzzled, and he cautioned against drawing conclusions from negative results.</p>

	<p>He ended his article in JAMA with a telling acknowledgement: “We entered the outbreak with a notion that we knew the cause of the disease, and were quite sure we knew how it was transmitted from person to person. Perhaps, if we have learned anything, it is that we are not quite sure what we know about the disease.</p>

	<p>The research conducted at Angel Island and that continued in early 1919 in Boston broadened this research by inoculating with the Mathers streptococcus and by including a search for filter-passing agents, but it produced similar negative results. It seemed that what was acknowledged to be one of the most contagious of communicable diseases could not be transferred under experimental conditions.</p>

	<p>Some Interesting Though Unsuccessful Attempts To Transmit Influenza Experimentally.
	How great are the difficulties surrounding the study of the nature of the virus of influenza is indicated by the following summary of two series of experiments recently carried out, one at Boston and one at San Francisco.</p>

	<h2>BOSTON EXPERIMENTS</h2>
	<p>These experiments were carried on jointly by Lieut. Commander M. J. Rosenau, Medical Corps, U. S. N. R. F., and Lieut. W. J. Keegan, Medical Corps, U. S. N. R. F. and by Surg. Joseph Goldberger and Asst. Surg. G. C. Lake, United States Public Health Service, at the United States Quarantine Station, Gallop’s Island, Boston, Mass.</p>

	<p>The subjects of experiment were 68 volunteers from the United States Naval Detention Training Camp, Door Island, Boston. These volunteers had been exposed in some degree to an epidemic of influenza at the training camp or at some station prior to coming to Door Island; 47 of the men wore without history of an attack of influenza during the recent epidemic and 39 of those were without history of an attack of such illness at any time during their lives.</p>

	<p>The experiments consisted of inoculations with pure cultures of Pfeiffer’s bacidus, with secretions from the upper respiratory passagos, and with blood from typical cases of influenza.</p>

	<p>The study was begun on November 13 with an experiment in which a suspension of a freshly isolated culture of Pfeiffer’s bacillus was instilled into the nose of each of 3 nonimmunes and into 3 controls who had a history of an attack in the present epidemic.</p>

	<p>None of these volunteers showed any reaction following this inoculation. Another experiment was made at a later date with a suspension of a number of different pure cultures of Pfeiffer’s bacillus, of which 4 were recently isolated. Ten presumably nonimmune volunteers wore inoculated, with the same negative results.</p>

	<p>Three sets of experiments were made with secretions, both unfiltered and filtered, from the upper respiratory tract of typical cases of influenza in the active stage of the disease. In these experiments a total of 30 men were subjected to inoculation by means of spray, swab, or both, of the nose and throat.</p>

	<p>The interval elapsing between securing secretions from the donors and inoculation of the volunteers was progressively reduced in these experiments so that in the third of the series the interval at most was 30 seconds. In no instance was an attack of influenza produced in any one of the subjects.</p>

	<p>An experiment was made in which the members of one of the groups of volunteers which had been subjected to inoculation with secretions were exposed to a group of cases of influenza in the active stage of the disease in a manner intended to simulate conditions which in nature are supposed to favor the transmission of the disease.</p>

	<p>Each of this group of 10 volunteers came into close association for a few minutes with each of 10 selected cases of influenza in the wards of the Chelsea Naval Hospital.</p>

	<p>At the time the volunteers were exposed to this infection the cases were from 10 to 84 hours from the onset of their illness and 4 of them were not over 24 hours after the onset. Each volunteer conversed a few minutes with each of the selected patients, who were requested to, and coughed into the face of each volunteer in turn, so that each volunteer was exposed in this manner to all 10 cases.</p>

	<p>The total exposure amounted to about three-quarters of an hour for each volunteer. None of those volunteers developed any symptoms of influenza following this experiment.</p>

	<p>Advantage was taken of the opportunity for making this study to attempt to confirm the reported positive results of transmission of influenza by Nicolle. Secretions from 5 typical cases of influenza were secured, filtered, and some of the filtrate was inoculated subcutaneously into each of the group of 10 volunteers.</p>

	<p>At the same time blood was drawn from the same cases and pooled, and some of the mixed blood injected subcutaneously into each of another group of 10 volunteers. The time lost between drawing the blood and inoculating it in no case exceeded three-quarters of an hour. None of the men subjected to these inoculations developed any evidences of illness.</p>

	<p>In the foregoing experiments the patients serving as donors belonged to groups from epidemic foci either on shipboard or at institutions. The great majority indeed belonged in a group from an epidemic on board the U. S. S. Yacona. Of the personnel of this vessel, 95 in number, 80, or 84 percent, were stricken with the disease in an epidemic between November 17 and 29.</p>

	<h2>SAN FRANCISCO EXPERIMENTS</h2>
	<p>The following observations were carried out practically simultaneously with those described above. The work was done at the Angel Island Quarantine Station, San Francisco, Cal., utilizing volunteers from the Yerba Buena Naval Training Station, San Francisco.</p>

	<p>The experiments were carried on jointly by Surg. G. W. McCoy, of the United States Public Health Service, and Lieut. De Wayne Richey, United States Navy.</p>

	<p>The volunteers who were used in these experiments differed from those used at Boston in two respects—first, the personnel of the Yerba Buena Station had not been exposed to influenza in the present epidemic and were therefore presumed not to possess any special natural immunity; second, all of the men had been vaccinated with large doses of a bacterial vaccine containing Pfeiffer’s bacilli, the three fixed types of pneumococci and hæmolytic streptococci.</p>

	<p>We are not prepared at present to state what influence this vaccination may have had in promoting resistance to influenza infection, but if we may judge by the results of controlled experiments elsewhere such vaccination may for the present purpose be ignored.</p>

	<p>Editorial Note.—The foregoing experiments, though extremely interesting, do not, of course, warrant final conclusions. It is hoped that it may be possible to carry the studies further and that results may be obtained that will definitely settle the nature and the modo of spread of the virus of epidemic influenza.</p>

	<p>For the present the sanitarian will do well to continue to apply the general principles of control that are based on the justifiable assumption that the disease is a droplet infection, giving, however, increased attention to a point that is suggested by these experiments—namely, an infective period at the very earliest stages of the attack.</p>

	<p>It would seem to be wise to give renewed emphasis to the importance of going to bed at the slightest indications of illness.</p>
	
	<h2>Sources</h2>
	
	<p>Abstract of the AMA Article, 1919
	1377. Experiments to Determine the Mode of Spread of Influenza. Milton J. Rosenau. J.
	Am. M. Assn., Chicago, 1919, 73, 311.</p>

	<p>Experiments to determine the mode of spread of influenza were carried out on Gallops Island. One hundred volunteers were mostly between 18 and 25 years, while a few were about 30. Pure cultures of Pfeiffer’s bacillus were administered to some of the volunteers but failed to produce the disease.</p>

	<p>Large quantities of a mixture of 13 strains of the Pfeiffer bacillus were suspended and the suspension sprayed into the nose, eyes and throat of 19 volunteers. This experiment was also negative. Next 1 cc. of the mucous discharges of patienta was sprayed into the nostrils, throat and eyes, also without producing disease.</p>

	<p>The blood from patients suffering from influenza was injected in 10 cc. quantities into each of 10 volunteers without producing disease. Ten volunteers were then brought into close contact with 10 patients and though the patients breathed and coughed into the faces of the volunteers no disease appeared.</p>

	<p>Similar experiments were conducted at Portsmouth with the result that half of the volunteers came down with fever and sore throat caused by hemolytic streptococci. The author concludes that we are still ignorant of the true mode of spread of influenza. -P. G. H.</p>

	<hr>
	<p>Note: I'm aware that the <b>SCIENTIFIC CONSENSUS</b> now purports that the spanish flu was caused by a virus, however, this only means, for the germ theorist, that the experiments involving Pfeiffer bacillus itself should be disregarded. The experiments involving sick and diseased individuals are worth considering.</p>
	
	<a href="sales.html">Back to draft</a>
</body>
