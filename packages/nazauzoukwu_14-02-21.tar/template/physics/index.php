<!DOCTYPE html>
<head>
	<link rel="stylesheet" href="../style.css">
	<title>Physics</title>
	
</head>

<body>
	<header><h1>Physics</h1></header>
	<section>
		<h2>Simulations</h2>
		<ul>
			<li><a href="drop.html">Dropping a mass at different heights</a></li>
			<li><a href="convex.html">Finding the properties of a convex lens</a></li>
			<li><a href="induction.html">Electromagnetic induction</a></li>
		</ul>
	</section>
	<footer>
		<ul>
			<li><a href="index.html">Home</a></li>
			<li><a href="http://mathsphysics.com/">Visit my guy Mr Foley</a>
		</ul>
	</footer>
</body>
