<!DOCTYPE html>

<head>
	<link rel="stylesheet" href="../simple.css">
	<title>J. J. Thomson project</title>
	
	<style>
		img {
			float: right;
			margin: 10px;
			right: 0;
		}
	</style>
</head>

<body>
	<?php require("php/util.php"); echo markdown_to_html("template/chemistry/project.md");?>
</body>
