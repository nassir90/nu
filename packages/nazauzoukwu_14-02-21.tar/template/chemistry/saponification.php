<!DOCTYPE html>

<head>
	<link rel="stylesheet" href="../simple.css">
	<title>Saponification</title>
</head>

<body>
	<h1>Saponification</h1>
	
	<section style="float: right;"><canvas><?php readfile("php/peasant.txt");?></canvas></section>
	
	<h2>Instructions</h2>
	<ol>
		<li>Put the ethanol, the glycryl tristearate, the sodium hydroxide and the anti-bumping pellets in the test tube.</li>
	</ol>
	
	<hr>
	
	<p><a href="index.html">Back to index</a></p>
	<p><a href="https://amrita.olabs.edu.in/?sub=73&brch=3&sim=119&cnt=4">Better version</a> - Kinda uninspiring to see for a prospective programmer. Indians probably have quantum computers already, they just have to finish the youtube tutorials before they tell us.</p>
</body>
