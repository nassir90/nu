<?php require("php/util.php") ?>

<!DOCTYPE html>

<head>
	<title>Acids and bases</title>
	<link rel="stylesheet" href="../../style.css">
</head>

<body>
	<header><h1>Acids and bases</h1></header>
	
	<section>
	<?php print(file_to_table("template/notes/chemistry/acidsandbases.txt")); ?>
	</section>
	
	<footer><a href="../../index.html">Home</a></footer>
</body>
