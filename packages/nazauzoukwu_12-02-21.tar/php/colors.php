<?php
$dark = "hsl(100, 10%, 5%)";
$base = "hsl(100, 10%, 40%)";
$light = "hsl(100, 10%, 60%)";
?>
