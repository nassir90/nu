<!DOCTYPE html>

<head>
	<link rel="stylesheet" href="../style.css">
	<title>Projectiles on an inclined plane</title>
</head>

<body>
	<header><h1>Applied maths index</h1></header>
	
	<section>
	
	<h2>Javascript Simulations</h2>
	<ul>
		<li><a href="./inclinedplane.html">Projectiles on an inclined plane</a></li>
	</ul>
	
	<h2>Native Simulations</h2>
	<ul>
		<li><a href="./connectedparticles.html">Connected particle simulations</a></li>
	</ul>
		
	</section>
	
	<footer><a href="../index.html">Back home</a></footer>
	
</body>
