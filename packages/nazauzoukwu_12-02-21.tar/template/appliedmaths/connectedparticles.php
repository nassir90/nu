<!DOCTYPE html>

<head>
	<title>Connected Particles</title>
	<link rel="stylesheet" href="../simple.css">
	
	<style>
		img {
			margin: 20px;
		}
	</style>
</head>

<body>
	<?php require("php/util.php"); echo markdown_to_html("template/appliedmaths/connectedparticles.md");?>
	<hr>
	
	<a href="index.html">Go back to index</a>
</body>
