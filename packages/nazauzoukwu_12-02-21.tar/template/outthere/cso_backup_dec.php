<!DOCTYPE html>
<!-- saved from url=(0086)https://www.cso.ie/en/releasesandpublications/br/b-cdc/covid-19deathsandcasesseries18/ -->
<html xmlns="https://www.w3.org/1999/xhtml" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<!--scale the layout to work correctly on moble decives-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<!--define the character encoding for the page-->
		
          <!-- navigation object :  Last modified --><meta property="article:published_time" name="DC.Keywords" content="2020-12-18"> <!-- modified -->
         
		<title>COVID-19 Deaths and Cases, Series 18 - CSO - Central Statistics Office</title>
          <!-- navigation object :  Key words --><meta name="DC.Keywords" content=""> <!-- Keywords -->
          <!-- navigation object :  Last modified --><meta property="article:published_time" name="DC.Keywords" content="2020-12-18"> <!-- modified -->
          <meta name="DC.Publisher" content="CSO"> <!-- modified -->
          <!-- start css -->
          <!-- IE compatibility mode fix--><meta http-equiv="X-UA-Compatible" content="IE=edge">

        <!--main.css--><link rel="stylesheet" type="text/css" media="" href="./cso_backup_dec_files/main.css">
        <!--earthworm.css--><link rel="stylesheet" type="text/css" media="" href="./cso_backup_dec_files/earthworm.css">
        <!--layout.css--><link rel="stylesheet" type="text/css" media="" href="./cso_backup_dec_files/layout.css">
        <!--colours.css--><link rel="stylesheet" type="text/css" media="" href="./cso_backup_dec_files/colours.css">
        
        <!--jquery.fancybox.css--><link href="./cso_backup_dec_files/jquery.fancybox.css" rel="stylesheet">
        <!--mediaQueries.css--><link rel="stylesheet" type="text/css" media="" href="./cso_backup_dec_files/mediaQueries.css">
		
        <!--include jQuery-->
		<!--jquery-1.11.1.min.js--><script async="" src="./cso_backup_dec_files/analytics.js"></script><script type="text/javascript" src="./cso_backup_dec_files/jquery-1.11.1.min.js"></script><script data-dapp-detection="">!function(){let e=!1;function n(){if(!e){const n=document.createElement("meta");n.name="dapp-detected",document.head.appendChild(n),e=!0}}if(window.hasOwnProperty("ethereum")){if(window.__disableDappDetectionInsertion=!0,void 0===window.ethereum)return;n()}else{var t=window.ethereum;Object.defineProperty(window,"ethereum",{configurable:!0,enumerable:!1,set:function(e){window.__disableDappDetectionInsertion||n(),t=e},get:function(){if(!window.__disableDappDetectionInsertion){const e=arguments.callee;e&&e.caller&&e.caller.toString&&-1!==e.caller.toString().indexOf("getOwnPropertyNames")||n()}return t}})}}();</script>
		<script type="text/javascript" src="./cso_backup_dec_files/jsapi"></script>
        
        <!--include Flexslider - used for carousels and image slders-->
		<!--jquery.flexslider-min.js--><script type="text/javascript" src="./cso_backup_dec_files/jquery.flexslider.js"></script>
          
		<!--include Fancybox - used for modal windows-->
		<!--jquery.fancybox.js--><script src="./cso_backup_dec_files/jquery.fancybox.min.js"></script>
          <!--flexslider.css<link rel="stylesheet" type="text/css" media="" href="/en/media/styleassets/css/granite/flexslider.css" />-->
          
          
          
          
          <!--include High Charts-->
		<script type="text/javascript" src="./cso_backup_dec_files/highcharts.js"></script>
<script type="text/javascript" src="./cso_backup_dec_files/map.js"></script>
<script type="text/javascript" src="./cso_backup_dec_files/highmaps.js"></script>
<script type="text/javascript" src="./cso_backup_dec_files/data.js"></script>
<script type="text/javascript" src="./cso_backup_dec_files/highcharts-more.js"></script>
<script type="text/javascript" src="./cso_backup_dec_files/exporting.js"></script>
          
          <script src="./cso_backup_dec_files/loadingoverlay.min.js"></script>
<script src="./cso_backup_dec_files/loadingoverlay_progress.min.js"></script>

          <script src="./cso_backup_dec_files/jquery.dataTables.min.js"></script>
    <script src="./cso_backup_dec_files/dataTables.buttons.min.js"></script>
    <script src="./cso_backup_dec_files/buttons.flash.min.js"></script>
    <script src="./cso_backup_dec_files/jszip.min.js"></script>
    <script src="./cso_backup_dec_files/pdfmake.min.js"></script>
    <script src="./cso_backup_dec_files/vfs_fonts.js"></script>
    <script src="./cso_backup_dec_files/buttons.html5.min.js"></script>
    <script src="./cso_backup_dec_files/buttons.print.min.js"></script>

    <link rel="stylesheet" href="./cso_backup_dec_files/jquery.dataTables.min.css">

    <link rel="stylesheet" href="./cso_backup_dec_files/buttons.dataTables.min.css">

          
          
          
          <!--JQUERY UI-->
          <script src="./cso_backup_dec_files/jquery-ui.js"></script>
          <link rel="stylesheet" href="./cso_backup_dec_files/jquery-ui.css">
            
            <!--JSON Stat-->
            
            <script type="text/javascript" src="./cso_backup_dec_files/json-stat.js"></script>
          
          
          
          

          <!--include sitewide JavaScript for cso.ie-->
		<!--site.js--><script type="text/javascript" src="./cso_backup_dec_files/site.js"></script>
         <!-- end css --> 
            <!--START HIGHSLIDES-->  
                     
               <script type="text/javascript" src="./cso_backup_dec_files/highslide-full.js"></script><!--highslide full-->
                  <!--<script type="text/javascript" src="/en/media/styleassets/mip/mobile.js"></script>mobile highslides-->
                  <link rel="stylesheet" type="text/css" media="" href="./cso_backup_dec_files/highslide.css"><!--highslide.css-->
                  
           <script type="text/javascript">
             //hs.graphicsDir = '/images/highslide/graphics/';
             
            hs.graphicsDir = 'https://cdn.cso.ie/static/img/highslide/'
    hs.outlineType = 'rounded-white';
            hs.align = 'center';
             hs.showCredits = false;
             
</script>
                  
                    
                <!--END HIGHSLIDES--> 
           <!-- Excel styles -->

		          
          
          
           <style type="text/css">
.b1{white-space-collapsing:preserve;}
.excel-262843-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262843-media-r1{height:15.0pt;}
.excel-262843-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262843-media-c2{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262843-media-c3{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262843-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262843-media-c5{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262843-media-c6{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262843-media-c7{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262843-media-c8{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262843-media-c9{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262843-media-c10{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262842-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262842-media-r1{height:15.0pt;}
.excel-262842-media-r2{height:27.0pt;}
.excel-262842-media-r3{height:31.5pt;}
.excel-262842-media-r4{height:27.75pt;}
.excel-262842-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c2{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c3{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c6{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c7{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c8{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c9{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c10{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262842-media-c11{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262835-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262835-media-r1{height:15.0pt;}
.excel-262835-media-r2{height:25.5pt;}
.excel-262835-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c2{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c3{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c4{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c5{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c6{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c7{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c8{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c9{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262835-media-c10{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c11{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; font-family:arial;font-size:10pt; }
.excel-262835-media-c12{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: #FF0000; font-family:arial;font-size:10pt; }
.excel-262835-media-c13{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: #FF0000; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262835-media-c14{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262835-media-c15{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c16{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262835-media-c17{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262835-media-c18{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: #FF0000; font-family:arial;font-size:10pt; }
.excel-262835-media-c19{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: #FF0000; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262835-media-c20{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c21{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262835-media-c22{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c23{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262835-media-c24{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262832-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262832-media-r1{height:15.0pt;}
.excel-262832-media-r2{height:42.0pt;}
.excel-262832-media-r3{height:30.0pt;}
.excel-262832-media-r4{height:28.5pt;}
.excel-262832-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c2{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c3{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c6{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c7{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262832-media-c8{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c9{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: #FF0000; font-family:arial;font-size:10pt; }
.excel-262832-media-c10{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c11{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262832-media-c12{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c13{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262832-media-c14{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: #FF0000; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262832-media-c15{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262832-media-c16{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c17{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c18{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262832-media-c19{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c20{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262832-media-c21{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262837-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262837-media-r1{height:15.0pt;}
.excel-262837-media-r2{height:30.0pt;}
.excel-262837-media-r3{height:18.0pt;}
.excel-262837-media-r4{height:30.75pt;}
.excel-262837-media-r5{height:37.5pt;}
.excel-262837-media-r6{height:28.5pt;}
.excel-262837-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c2{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c3{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c6{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c7{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262837-media-c8{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: #FF0000; font-family:arial;font-size:10pt; }
.excel-262837-media-c9{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: #FF0000; font-family:arial;font-size:10pt; }
.excel-262837-media-c10{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c11{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262837-media-c12{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c13{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262837-media-c14{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c15{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c16{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262837-media-c17{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c18{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c19{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262837-media-c20{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262837-media-c21{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262841-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262841-media-r1{height:15.0pt;}
.excel-262841-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c2{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c3{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c6{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c7{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c8{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262841-media-c9{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262824-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262824-media-r1{height:15.0pt;}
.excel-262824-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c2{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c3{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c6{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262824-media-c7{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c8{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262824-media-c9{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c10{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262824-media-c11{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: #FF0000; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262824-media-c12{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c13{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262824-media-c14{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262824-media-c15{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262824-media-c16{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262825-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262825-media-r1{height:15.0pt;}
.excel-262825-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c2{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c3{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c6{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c7{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262825-media-c8{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c9{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c10{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262825-media-c11{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: #FF0000; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262825-media-c12{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: #FF0000; font-family:arial;font-size:10pt; }
.excel-262825-media-c13{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c14{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c15{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c16{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262825-media-c17{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262825-media-c18{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; font-style: italic; }

.b1{white-space-collapsing:preserve;}
.excel-262828-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262828-media-r1{height:15.0pt;}
.excel-262828-media-r2{height:27.0pt;}
.excel-262828-media-r3{height:30.0pt;}
.excel-262828-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c2{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c3{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c6{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c7{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c8{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c9{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262828-media-c10{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }

.b1{white-space-collapsing:preserve;}
.excel-262836-media-t1{border-collapse:collapse;border-spacing:0;}
.excel-262836-media-r1{height:15.0pt;}
.excel-262836-media-r2{height:52.5pt;}
.excel-262836-media-c1{white-space: pre-wrap; text-align: left; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c2{white-space: pre-wrap; text-align: center; vertical-align: bottom; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c3{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; font-style: italic; }
.excel-262836-media-c4{white-space: pre-wrap; text-align: right; vertical-align: bottom; border-top: thin solid black; border-bottom: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c5{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c6{white-space: pre-wrap; text-align: right; vertical-align: bottom; font-weight: bold; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c7{white-space: pre-wrap; text-align: left; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c8{white-space: pre-wrap; text-align: right; vertical-align: bottom; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c9{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-bottom: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c10{white-space: pre-wrap; text-align: left; vertical-align: bottom; border-top: thin solid black; color: black; font-family:arial;font-size:10pt; }
.excel-262836-media-c11{white-space: pre-wrap; text-align: left; vertical-align: top; color: black; font-family:arial;font-size:10pt; }


             
             
             
</style>
           
<script> 
//js to set current tab to active on main nav DR

    $(document).ready(function () {


        var theme = 'Releases and Publications';

  //alert(theme);

        if (theme.length == '0') {
            $("#homeTab").addClass("currentbranch0");
            // alert('I am here');
        }

        else if (theme == 'Statistics' || theme == 'Releases and Publications') {

            $("#statisticsTab").addClass("currentbranch0");

        }

        else if (theme == 'Databases') {

            $("#databasesTab").addClass("currentbranch0");

        }


        else if (theme == 'Surveys and Methodology') {

            $("#methodsTab").addClass("currentbranch0");

        }

        else if (theme == 'About Us') {

            $("#aboutUsTab").addClass("currentbranch0");

        }


        else {
            //do nothing
        }


    });

    //end main nav JS DR
</script>

      <!-- start header --> 

		<!-- ********** HEADER ********** -->
		<!-- navigation object : Header code --><style type="text/css">.highslide img {cursor: url(https://cdn.cso.ie/static/img/highslide/zoomin.cur), pointer !important;}.highslide-viewport-size {position: fixed; width: 100%; height: 100%; left: 0; top: 0}</style><style></style></head><body style="zoom: 1;"><div class="cc-revoke cc-bottom cc-animate cc-color-override--77885362" style="display: none;">Cookie Policy</div><div role="dialog" aria-live="polite" aria-label="cookieconsent" aria-describedby="cookieconsent:desc" class="cc-window cc-banner cc-type-opt-in cc-theme-block cc-bottom cc-color-override--77885362 " style=""><!--googleoff: all--><span id="cookieconsent:desc" class="cc-message"><h2 style="margin-bottom: 10px">Cookies</h2><span>This website uses cookies to improve your experience and to monitor the site traffic. These cookies are automatically rejected and you can choose to accept them by clicking on the 'Accept' button. To find out more about how we use cookies see our <a href="https://www.cso.ie/en/aboutus/lgdp/dataprotectionprivacytransparency/websiteprivacystatement/index.html" target="_blank" style="color: #ffffff">Privacy Statement</a>. and </span> <a aria-label="learn more about cookies" role="button" tabindex="0" class="cc-link" href="https://www.cso.ie/en/releasesandpublications/br/b-cdc/covid-19deathsandcasesseries18/#" rel="noopener noreferrer nofollow" target="_blank"><span style="font-size: 20px;font-weight: bold">Manage Cookies</span></a></span><div class="cc-compliance cc-highlight"><a aria-label="deny cookies" role="button" tabindex="0" class="cc-btn cc-deny"><span style="display: none">Reject</span></a><a aria-label="allow cookies" role="button" tabindex="0" class="cc-btn cc-allow"><span style="padding: 20px;font-size: 18px;">Accept</span></a></div><!--googleon: all--></div><a href="https://www.cso.ie/en/releasesandpublications/br/b-cdc/covid-19deathsandcasesseries18/#" class="back-to-top" style="display: inline;">Back to Top</a><a name="d.en.88568"></a>
<!--start Code only (admin)-->
<!--test 3-->
<link rel="icon" type="image/png" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-57x57.png">

<link rel="apple-touch-icon" type="image/png" sizes="57x57" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" type="image/png" sizes="60x60" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" type="image/png" sizes="72x72" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" type="image/png" sizes="76x76" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" type="image/png" sizes="114x114" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" type="image/png" sizes="120x120" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" type="image/png" sizes="144x144" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" type="image/png" sizes="152x152" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" type="image/png" sizes="180x180" href="https://cdn.cso.ie/client/1.0.2/favicon/apple-icon-180x180.png">

<link rel="icon" type="image/png" sizes="192x192" href="https://cdn.cso.ie/client/1.0.2/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://cdn.cso.ie/client/1.0.2/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="https://cdn.cso.ie/client/1.0.2/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://cdn.cso.ie/client/1.0.2/favicon/favicon-16x16.png">

<link rel="manifest" href="https://www.cso.ie/favicons/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/favicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    
</script>

<!-- Begin Cookie Consent plugin by Silktide - https://cookieconsent.insites.com/ -->
<link rel="stylesheet" type="text/css" href="./cso_backup_dec_files/cookieconsent.min.css">
<script src="./cso_backup_dec_files/cookieconsent.min.js"></script>
<style>
.cc-message a:visited {
     color: rgb(255, 255, 255)
}
</style>
<script>

window.addEventListener("load", function () {
  window.cookieconsent.initialise({
    "palette": {
      "popup": {
        "background": "#35456B",
        "text": "#ffffff"
      },
      "button": {
        "background": "#FBAA34",
        "text": "#ffffff"
      }
    },
    position: "bottom",
    "static": false,
    "type": "opt-in",
    "revokable": false,
    "content": {
      "message": "<h2 style='margin-bottom: 10px'>Cookies</h2><span>This website uses cookies to improve your experience and to monitor the site traffic. These cookies are automatically rejected and you can choose to accept them by clicking on the 'Accept' button. To find out more about how we use cookies see our <a href='https://www.cso.ie/en/aboutus/lgdp/dataprotectionprivacytransparency/websiteprivacystatement/index.html' target='_blank' style='color: #ffffff'>Privacy Statement</a>. and </span>",
      "allow": "<span style='padding: 20px;font-size: 18px;'>Accept</span>",
      "deny": "<span style='display: none'>Reject</span>",
      "link": "<span style='font-size: 20px;font-weight: bold'>Manage Cookies</span>",
      "href": "#",
       "policy":  "Cookie Policy"
    },
    "onInitialise": function (e) {
      if (e == "allow") {
        window['ga-disable-UA-4963963-4'] = false;
      } else {
        window['ga-disable-UA-4963963-4'] = true;
      }

      ga('create', 'UA-4963963-4', 'auto');
      ga('set', 'anonymizeIp', true);
      ga('send', 'pageview');
    },
    "onStatusChange": function (e, t) {
      if (e == "allow") {
        window['ga-disable-UA-4963963-4'] = false;
        window.location.href = window.location.pathname;
        $("#cookie-consent-status-toggle").prop("checked", true)
      } else {
        $("#cookie-consent-status-toggle").prop("checked", false)
        window.location.href = window.location.pathname;

      }



      window['ga-disable-UA-4963963-4'] = true;
    }
  });
  $(".cc-link").click(function (e) {
    e.preventDefault()
    setCookie("cookieconsent_status", "deny", 365);
    window.location.href = "/en/aboutus/lgdp/dataprotectionprivacytransparency/websiteprivacystatement/index.html#cookie-toggle-anchor"
  });

  function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }



  ga('create', 'UA-4963963-4', 'auto');
  ga('set', 'anonymizeIp', true);
  ga('send', 'pageview');
});






</script>
<!-- End Cookie Consent plugin -->



          

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K6398KM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->








<a href="https://www.cso.ie/en/releasesandpublications/br/b-cdc/covid-19deathsandcasesseries18/#" class="back-to-top" style="display: inline;">Back to Top</a> 


<a id="top"></a> 

<div class="container header">
<div class="row">
<div class="col span12">
<h1><a href="https://www.cso.ie/en/"><img src="./cso_backup_dec_files/CSO_Logo_.png" alt="Central Statistics Office"></a></h1>

<div id="headerSocial">

<a class="btn blue" href="https://www.cso.ie/en/baile/" title="Gaeilge">Gaeilge</a>


<div class="headerSocial">

<ul>
            <li class="youtube">
               <a href="https://www.youtube.com/user/CSOIrelandMedia" title="Follow us on YouTube" target="_blank"><i class="fa fa-youtube-play fa-2x"></i></a>
            </li>
            <li class="twitter">
               <a href="https://twitter.com/csoIreland" title="Follow us on Twitter" target="_blank"><i class="fa fa-twitter fa-2x"></i></a>
            </li>
            <li class="facebook">
               <a href="https://www.facebook.com/CSOIreland" title="Like us on Facebook" target="_blank"><i class="fa fa-facebook-official fa-2x"></i></a>
            </li>
            <li class="rss">
               <a href="https://www.cso.ie/rss/en/latestreleasesandpublications/index.xml" title="Subscribe to RSS feeds" target="_blank"><i class="fa fa-rss fa-2x"></i></a>
            </li>

         </ul>

</div>
</div>



<div class="headerSearch">
<!-- Form's action must be the results page's URL -->
<form method="get" action="https://www.cso.ie/en/search/">
  <!-- Search field's name must be addsearch -->
  <input type="text" name="addsearch" placeholder="Search our site" autocomplete="off">
</form>
<!--<p>Search currently unavailable</p>-->
</div>






<!--/col--></div>
<!--/row--></div>
<!--/header--></div>
<p class="hide">&nbsp;<a accesskey="s" href="https://www.cso.ie/en/releasesandpublications/br/b-cdc/covid-19deathsandcasesseries18/#content">Skip navigation</a></p>
<div class="container mainNav">
<div class="row">
<div class="col span12"><a class="toggleMainNav navMobile" href="javascript:" title="show menu">Show Menu <em class="fa fa-navicon">&nbsp;</em></a>
<ul class="mainNavList">
<li><span id="homeTab"><a title="Home" href="https://www.cso.ie/en/">Home</a></span></li>
<li><span id="statisticsTab" class="currentbranch0">Statistics</span>
<div class="ddBox"><a class="pageLink" href="https://www.cso.ie/en/statistics/">Statistics</a>
<ul class="statisticsList">
<li><a href="https://www.cso.ie/en/statistics/">People and Society</a>
<!-- navigation object : People and society box --><a name="d.en.88546"></a>
<ul class="links ulList">
  
  <li id="li88546_1"><a href="https://www.cso.ie/en/statistics/population/">Population</a>  <span class="externalSource"></span></li>
  
  <li id="li88546_2"><a href="https://www.cso.ie/en/statistics/education/">Education</a>  <span class="externalSource"></span></li>
  
  <li id="li88546_3"><a href="https://www.cso.ie/en/statistics/birthsdeathsandmarriages/"> Births, Deaths &amp; Marriages </a>  <span class="externalSource"></span></li>
  
  <li id="li88546_4"><a href="https://www.cso.ie/en/statistics/crimeandjustice/">Crime and Justice</a>  <span class="externalSource"></span></li>
  
  <li id="li88546_5"><a href="https://www.cso.ie/en/statistics/socialconditions/">Social Conditions</a>  <span class="externalSource"></span></li>
  
  <li id="li88546_6"><a href="https://www.cso.ie/en/statistics/health/">Health</a>  <span class="externalSource"></span></li>
  
  <li id="li88546_7"><a href="https://www.cso.ie/en/statistics/informationsociety/">Information Society</a>  <span class="externalSource"></span></li>
  
  <li id="li88546_8"><a href="https://www.cso.ie/en/statistics/housingandhouseholds/">Housing and Households</a>  <span class="externalSource"></span></li>
  
  
  
  
  
  
  
  
</ul>


<!--<div style="margin-bottom: 20px"></div>-->

<script>
 
 $("#li88546_1").not(":has(a)").remove();  
  $("#li88546_2").not(":has(a)").remove();
  $("#li88546_3").not(":has(a)").remove();  
  $("#li88546_4").not(":has(a)").remove();  
  $("#li88546_5").not(":has(a)").remove();
  $("#li88546_6").not(":has(a)").remove();
  $("#li88546_7").not(":has(a)").remove();
  $("#li88546_8").not(":has(a)").remove();
  $("#li88546_9").not(":has(a)").remove();
  $("#li88546_10").not(":has(a)").remove();
  $("#li88546_11").not(":has(a)").remove();
  $("#li88546_12").not(":has(a)").remove();
  
</script>  


</li>
<li><a href="https://www.cso.ie/en/statistics/">Labour Market and Earnings</a>
<!-- navigation object : Labour Market & Earnings --><a name="d.en.88548"></a>
<ul class="links ulList">
  
  <li id="li88548_1"><a href="https://www.cso.ie/en/statistics/labourmarket/">Labour Market</a>  <span class="externalSource"></span></li>
  
  <li id="li88548_2"><a href="https://www.cso.ie/en/statistics/earnings/">Earnings</a>  <span class="externalSource"></span></li>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
</ul>


<!--<div style="margin-bottom: 20px"></div>-->

<script>
 
 $("#li88548_1").not(":has(a)").remove();  
  $("#li88548_2").not(":has(a)").remove();
  $("#li88548_3").not(":has(a)").remove();  
  $("#li88548_4").not(":has(a)").remove();  
  $("#li88548_5").not(":has(a)").remove();
  $("#li88548_6").not(":has(a)").remove();
  $("#li88548_7").not(":has(a)").remove();
  $("#li88548_8").not(":has(a)").remove();
  $("#li88548_9").not(":has(a)").remove();
  $("#li88548_10").not(":has(a)").remove();
  $("#li88548_11").not(":has(a)").remove();
  $("#li88548_12").not(":has(a)").remove();
  
</script>  


</li>
<li><a href="https://www.cso.ie/en/statistics/">Business Sectors</a>
<!-- navigation object : Business Sectors --><a name="d.en.88550"></a>
<ul class="links ulList">
  
  <li id="li88550_1"><a href="https://www.cso.ie/en/statistics/agriculture/">Agriculture</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_2"><a href="https://www.cso.ie/en/statistics/construction/">Construction</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_3"><a href="https://www.cso.ie/en/statistics/digitaleconomy/">Digital Economy</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_4"><a href="https://www.cso.ie/en/statistics/industry/">Industry</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_5"><a href="https://www.cso.ie/en/statistics/multisectoral/">Multisectoral</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_6"><a href="https://www.cso.ie/en/statistics/scienceandtechnology/">Science &amp; Technology</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_7"><a href="https://www.cso.ie/en/statistics/services/">Services</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_8"><a href="https://www.cso.ie/en/statistics/tourismandtravel/">Tourism &amp; Travel</a>  <span class="externalSource"></span></li>
  
  <li id="li88550_9"><a href="https://www.cso.ie/en/statistics/transport/">Transport</a>  <span class="externalSource"></span></li>
  
  
  
  
  
  
</ul>


<!--<div style="margin-bottom: 20px"></div>-->

<script>
 
 $("#li88550_1").not(":has(a)").remove();  
  $("#li88550_2").not(":has(a)").remove();
  $("#li88550_3").not(":has(a)").remove();  
  $("#li88550_4").not(":has(a)").remove();  
  $("#li88550_5").not(":has(a)").remove();
  $("#li88550_6").not(":has(a)").remove();
  $("#li88550_7").not(":has(a)").remove();
  $("#li88550_8").not(":has(a)").remove();
  $("#li88550_9").not(":has(a)").remove();
  $("#li88550_10").not(":has(a)").remove();
  $("#li88550_11").not(":has(a)").remove();
  $("#li88550_12").not(":has(a)").remove();
  
</script>  


</li>
<li><a href="https://www.cso.ie/en/statistics/">Economy</a>
<!-- navigation object : Economy --><a name="d.en.88556"></a>
<ul class="links ulList">
  
  <li id="li88556_1"><a href="https://www.cso.ie/en/statistics/internationalaccounts/">International Accounts</a>  <span class="externalSource"></span></li>
  
  <li id="li88556_2"><a href="https://www.cso.ie/en/statistics/prices/">Prices</a>  <span class="externalSource"></span></li>
  
  <li id="li88556_3"><a href="https://www.cso.ie/en/statistics/nationalaccounts/">National Accounts</a>  <span class="externalSource"></span></li>
  
  <li id="li88556_4"><a href="https://www.cso.ie/en/statistics/governmentaccounts/">Government Accounts</a>  <span class="externalSource"></span></li>
  
  <li id="li88556_5"><a href="https://www.cso.ie/en/statistics/externaltrade/">External Trade</a>  <span class="externalSource"></span></li>
  
  <li id="li88556_6"><a href="https://www.cso.ie/en/statistics/keyeconomicindicators/">Key Economic Indicators</a>  <span class="externalSource"></span></li>
  
  <li id="li88556_7"><a href="https://www.cso.ie/en/statistics/imfsummarydatapage/">IMF Summary Data Page</a>  <span class="externalSource"></span></li>
  
  
  
  
  
  
  
  
  
  
</ul>


<!--<div style="margin-bottom: 20px"></div>-->

<script>
 
 $("#li88556_1").not(":has(a)").remove();  
  $("#li88556_2").not(":has(a)").remove();
  $("#li88556_3").not(":has(a)").remove();  
  $("#li88556_4").not(":has(a)").remove();  
  $("#li88556_5").not(":has(a)").remove();
  $("#li88556_6").not(":has(a)").remove();
  $("#li88556_7").not(":has(a)").remove();
  $("#li88556_8").not(":has(a)").remove();
  $("#li88556_9").not(":has(a)").remove();
  $("#li88556_10").not(":has(a)").remove();
  $("#li88556_11").not(":has(a)").remove();
  $("#li88556_12").not(":has(a)").remove();
  
</script>  


</li>
<li><a href="https://www.cso.ie/en/statistics/">Environment</a>
<!-- navigation object : Environment and Climate --><a name="d.en.88559"></a>
<ul class="links ulList">
  
  <li id="li88559_1"><a href="https://www.cso.ie/en/statistics/environmentaccounts/">Environment Accounts</a>  <span class="externalSource"></span></li>
  
  <li id="li88559_2"><a href="https://www.cso.ie/en/statistics/environmentindicators/">Environment Indicators</a>  <span class="externalSource"></span></li>
  
  <li id="li88559_3"><a href="https://www.cso.ie/en/statistics/environmentstatistics/">Environment Statistics</a>  <span class="externalSource"></span></li>
  
  <li id="li88559_4"><a href="https://www.cso.ie/en/statistics/climateandenergy/">Climate and Energy</a>  <span class="externalSource"></span></li>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
</ul>


<!--<div style="margin-bottom: 20px"></div>-->

<script>
 
 $("#li88559_1").not(":has(a)").remove();  
  $("#li88559_2").not(":has(a)").remove();
  $("#li88559_3").not(":has(a)").remove();  
  $("#li88559_4").not(":has(a)").remove();  
  $("#li88559_5").not(":has(a)").remove();
  $("#li88559_6").not(":has(a)").remove();
  $("#li88559_7").not(":has(a)").remove();
  $("#li88559_8").not(":has(a)").remove();
  $("#li88559_9").not(":has(a)").remove();
  $("#li88559_10").not(":has(a)").remove();
  $("#li88559_11").not(":has(a)").remove();
  $("#li88559_12").not(":has(a)").remove();
  
</script>  


</li>
<li><a href="https://www.cso.ie/en/statistics/">General Statistical Publications</a>
<!-- navigation object : Environment and Climate --><a name="d.en.196257"></a>
<ul class="links">
 
  
  <li><a href="https://www.cso.ie/en/statistics/generalstatisticalpublications/geographicalprofilesofincomeinireland/">Geographical Profiles of Income in Ireland </a>  <span class="externalSource"></span></li>

</ul><a name="d.en.116511"></a>
<ul class="links">
 
  
  <li><a href="https://www.cso.ie/en/statistics/othercsopublications/brexit-irelandandtheukinnumbers/">Brexit - Ireland and the UK in numbers</a>  <span class="externalSource"></span></li>

</ul><a name="d.en.88848"></a>
<ul class="links ulList">
  
  <li id="li88848_1"><a href="https://www.cso.ie/en/statistics/lifein1916irelandstoriesfromstatistics/">Life in 1916 Ireland: Stories from statistics</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_2"><a href="https://www.cso.ie/en/statistics/statisticalyearbookofireland/">Statistical Yearbook of Ireland</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_3"><a href="https://www.cso.ie/en/statistics/generalstatisticalpublications/measuringirelandsprogress/">Measuring Ireland's Progress</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_4"><a href="https://www.cso.ie/en/statistics/generalstatisticalpublications/womenandmeninireland/">Women and Men in Ireland</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_5"><a href="https://www.cso.ie/en/statistics/irelandnorthandsouth-astatisticalprofile/">Ireland North and South - A Statistical Profile</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_6"><a href="https://www.cso.ie/en/qnhs/releasesandpublications/qnhs-specialmodules/">QNHS- Special Modules</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_7"><a href="https://www.cso.ie/en/statistics/othercsopublications/">Other Statistical Publications</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_8"><a href="https://www.cso.ie/en/statistics/unsustainabledevelopmentgoals/">UN Sustainable Development Goals</a>  <span class="externalSource"></span></li>
  
  <li id="li88848_9"><a href="https://www.cso.ie/en/statistics/generalstatisticalpublications/ealsi/">How Dark is your Sky? Estimating Artificial Light in Ireland from Satellite Imagery, 2015-2019</a>  <span class="externalSource"></span></li>
  
  
  
  
  
  
</ul>


<!--<div style="margin-bottom: 20px"></div>-->

<script>
 
 $("#li88848_1").not(":has(a)").remove();  
  $("#li88848_2").not(":has(a)").remove();
  $("#li88848_3").not(":has(a)").remove();  
  $("#li88848_4").not(":has(a)").remove();  
  $("#li88848_5").not(":has(a)").remove();
  $("#li88848_6").not(":has(a)").remove();
  $("#li88848_7").not(":has(a)").remove();
  $("#li88848_8").not(":has(a)").remove();
  $("#li88848_9").not(":has(a)").remove();
  $("#li88848_10").not(":has(a)").remove();
  $("#li88848_11").not(":has(a)").remove();
  $("#li88848_12").not(":has(a)").remove();
  
</script>  


</li>
<li><a href="https://www.cso.ie/en/statistics/a-zofreleasespublications/">A-Z of Releases and Publications</a>
<!-- navigation object : Environment and Climate --><a name="d.en.88564"></a>
<ul class="links ulList">
  
  <li id="li88564_1"><a href="https://www.cso.ie/en/statistics/multisectoral/">Access to Finance</a>  <span class="externalSource"></span></li>
  
  <li id="li88564_2"><a href="https://www.cso.ie/en/statistics/agriculture/">Agricultural Labour Input</a>  <span class="externalSource"></span></li>
  
  <li id="li88564_3"><a href="https://www.cso.ie/en/statistics/agriculture/">Agricultural Price Indices</a>  <span class="externalSource"></span></li>
  
  <li id="li88564_4"><a href="https://www.cso.ie/en/statistics/agriculture/">Agriculture Price Indices - Preliminary estimates</a>  <span class="externalSource"></span></li>
  
  <li id="li88564_5"><a href="https://www.cso.ie/en/statistics/services/">Annual Services Inquiry</a>  <span class="externalSource"></span></li>
  
  <li id="li88564_6"><a href="https://www.cso.ie/en/statistics/agriculture/">Area, Yield &amp; Production of Crops</a>  <span class="externalSource"></span></li>
  
  <li id="li88564_7"><a href="https://www.cso.ie/en/statistics/transport/">Aviation Statistics</a>  <span class="externalSource"></span></li>
  
  <li id="li88564_8"><a href="https://www.cso.ie/en/statistics/a-zofreleasespublications/"><b>View All...</b></a>  <span class="externalSource"></span></li>
  
  
  
  
  
  
  
  
</ul>


<!--<div style="margin-bottom: 20px"></div>-->

<script>
 
 $("#li88564_1").not(":has(a)").remove();  
  $("#li88564_2").not(":has(a)").remove();
  $("#li88564_3").not(":has(a)").remove();  
  $("#li88564_4").not(":has(a)").remove();  
  $("#li88564_5").not(":has(a)").remove();
  $("#li88564_6").not(":has(a)").remove();
  $("#li88564_7").not(":has(a)").remove();
  $("#li88564_8").not(":has(a)").remove();
  $("#li88564_9").not(":has(a)").remove();
  $("#li88564_10").not(":has(a)").remove();
  $("#li88564_11").not(":has(a)").remove();
  $("#li88564_12").not(":has(a)").remove();
  
</script>  


</li>
</ul>
<a class="close" href="javascript:">close <em class="fa fa-arrow-circle-up">&nbsp;</em></a></div>
<!--/ddBox--></li>
<li><span id="databasesTab"><a title="Databases" href="https://www.cso.ie/en/databases/">Databases</a></span></li>
<li><span id="methodsTab"><a title="Methods" href="https://www.cso.ie/en/methods/">Methods</a></span></li>
<li><span id="aboutUsTab"><a title="About Us" href="https://www.cso.ie/en/aboutus/">About Us</a></span></li>
<li><span id="censusTab"><a title="Census" href="https://www.cso.ie/en/census/">Census</a></span></li>
<!--<li><a href="#onlineSurvey" class="fancySurvey">Show Survey</a></li>--></ul>
</div>
<!--/col--></div>
<!--/row--></div>
<!--/mainNav-->

<!--end Code only (admin)-->	
      <!--/mainNav-->
         <!-- end header -->   
            <!-- ********** CONTENT ********** -->
		<div class="container content">
			<div class="row pageHeader">
				<div class="col span12">
					<div id="breadcrumbs">
						<span class="youarehere">You are here: </span> 
						<!-- navigation object : Breadcrumb --><a href="https://www.cso.ie/en/">Home</a> / <a href="https://www.cso.ie/en/releasesandpublications/">Releases and Publications</a> / <a href="https://www.cso.ie/en/releasesandpublications/br/">BR</a> / <a href="https://www.cso.ie/en/releasesandpublications/br/b-cdc/">B-CDC</a> / <a href="https://www.cso.ie/en/releasesandpublications/br/b-cdc/covid-19deathsandcasesseries18/">COVID-19 Deaths and Cases, Series 18</a>
					</div><!--/breadcrumb-->
				</div><!--/col-->
                 
          
              
                           
				<div class="col span12">
					<h1 id="pageTitle">COVID-19 Deaths and Cases, Series 18</h1>
				</div><!--/col-->

			</div><!--/row-->
			<div class="row mainContent">
				<div id="columnLeft" class="col columnLeft">
					<div class="copy"><div class="br_container"> <!-- starts wrapper for columns -->
<div class="br_lhs"> <!-- starts LHS column -->
  
<div class="br_title">
  <h1>COVID Deaths and Cases</h1>
</div>
<div class="br_instance">
  <h3>From 28 February to 11 December 2020</h3>
</div>
<div id="releaseDate" class="br_date">
  <span id="releasePublication">CSO statistical release</span>, <time datetime="2020-12-18GMT110000+0000">18 December 2020</time>, 11am
</div>


<script>
  //this came over from ER template - I don't need it but it outputs contact details for pdf - check with Damien
$(document).ready(function(){  
     
  var contactDetailsPrint=$('#contactDetails').clone();
  
  $("#printContact").html(contactDetailsPrint); 
  
    
});
</script>



<div class="bulletin-banner">
  
  <h3>COVID-19 Insight Bulletins: Deaths and Cases, Series 18</h3>
  <h4>Information on the people who have died from COVID-19 or have been diagnosed with the virus.</h4>
</div>
<a name="d.en.262840"></a>
<p><strong>Key Findings:</strong></p>
<ul>
<li>The number of cases for the week ending 11 December was 1,694 - a decrease of 243 cases from the previous week</li>
<li>The percentage of cases in the 65-79 and 80+ age categories has been increasing in recent weeks, these age groups made up 10% of cases in the week ending 11 December up from less than 5% in week ending 10 August</li>
<li>The median age of new confirmed COVID-19 cases was 33 years old for the week ending 11 December</li>
<li>More than 20 people have died from COVID-19 in each of the last nine weeks</li>
<li>It is the sixth week in a row that Dublin had less than 1,000 weekly cases and in the week ending 11 December, Dublin accounted for 28% of all new cases</li>
<li>More than half (55%) of all confirmed cases were linked to an outbreak and 35% of cases linked to an outbreak were under 25 years old</li>
<li>Outbreaks in hospitals accounted for 14% of cases and nursing homes for 9% of cases linked to an outbreak in November and December, up from 2% and 5% of cases linked to an outbreak in September and October</li>
<li>The average mortality rate in November was 12 people per 1,000 confirmed cases, down from a peak of 74 per 1,000 in April, but higher than in recent months due to the rise in cases among older groups</li>
<li>The average hospitalisation rate in November was 64 people per 1,000 confirmed cases, down from a peak of 192 per 1,000 in March, this is higher than in recent months&nbsp;due to the increase in cases among older groups</li>
<li>The average ICU rate in September, October and November was five or less per 1,000 confirmed cases, down from a peak of 28 per 1,000 in March</li>
<li>The average number of contacts per positive case per week was three in the week ending 11 December, down from four contacts in early October</li>
</ul>
<p>This is the eighteenth publication in our series of information bulletins produced by the Central Statistics Office (CSO), that aim to provide insights into those who have either died from or contracted COVID-19, by using data from the Computerised Infectious Disease Reporting (CIDR) provided to the CSO by the Health Protection Surveillance Centre and data from the HSE’s Swiftcare (A2i) and COVID Care Tracker (CCT) systems. This Bulletin covers the period from 28 February to 11 December 2020.</p>

<a name="d.en.262822"></a>
<p><strong>Referrals and Testing </strong></p>
<p>There were 64,061 referrals for community testing where a valid reservation was recorded in the week ending 11 December. Referrals for testing decreased in the last week, in particular among the 45 – 64 age groups, which&nbsp;fell from 19,324 to 17,826 in the week ending 11 December. Some 46% of referrals were from GPs in the week ending 11 December. Analysis on referral speciality type shows that while Healthcare/ Essential worker referrals for testing have remained consistent for the last number of weeks contact testing/at risk groups and general COVID-19 testing has increased in December.</p>
<p>Testing numbers cannot be directly compared with referrals for community testing; there is a significant number of tests completed in hospitals as well as a time lag between referral and test completion. Several referrals also do not result in a test being completed. However, weekly testing numbers from HSE labs and hospitals show there were 78,416 tests completed in the week ending 11 December. The positivity rate in the week ending 11 December was 2.5% down from 2.6% the previous week.</p>
<p><strong>Contacts</strong></p>
<p>The average number of contacts per positive case per week was three in the week ending 11 December, down from four contacts per case in early October. This implies details of more than 5,000 close contacts were recorded in the week. In the 15-24 age group, the number of contacts per case was four in the week ending 11 December.</p>
 <style>
 .highcharts-tooltip {
    z-index: 9998;

}

   .tooltip {
   /*padding:10px;*/
   background-color:white;
}
   
.highcharts-tooltip span {
    background-color:white;
    
    opacity:1;
    z-index:9999!important;
} 
   
</style>

<div style="display: none" id="262820stacking">null</div>
<div style="clear: both"></div>



    
    <div id="highchartDiv262820" class="highchartBox" data-highcharts-chart="0" style="overflow: hidden;"><div id="highcharts-dutyqdt-0" dir="ltr" class="highcharts-container " style="position: relative; overflow: hidden; width: 1146px; height: 400px; text-align: left; line-height: normal; z-index: 0; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); user-select: none;"><svg version="1.1" class="highcharts-root" style="font-family:&quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif;font-size:12px;" xmlns="http://www.w3.org/2000/svg" width="1146" height="400" viewBox="0 0 1146 400"><desc>Created with Highcharts 8.2.2</desc><defs><clippath id="highcharts-dutyqdt-1-"><rect x="0" y="0" width="1043" height="222" fill="none"></rect></clippath></defs><rect fill="#ffffff" class="highcharts-background" x="0" y="0" width="1146" height="400" rx="0" ry="0"></rect><rect fill="none" class="highcharts-plot-background" x="53" y="76" width="1043" height="222"></rect><g class="highcharts-pane-group" data-z-index="0"></g><g class="highcharts-plot-lines-0" data-z-index="0"><path fill="none" class="highcharts-plot-line "></path></g><g class="highcharts-grid highcharts-xaxis-grid" data-z-index="1"><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 147.5 76 L 147.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 242.5 76 L 242.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 336.5 76 L 336.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 431.5 76 L 431.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 526.5 76 L 526.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 621.5 76 L 621.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 716.5 76 L 716.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 811.5 76 L 811.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 905.5 76 L 905.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 1000.5 76 L 1000.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 1095.5 76 L 1095.5 298" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 52.5 76 L 52.5 298" opacity="1"></path></g><g class="highcharts-grid highcharts-yaxis-grid" data-z-index="1"><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 53 298.5 L 1096 298.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 53 243.5 L 1096 243.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 53 187.5 L 1096 187.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 53 132.5 L 1096 132.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 53 75.5 L 1096 75.5" opacity="1"></path></g><rect fill="none" class="highcharts-plot-border" data-z-index="1" x="53" y="76" width="1043" height="222"></rect><g class="highcharts-axis highcharts-xaxis" data-z-index="2"><path fill="none" class="highcharts-axis-line" stroke="#ccd6eb" stroke-width="1" data-z-index="7" d="M 53 298.5 L 1096 298.5"></path></g><g class="highcharts-axis highcharts-yaxis" data-z-index="2"><path fill="none" class="highcharts-axis-line" data-z-index="7" d="M 53 76 L 53 298"></path></g><g class="highcharts-series-group" data-z-index="3"><g class="highcharts-series highcharts-series-0 highcharts-line-series highcharts-color-0" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-1-)"><path fill="none" d="M 47.409090909091 138.75 L 142.22727272727 138.75 L 237.04545454545 138.75 L 331.86363636364 160.95 L 426.68181818182 149.85 L 521.5 152.625 L 616.31818181818 144.3 L 711.13636363636 160.95 L 805.95454545455 147.075 L 900.77272727273 147.075 L 995.59090909091 147.075" class="highcharts-graph" data-z-index="1" stroke="#405482" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 47.409090909091 138.75 L 142.22727272727 138.75 L 237.04545454545 138.75 L 331.86363636364 160.95 L 426.68181818182 149.85 L 521.5 152.625 L 616.31818181818 144.3 L 711.13636363636 160.95 L 805.95454545455 147.075 L 900.77272727273 147.075 L 995.59090909091 147.075" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-0 highcharts-line-series highcharts-color-0 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)"><path fill="#405482" d="M 47 140.75 A 2 2 0 1 1 47.001999999666666 140.7499990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 142 140.75 A 2 2 0 1 1 142.00199999966668 140.7499990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 237 140.75 A 2 2 0 1 1 237.00199999966668 140.7499990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 331 162.95 A 2 2 0 1 1 331.0019999996667 162.94999900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 426 151.85 A 2 2 0 1 1 426.0019999996667 151.84999900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 521 154.625 A 2 2 0 1 1 521.0019999996666 154.6249990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 616 146.3 A 2 2 0 1 1 616.0019999996666 146.2999990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 711 162.95 A 2 2 0 1 1 711.0019999996666 162.94999900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 805 149.075 A 2 2 0 1 1 805.0019999996666 149.07499900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 900 149.075 A 2 2 0 1 1 900.0019999996666 149.07499900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 995 149.075 A 2 2 0 1 1 995.0019999996666 149.07499900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path></g><g class="highcharts-series highcharts-series-1 highcharts-line-series highcharts-color-1" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-1-)"><path fill="none" d="M 47.409090909091 47.17500000000001 L 142.22727272727 80.47500000000002 L 237.04545454545 111 L 331.86363636364 124.875 L 426.68181818182 130.425 L 521.5 116.55000000000001 L 616.31818181818 105.44999999999999 L 711.13636363636 119.32499999999999 L 805.95454545455 105.44999999999999 L 900.77272727273 122.1 L 995.59090909091 105.44999999999999" class="highcharts-graph" data-z-index="1" stroke="#00af86" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 47.409090909091 47.17500000000001 L 142.22727272727 80.47500000000002 L 237.04545454545 111 L 331.86363636364 124.875 L 426.68181818182 130.425 L 521.5 116.55000000000001 L 616.31818181818 105.44999999999999 L 711.13636363636 119.32499999999999 L 805.95454545455 105.44999999999999 L 900.77272727273 122.1 L 995.59090909091 105.44999999999999" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-1 highcharts-line-series highcharts-color-1 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)"><path fill="#00af86" d="M 47 45.17500000000001 L 49 47.17500000000001 L 47 49.17500000000001 L 45 47.17500000000001 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 142 78.47500000000002 L 144 80.47500000000002 L 142 82.47500000000002 L 140 80.47500000000002 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 237 109 L 239 111 L 237 113 L 235 111 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 331 122.875 L 333 124.875 L 331 126.875 L 329 124.875 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 426 128.425 L 428 130.425 L 426 132.425 L 424 130.425 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 521 114.55000000000001 L 523 116.55000000000001 L 521 118.55000000000001 L 519 116.55000000000001 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 616 103.44999999999999 L 618 105.44999999999999 L 616 107.44999999999999 L 614 105.44999999999999 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 711 117.32499999999999 L 713 119.32499999999999 L 711 121.32499999999999 L 709 119.32499999999999 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 805 103.44999999999999 L 807 105.44999999999999 L 805 107.44999999999999 L 803 105.44999999999999 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 900 120.1 L 902 122.1 L 900 124.1 L 898 122.1 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 995 103.44999999999999 L 997 105.44999999999999 L 995 107.44999999999999 L 993 105.44999999999999 Z" opacity="1" class="highcharts-point highcharts-color-1"></path></g><g class="highcharts-series highcharts-series-2 highcharts-line-series highcharts-color-2" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-1-)"><path fill="none" d="M 47.409090909091 88.80000000000001 L 142.22727272727 99.89999999999999 L 237.04545454545 133.2 L 331.86363636364 124.875 L 426.68181818182 130.425 L 521.5 124.875 L 616.31818181818 124.875 L 711.13636363636 119.32499999999999 L 805.95454545455 127.65 L 900.77272727273 122.1 L 995.59090909091 124.875" class="highcharts-graph" data-z-index="1" stroke="#fbaa34" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 47.409090909091 88.80000000000001 L 142.22727272727 99.89999999999999 L 237.04545454545 133.2 L 331.86363636364 124.875 L 426.68181818182 130.425 L 521.5 124.875 L 616.31818181818 124.875 L 711.13636363636 119.32499999999999 L 805.95454545455 127.65 L 900.77272727273 122.1 L 995.59090909091 124.875" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-2 highcharts-line-series highcharts-color-2 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)"><path fill="#fbaa34" d="M 45 86.80000000000001 L 49 86.80000000000001 L 49 90.80000000000001 L 45 90.80000000000001 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 140 97.89999999999999 L 144 97.89999999999999 L 144 101.89999999999999 L 140 101.89999999999999 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 235 131.2 L 239 131.2 L 239 135.2 L 235 135.2 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 329 122.875 L 333 122.875 L 333 126.875 L 329 126.875 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 424 128.425 L 428 128.425 L 428 132.425 L 424 132.425 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 519 122.875 L 523 122.875 L 523 126.875 L 519 126.875 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 614 122.875 L 618 122.875 L 618 126.875 L 614 126.875 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 709 117.32499999999999 L 713 117.32499999999999 L 713 121.32499999999999 L 709 121.32499999999999 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 803 125.65 L 807 125.65 L 807 129.65 L 803 129.65 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 898 120.1 L 902 120.1 L 902 124.1 L 898 124.1 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 993 122.875 L 997 122.875 L 997 126.875 L 993 126.875 Z" opacity="1" class="highcharts-point highcharts-color-2"></path></g><g class="highcharts-series highcharts-series-3 highcharts-line-series highcharts-color-3" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-1-)"><path fill="none" d="M 47.409090909091 119.32499999999999 L 142.22727272727 113.775 L 237.04545454545 135.975 L 331.86363636364 133.2 L 426.68181818182 147.075 L 521.5 127.65 L 616.31818181818 135.975 L 711.13636363636 130.425 L 805.95454545455 130.425 L 900.77272727273 141.525 L 995.59090909091 133.2" class="highcharts-graph" data-z-index="1" stroke="#3c5daa" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 47.409090909091 119.32499999999999 L 142.22727272727 113.775 L 237.04545454545 135.975 L 331.86363636364 133.2 L 426.68181818182 147.075 L 521.5 127.65 L 616.31818181818 135.975 L 711.13636363636 130.425 L 805.95454545455 130.425 L 900.77272727273 141.525 L 995.59090909091 133.2" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-3 highcharts-line-series highcharts-color-3 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)"><path fill="#3c5daa" d="M 47 117.32499999999999 L 49 121.32499999999999 L 45 121.32499999999999 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 142 111.775 L 144 115.775 L 140 115.775 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 237 133.975 L 239 137.975 L 235 137.975 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 331 131.2 L 333 135.2 L 329 135.2 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 426 145.075 L 428 149.075 L 424 149.075 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 521 125.65 L 523 129.65 L 519 129.65 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 616 133.975 L 618 137.975 L 614 137.975 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 711 128.425 L 713 132.425 L 709 132.425 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 805 128.425 L 807 132.425 L 803 132.425 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 900 139.525 L 902 143.525 L 898 143.525 Z" opacity="1" class="highcharts-point highcharts-color-3"></path><path fill="#3c5daa" d="M 995 131.2 L 997 135.2 L 993 135.2 Z" opacity="1" class="highcharts-point highcharts-color-3"></path></g><g class="highcharts-series highcharts-series-4 highcharts-line-series highcharts-color-4" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-1-)"><path fill="none" d="M 47.409090909091 138.75 L 142.22727272727 138.75 L 237.04545454545 138.75 L 331.86363636364 135.975 L 426.68181818182 155.4 L 521.5 155.4 L 616.31818181818 160.95 L 711.13636363636 147.075 L 805.95454545455 166.5 L 900.77272727273 163.725 L 995.59090909091 149.85" class="highcharts-graph" data-z-index="1" stroke="#b7be34" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 47.409090909091 138.75 L 142.22727272727 138.75 L 237.04545454545 138.75 L 331.86363636364 135.975 L 426.68181818182 155.4 L 521.5 155.4 L 616.31818181818 160.95 L 711.13636363636 147.075 L 805.95454545455 166.5 L 900.77272727273 163.725 L 995.59090909091 149.85" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-4 highcharts-line-series highcharts-color-4 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)"><path fill="#b7be34" d="M 45 136.75 L 49 136.75 L 47 140.75 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 140 136.75 L 144 136.75 L 142 140.75 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 235 136.75 L 239 136.75 L 237 140.75 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 329 133.975 L 333 133.975 L 331 137.975 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 424 153.4 L 428 153.4 L 426 157.4 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 519 153.4 L 523 153.4 L 521 157.4 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 614 158.95 L 618 158.95 L 616 162.95 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 709 145.075 L 713 145.075 L 711 149.075 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 803 164.5 L 807 164.5 L 805 168.5 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 898 161.725 L 902 161.725 L 900 165.725 Z" opacity="1" class="highcharts-point highcharts-color-4"></path><path fill="#b7be34" d="M 993 147.85 L 997 147.85 L 995 151.85 Z" opacity="1" class="highcharts-point highcharts-color-4"></path></g><g class="highcharts-series highcharts-series-5 highcharts-line-series highcharts-color-5" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-1-)"><path fill="none" d="M 47.409090909091 155.4 L 142.22727272727 160.95 L 237.04545454545 160.95 L 331.86363636364 163.725 L 426.68181818182 155.4 L 521.5 141.525 L 616.31818181818 166.5 L 711.13636363636 158.175 L 805.95454545455 155.4 L 900.77272727273 147.075 L 995.59090909091 138.75" class="highcharts-graph" data-z-index="1" stroke="#0099b4" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 47.409090909091 155.4 L 142.22727272727 160.95 L 237.04545454545 160.95 L 331.86363636364 163.725 L 426.68181818182 155.4 L 521.5 141.525 L 616.31818181818 166.5 L 711.13636363636 158.175 L 805.95454545455 155.4 L 900.77272727273 147.075 L 995.59090909091 138.75" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-5 highcharts-line-series highcharts-color-5 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)"><path fill="#0099b4" d="M 47 157.4 A 2 2 0 1 1 47.001999999666666 157.3999990000001 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 142 162.95 A 2 2 0 1 1 142.00199999966668 162.94999900000008 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 237 162.95 A 2 2 0 1 1 237.00199999966668 162.94999900000008 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 331 165.725 A 2 2 0 1 1 331.0019999996667 165.72499900000008 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 426 157.4 A 2 2 0 1 1 426.0019999996667 157.3999990000001 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 521 143.525 A 2 2 0 1 1 521.0019999996666 143.5249990000001 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 616 168.5 A 2 2 0 1 1 616.0019999996666 168.4999990000001 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 711 160.175 A 2 2 0 1 1 711.0019999996666 160.1749990000001 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 805 157.4 A 2 2 0 1 1 805.0019999996666 157.3999990000001 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 900 149.075 A 2 2 0 1 1 900.0019999996666 149.07499900000008 Z" opacity="1" class="highcharts-point highcharts-color-5"></path><path fill="#0099b4" d="M 995 140.75 A 2 2 0 1 1 995.0019999996666 140.7499990000001 Z" opacity="1" class="highcharts-point highcharts-color-5"></path></g><g class="highcharts-series highcharts-series-6 highcharts-line-series highcharts-color-6" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-1-)"><path fill="none" d="M 47.409090909091 94.35000000000001 L 142.22727272727 105.44999999999999 L 237.04545454545 130.425 L 331.86363636364 135.975 L 426.68181818182 138.75 L 521.5 130.425 L 616.31818181818 127.65 L 711.13636363636 130.425 L 805.95454545455 130.425 L 900.77272727273 135.975 L 995.59090909091 127.65" class="highcharts-graph" data-z-index="1" stroke="#5b6670" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 47.409090909091 94.35000000000001 L 142.22727272727 105.44999999999999 L 237.04545454545 130.425 L 331.86363636364 135.975 L 426.68181818182 138.75 L 521.5 130.425 L 616.31818181818 127.65 L 711.13636363636 130.425 L 805.95454545455 130.425 L 900.77272727273 135.975 L 995.59090909091 127.65" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-6 highcharts-line-series highcharts-color-6 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(53,76) scale(1 1)"><path fill="#5b6670" d="M 47 92.35000000000001 L 49 94.35000000000001 L 47 96.35000000000001 L 45 94.35000000000001 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 142 103.44999999999999 L 144 105.44999999999999 L 142 107.44999999999999 L 140 105.44999999999999 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 237 128.425 L 239 130.425 L 237 132.425 L 235 130.425 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 331 133.975 L 333 135.975 L 331 137.975 L 329 135.975 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 426 136.75 L 428 138.75 L 426 140.75 L 424 138.75 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 521 128.425 L 523 130.425 L 521 132.425 L 519 130.425 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 616 125.65 L 618 127.65 L 616 129.65 L 614 127.65 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 711 128.425 L 713 130.425 L 711 132.425 L 709 130.425 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 805 128.425 L 807 130.425 L 805 132.425 L 803 130.425 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 900 133.975 L 902 135.975 L 900 137.975 L 898 135.975 Z" opacity="1" class="highcharts-point highcharts-color-6"></path><path fill="#5b6670" d="M 995 125.65 L 997 127.65 L 995 129.65 L 993 127.65 Z" opacity="1" class="highcharts-point highcharts-color-6"></path></g></g><g class="highcharts-exporting-group" data-z-index="3"><g class="highcharts-button highcharts-contextbutton" stroke-linecap="round" transform="translate(1112,10)"><rect fill="#ffffff" class="highcharts-button-box" x="0.5" y="0.5" width="24" height="22" rx="2" ry="2" stroke="none" stroke-width="1"></rect><title>Chart context menu</title><path fill="#666666" d="M 6 6.5 L 20 6.5 M 6 11.5 L 20 11.5 M 6 16.5 L 20 16.5" class="highcharts-button-symbol" data-z-index="1" stroke="#666666" stroke-width="3"></path><text x="0" data-z-index="1" y="12" style="color:#333333;cursor:pointer;font-weight:normal;fill:#333333;"></text></g></g><text x="10" text-anchor="start" class="highcharts-caption" data-z-index="4" style="color:#666666;fill:#666666;" y="397"></text><g class="highcharts-legend" data-z-index="7" transform="translate(190,361)"><rect fill="none" class="highcharts-legend-box" rx="0" ry="0" x="0" y="0" width="767" height="24" visibility="visible"></rect><g data-z-index="1"><g><g class="highcharts-legend-item highcharts-line-series highcharts-color-0 highcharts-series-0" data-z-index="1" transform="translate(8,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#405482" stroke-width="2"></path><path fill="#405482" d="M 8 13 A 2 2 0 1 1 8.001999999666667 12.999999000000084 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-1 highcharts-series-1" data-z-index="1" transform="translate(109,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#00af86" stroke-width="2"></path><path fill="#00af86" d="M 8 9 L 10 11 L 8 13 L 6 11 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-2 highcharts-series-2" data-z-index="1" transform="translate(217,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#fbaa34" stroke-width="2"></path><path fill="#fbaa34" d="M 6 9 L 10 9 L 10 13 L 6 13 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-3 highcharts-series-3" data-z-index="1" transform="translate(325,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#3c5daa" stroke-width="2"></path><path fill="#3c5daa" d="M 8 9 L 10 13 L 6 13 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-4 highcharts-series-4" data-z-index="1" transform="translate(433,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#b7be34" stroke-width="2"></path><path fill="#b7be34" d="M 6 9 L 10 9 L 8 13 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-5 highcharts-series-5" data-z-index="1" transform="translate(541,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#0099b4" stroke-width="2"></path><path fill="#0099b4" d="M 8 13 A 2 2 0 1 1 8.001999999666667 12.999999000000084 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-6 highcharts-series-6" data-z-index="1" transform="translate(689,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#5b6670" stroke-width="2"></path><path fill="#5b6670" d="M 8 9 L 10 11 L 8 13 L 6 11 Z" class="highcharts-point" opacity="1"></path></g></g></g></g><g class="highcharts-axis-labels highcharts-xaxis-labels" data-z-index="7"><text x="102.76611351304425" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 102.76611351304425 313)" y="313" opacity="1">02/10/2020</text><text x="197.58429533122424" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 197.58429533122424 313)" y="313" opacity="1">09/10/2020</text><text x="292.40247714941427" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 292.40247714941427 313)" y="313" opacity="1">16/10/2020</text><text x="387.2206589675942" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 387.2206589675942 313)" y="313" opacity="1">23/10/2020</text><text x="482.03884078577437" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 482.03884078577437 313)" y="313" opacity="1">30/10/2020</text><text x="576.8570226039543" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 576.8570226039543 313)" y="313" opacity="1">06/11/2020</text><text x="671.6752044221342" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 671.6752044221342 313)" y="313" opacity="1">13/11/2020</text><text x="766.4933862403142" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 766.4933862403142 313)" y="313" opacity="1">20/11/2020</text><text x="861.3115680585043" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 861.3115680585043 313)" y="313" opacity="1">27/11/2020</text><text x="956.1297498766643" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 956.1297498766643 313)" y="313" opacity="1">04/12/2020</text><text x="1050.947931694864" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="end" transform="translate(0,0) rotate(-45 1050.947931694864 313)" y="313" opacity="1">11/12/2020</text></g><g class="highcharts-axis-labels highcharts-yaxis-labels" data-z-index="7"></g><text x="1136" class="highcharts-credits" text-anchor="end" data-z-index="8" style="cursor:context-menu;color:#999999;font-size:9px;fill:#999999;" y="395"><tspan>Source: CSO Ireland</tspan></text></svg><span class="highcharts-title" data-z-index="4" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 14px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 403px; top: 7px; color: rgb(51, 51, 51); text-align: center;">Figure 1 - Average Contacts per Case by Age Group</span><span class="highcharts-subtitle" data-z-index="4" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 0px; top: 373px; color: rgb(102, 102, 102);"></span><div class="highcharts-legend" style="position: absolute; left: 190px; top: 361px; opacity: 1;"><div style="position: absolute; left: 0px; top: 0px; opacity: 1;"><div style="position: absolute; left: 0px; top: 0px; opacity: 1;"><div class="highcharts-legend-item highcharts-line-series highcharts-color-0 highcharts-series-0" style="position: absolute; left: 8px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">0-14 years</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-1 highcharts-series-1" style="position: absolute; left: 109px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">15-24 years</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-2 highcharts-series-2" style="position: absolute; left: 217px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">25-44 years</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-3 highcharts-series-3" style="position: absolute; left: 325px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">45-64 years</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-4 highcharts-series-4" style="position: absolute; left: 433px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">65-79 years</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-5 highcharts-series-5" style="position: absolute; left: 541px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">80 years and over</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-6 highcharts-series-6" style="position: absolute; left: 689px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">All ages</span></div></div></div></div><div class="highcharts-axis-labels highcharts-yaxis-labels" style="position: absolute; left: 0px; top: 0px; opacity: 1;"><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 237px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">2</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 181px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">4</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 126px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">6</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 292px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">0</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 70px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">8</span></div><div class="highcharts-axis highcharts-yaxis" style="position: absolute; left: 0px; top: 0px; opacity: 1;"><span data-z-index="7" class="highcharts-axis-title" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(102, 102, 102); margin-left: 0px; margin-top: 0px; transform: rotate(270deg); transform-origin: 50% 12px; left: -2.5px; top: 175px; visibility: inherit;">Contacts</span></div></div></div><div class="highchartTable" id="262820datatable">
 
   <!-- Livestock Survey December - LSD2012   FIG4  Created:  2020/8/13 14:45 -->
<table id="262820table"><thead><tr>
<th></th><td class="line">0-14 years</td><td class="line">15-24 years</td><td class="line">25-44 years</td><td class="line">45-64 years</td><td class="line">65-79 years</td><td class="line">80 years and over</td><td class="line">All ages</td></tr></thead><tbody>
<tr><th>02/10/2020</th><td>3.0</td><td>6.3</td><td>4.8</td><td>3.7</td><td>3.0</td><td>2.4</td><td>4.6</td></tr>
<tr><th>09/10/2020</th><td>3.0</td><td>5.1</td><td>4.4</td><td>3.9</td><td>3.0</td><td>2.2</td><td>4.2</td></tr>
<tr><th>16/10/2020</th><td>3.0</td><td>4.0</td><td>3.2</td><td>3.1</td><td>3.0</td><td>2.2</td><td>3.3</td></tr>
<tr><th>23/10/2020</th><td>2.2</td><td>3.5</td><td>3.5</td><td>3.2</td><td>3.1</td><td>2.1</td><td>3.1</td></tr>
<tr><th>30/10/2020</th><td>2.6</td><td>3.3</td><td>3.3</td><td>2.7</td><td>2.4</td><td>2.4</td><td>3.0</td></tr>
<tr><th>06/11/2020</th><td>2.5</td><td>3.8</td><td>3.5</td><td>3.4</td><td>2.4</td><td>2.9</td><td>3.3</td></tr>
<tr><th>13/11/2020</th><td>2.8</td><td>4.2</td><td>3.5</td><td>3.1</td><td>2.2</td><td>2.0</td><td>3.4</td></tr>
<tr><th>20/11/2020</th><td>2.2</td><td>3.7</td><td>3.7</td><td>3.3</td><td>2.7</td><td>2.3</td><td>3.3</td></tr>
<tr><th>27/11/2020</th><td>2.7</td><td>4.2</td><td>3.4</td><td>3.3</td><td>2.0</td><td>2.4</td><td>3.3</td></tr>
<tr><th>04/12/2020</th><td>2.7</td><td>3.6</td><td>3.6</td><td>2.9</td><td>2.1</td><td>2.7</td><td>3.1</td></tr>
<tr><th>11/12/2020</th><td>2.7</td><td>4.2</td><td>3.5</td><td>3.2</td><td>2.6</td><td>3.0</td><td>3.4</td></tr>
</tbody></table>
 
     </div>
          
 

<div style="clear: both"></div>

<div class="highchartText">
 
</div>
 <div style="clear: both"></div>  





<script language="JavaScript" type="text/JavaScript">
$(function () {

	// On document ready, call visualize on the datatable.
	$(document).ready(function () {
		/**
		 * Visualize an HTML table using Highcharts. The top (horizontal) header
		 * is used for series names, and the left (vertical) header is used
		 * for category names. This function is based on jQuery.
		 * @param {Object} table The reference to the HTML table to visualize
		 * @param {Object} options Highcharts options
		 */

		$("#262820datatable table").attr('id', '262820table');

		Highcharts.visualize = function (table, options) {
			// the categories
			options.xAxis.categories = [];
			$('tbody th', table).each(function (i) {
				options.xAxis.categories.push(this.innerHTML);
			});

			Highcharts.setOptions({
				lang: {
					thousandsSep: ',',
					decimalPoint: '.',
					numericSymbols: ['k', ' million', ' billion', ' trillion']
				}
			});

			// the data series
			options.series = [];

			$('tr', table).each(function (i) {
				var tr = this;

				$('th, td', tr).each(function (j) {
					if (j > 0) { // skip first column
						if (i == 0) { // get the name and init the series
							options.series[j - 1] = {
								name: this.innerHTML,
								data: [],

								color: $(this).attr("color"),

								connectNulls: true,

								type: $(this).attr("class")
							};
						} else { // add values
							options.series[j - 1].data.push(parseFloat(this.innerHTML));

						}
					}
				});
			});

			var chart = new Highcharts.Chart(options);
		}

		

		var screenWidth = $(window).width();
		
		if (screenWidth < 800) {


		} else {

			
		}

		var table = document.getElementById('262820table');
		var credits = 'Source: CSO Ireland';

		if (credits == '') {
			credits = 'Source: CSO Ireland';
		} else {
			

		}
		
		var yAxisMax = null;
		var yAxisMaxStr = '';
		
		if(yAxisMaxStr.length > 0) {
			yAxisMax = parseInt(yAxisMaxStr);
		};



		options = {

			chart: {
  
  
  
  
  
  
  
  
  events: {
            beforePrint: function () {
                this.oldhasUserSize = this.hasUserSize;
                this.resetParams = [this.chartWidth, this.chartHeight, false];
                this.setSize(600, 400, false);
            },
            afterPrint: function () {
                this.setSize.apply(this, this.resetParams);
                this.hasUserSize = this.oldhasUserSize;
            }
        },

				renderTo: 'highchartDiv262820',

				zoomType: 'none',
				marginRight: 50,

				height:  400

			},

			subtitle: {
				text: '',
				x: -10,
				verticalAlign: 'bottom',
				y: 0,
				align: 'left',
				widthAdjust: -200,
				useHTML: true

			},

			credits: {
				text: credits,
				href: '',
				style: {
					cursor: 'context-menu'
				}

			},

			colors: [
				'#405482',
				'#00af86',
				'#fbaa34',
				'#3c5daa',				
				'#b7be34',
				'#0099b4',
				'#5b6670',
				'#ffc629',
				'#566db4',
				'#6ac5ad',
				'#FFCC66',
				'#6699CC'
			],

			title: {

				style: {
					fontSize: '14px',
					textAlign: 'center'
				},

				text: 'Figure 1 - Average Contacts per Case by Age Group',
				useHTML: true,
				margin: 50
			},

			xAxis:
			{

				tickInterval:  0 ,

				labels: {

					 rotation: -45.0 ,

						style: {
						fontSize: '10px',
						width: 'auto',
						useHTML: true

					},
					
				}

			},

			plotOptions: {
				series: {

					marker: {

						radius: 2

					},

					shadow: false,
					border: true

				}
			},
			 

				tooltip: {

				useHTML: true,

				formatter: function () {

					function addCommas(nStr) {
						nStr += '';
						var x = nStr.split('.');
						var x1 = x[0];
						var x2 = x.length > 1 ? '.' + x[1] : '';
						var rgx = /(\d+)(\d{3})/;
						while (rgx.test(x1)) {
							x1 = x1.replace(rgx, '$1' + ',' + '$2');
						}
						return x1 + x2;
					}

					var numDecimals = Math.pow(10,  0 );
					var number = this.y;

					if (number >= 0) {

						return this.x + '</br>' + this.series.name + ': <b>' + addCommas(Math.round((this.y + 0.0000001) * numDecimals) / numDecimals) + ' Contacts</b>';

					} else {

						return this.x + '</br>' + this.series.name + ': <b>' + addCommas(Math.round((this.y - 0.0000001) * numDecimals) / numDecimals) + ' Contacts</b>';

					}

				}

			},
			legend: {useHTML: true},
			yAxis:
			{
				labels:{
					useHTML: true
				
				},
                useHTML: true,
				plotLines: [{

						 

					}
				],

				startOnTick: true,

				 

					max: yAxisMax,
					title: {
					text: 'Contacts',
                    useHTML: true
				}

			}
			

		};
		
			
		
		
		if ($("#262820stacking").text() == '') {	
			
			

			
			

		} else if ($("#262820stacking").text() == 'null') {

			

		} else if ($("#262820stacking").text() == 'normal') {

			options.plotOptions.series = {

					marker: {

						radius: 2

					},

					shadow: false,
					border: true,
					stacking: 'normal'
					

				}

		} else if ($("#262820stacking").text() == 'percent') {

			options.plotOptions.series = {

					marker: {

						radius: 2

					},

					shadow: false,
					border: true,
					stacking: 'percent'
					

				}

		} else {

			

		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//var test = $.extend(true, options, {});
		//debugger
		
		
		
		
		
		
		
		

		Highcharts.visualize(table, options);
	});

});
</script>
  
   
  
        
       <script language="JavaScript" type="text/JavaScript">
      
      $(document).ready(function () {

      	$("#highchartTableShow262820").click(function () {
      		$("#262820datatable").slideToggle(1000);

      		var $span = $(this).find('#buttonText262820');

      		if ($span.text() == "Show chart data") {
      			$span.text("Hide chart data");
      		} else {
      			$span.text("Show chart data");
      		}

      	});
      });
         

  
</script>
                      
<a name="d.en.262834"></a>
<p><strong>Confirmed Cases</strong></p>
<p>For the week ending 11 December, the number of weekly cases was 1,694, a decrease of 243 from the previous week. This was the third week since the beginning of September where less than 2,000 confirmed cases were recorded. The total number of confirmed cases to date is 76,279.</p>
<p>Dublin accounted for more than a fifth (472) of all new cases for the week ending 11 December and it was the sixth week in a row that Dublin had less than 1,000 weekly cases since the beginning of September. Donegal was the county with the second highest number of new cases at 156 cases, for the week ending 11 December.</p>
<p>The median age of new confirmed COVID-19 cases was 33 years old for the week ending 11 December. The median age for all cases is 39 years old, Galway has the lowest median age at 26 while Wicklow is highest at 44.</p>
<p>In the week ending 11 December, 181 confirmed cases were among health care workers.</p>
<p>Since the start of the pandemic, some 4,267 more females were diagnosed with COVID-19 than males and more than half (55%) of all confirmed cases have been linked to an outbreak.&nbsp;</p>
<p>The 25-44 age group still showed the highest number of confirmed COVID-19 cases at 24,762, however the percentage of cases in the 65-79 and 80+ age categories has been increasing in recent weeks. These age groups made up 10% of cases in the week ending 11 December up from less than 5% in week ending 07 August.</p>
<p><strong>Hospitalisations</strong></p>
<p>Table 6 shows weekly hospitalisations and admission to Intensive Care Units (ICU). These are dated using the epidemiological date of infection and so can be compared with confirmed cases. The peak week for admissions to hospitals was the week ending 27 March when 688 of the 3,428 cases were admitted to hospital, a further 95 of these were admitted to ICU.&nbsp;In comparison, of the 1,694 confirmed cases in the week ending 11 December, 57 were admitted to hospital and five people to ICU.</p>
<p>Figure 2 shows monthly Hospitalisation, Mortality and ICU Admission rates (per 1,000 confirmed cases). As cases in older groups have increased in recent weeks, the hospitalisation rate rose to 64 in November. The overall ICU admission rate was eight per 1,000 confirmed cases. (Note: It is important to note that there is a time lag between onset of symptoms and hospital admission. Also note that November rates are provisional).</p>
 <style>
 .highcharts-tooltip {
    z-index: 9998;

}

   .tooltip {
   /*padding:10px;*/
   background-color:white;
}
   
.highcharts-tooltip span {
    background-color:white;
    
    opacity:1;
    z-index:9999!important;
} 
   
</style>

<div style="display: none" id="262830stacking">null</div>
<div style="clear: both"></div>



    
    <div id="highchartDiv262830" class="highchartBox" data-highcharts-chart="1" style="overflow: hidden;"><div id="highcharts-dutyqdt-81" dir="ltr" class="highcharts-container " style="position: relative; overflow: hidden; width: 1146px; height: 400px; text-align: left; line-height: normal; z-index: 0; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); user-select: none;"><svg version="1.1" class="highcharts-root" style="font-family:&quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif;font-size:12px;" xmlns="http://www.w3.org/2000/svg" width="1146" height="400" viewBox="0 0 1146 400"><desc>Created with Highcharts 8.2.2</desc><defs><clippath id="highcharts-dutyqdt-82-"><rect x="0" y="0" width="1032" height="253" fill="none"></rect></clippath></defs><rect fill="#ffffff" class="highcharts-background" x="0" y="0" width="1146" height="400" rx="0" ry="0"></rect><rect fill="none" class="highcharts-plot-background" x="64" y="76" width="1032" height="253"></rect><g class="highcharts-pane-group" data-z-index="0"></g><g class="highcharts-plot-lines-0" data-z-index="0"><path fill="none" class="highcharts-plot-line "></path></g><g class="highcharts-grid highcharts-xaxis-grid" data-z-index="1"><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 178.5 76 L 178.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 292.5 76 L 292.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 407.5 76 L 407.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 522.5 76 L 522.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 636.5 76 L 636.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 751.5 76 L 751.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 866.5 76 L 866.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 980.5 76 L 980.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 1095.5 76 L 1095.5 329" opacity="1"></path><path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 63.5 76 L 63.5 329" opacity="1"></path></g><g class="highcharts-grid highcharts-yaxis-grid" data-z-index="1"><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 64 329.5 L 1096 329.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 64 278.5 L 1096 278.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 64 228.5 L 1096 228.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 64 177.5 L 1096 177.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 64 127.5 L 1096 127.5" opacity="1"></path><path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 64 75.5 L 1096 75.5" opacity="1"></path></g><rect fill="none" class="highcharts-plot-border" data-z-index="1" x="64" y="76" width="1032" height="253"></rect><g class="highcharts-axis highcharts-xaxis" data-z-index="2"><path fill="none" class="highcharts-axis-line" stroke="#ccd6eb" stroke-width="1" data-z-index="7" d="M 64 329.5 L 1096 329.5"></path></g><g class="highcharts-axis highcharts-yaxis" data-z-index="2"><path fill="none" class="highcharts-axis-line" data-z-index="7" d="M 64 76 L 64 329"></path></g><g class="highcharts-series-group" data-z-index="3"><g class="highcharts-series highcharts-series-0 highcharts-line-series highcharts-color-0" data-z-index="0.1" opacity="1" transform="translate(64,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-82-)"><path fill="none" d="M 57.333333333333 204.424 L 172 178.112 L 286.66666666667 210.496 L 401.33333333333 214.54399999999998 L 516 253 L 630.66666666667 247.94 L 745.33333333333 246.928 L 860 246.928 L 974.66666666667 240.856" class="highcharts-graph" data-z-index="1" stroke="#405482" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 57.333333333333 204.424 L 172 178.112 L 286.66666666667 210.496 L 401.33333333333 214.54399999999998 L 516 253 L 630.66666666667 247.94 L 745.33333333333 246.928 L 860 246.928 L 974.66666666667 240.856" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-0 highcharts-line-series highcharts-color-0 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(64,76) scale(1 1)"><path fill="#405482" d="M 57 206.424 A 2 2 0 1 1 57.001999999666666 206.4239990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 172 180.112 A 2 2 0 1 1 172.00199999966668 180.11199900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 286 212.496 A 2 2 0 1 1 286.0019999996667 212.4959990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 401 216.54399999999998 A 2 2 0 1 1 401.0019999996667 216.54399900000007 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 516 255 A 2 2 0 1 1 516.0019999996666 254.9999990000001 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 630 249.94 A 2 2 0 1 1 630.0019999996666 249.93999900000009 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 745 248.928 A 2 2 0 1 1 745.0019999996666 248.92799900000009 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 860 248.928 A 2 2 0 1 1 860.0019999996666 248.92799900000009 Z" opacity="1" class="highcharts-point highcharts-color-0"></path><path fill="#405482" d="M 974 242.856 A 2 2 0 1 1 974.0019999996666 242.85599900000008 Z" opacity="1" class="highcharts-point highcharts-color-0"></path></g><g class="highcharts-series highcharts-series-1 highcharts-line-series highcharts-color-1" data-z-index="0.1" opacity="1" transform="translate(64,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-82-)"><path fill="none" d="M 57.333333333333 58.696 L 172 109.29599999999999 L 286.66666666667 111.32 L 401.33333333333 130.548 L 516 189.244 L 630.66666666667 213.53199999999998 L 745.33333333333 204.424 L 860 216.56799999999998 L 974.66666666667 188.232" class="highcharts-graph" data-z-index="1" stroke="#00af86" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 57.333333333333 58.696 L 172 109.29599999999999 L 286.66666666667 111.32 L 401.33333333333 130.548 L 516 189.244 L 630.66666666667 213.53199999999998 L 745.33333333333 204.424 L 860 216.56799999999998 L 974.66666666667 188.232" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-1 highcharts-line-series highcharts-color-1 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(64,76) scale(1 1)"><path fill="#00af86" d="M 57 56.696 L 59 58.696 L 57 60.696 L 55 58.696 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 172 107.29599999999999 L 174 109.29599999999999 L 172 111.29599999999999 L 170 109.29599999999999 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 286 109.32 L 288 111.32 L 286 113.32 L 284 111.32 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 401 128.548 L 403 130.548 L 401 132.548 L 399 130.548 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 516 187.244 L 518 189.244 L 516 191.244 L 514 189.244 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 630 211.53199999999998 L 632 213.53199999999998 L 630 215.53199999999998 L 628 213.53199999999998 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 745 202.424 L 747 204.424 L 745 206.424 L 743 204.424 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 860 214.56799999999998 L 862 216.56799999999998 L 860 218.56799999999998 L 858 216.56799999999998 Z" opacity="1" class="highcharts-point highcharts-color-1"></path><path fill="#00af86" d="M 974 186.232 L 976 188.232 L 974 190.232 L 972 188.232 Z" opacity="1" class="highcharts-point highcharts-color-1"></path></g><g class="highcharts-series highcharts-series-2 highcharts-line-series highcharts-color-2" data-z-index="0.1" opacity="1" transform="translate(64,76) scale(1 1)" clip-path="url(#highcharts-dutyqdt-82-)"><path fill="none" d="M 57.333333333333 224.664 L 172 241.868 L 286.66666666667 242.88 L 401.33333333333 253 L 516 253 L 630.66666666667 248.952 L 745.33333333333 247.94 L 860 248.952 L 974.66666666667 247.94" class="highcharts-graph" data-z-index="1" stroke="#fbaa34" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path><path fill="none" d="M 57.333333333333 224.664 L 172 241.868 L 286.66666666667 242.88 L 401.33333333333 253 L 516 253 L 630.66666666667 248.952 L 745.33333333333 247.94 L 860 248.952 L 974.66666666667 247.94" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path></g><g class="highcharts-markers highcharts-series-2 highcharts-line-series highcharts-color-2 highcharts-tracker" data-z-index="0.1" opacity="1" transform="translate(64,76) scale(1 1)"><path fill="#fbaa34" d="M 55 222.664 L 59 222.664 L 59 226.664 L 55 226.664 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 170 239.868 L 174 239.868 L 174 243.868 L 170 243.868 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 284 240.88 L 288 240.88 L 288 244.88 L 284 244.88 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 399 251 L 403 251 L 403 255 L 399 255 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 514 251 L 518 251 L 518 255 L 514 255 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 628 246.952 L 632 246.952 L 632 250.952 L 628 250.952 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 743 245.94 L 747 245.94 L 747 249.94 L 743 249.94 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 858 246.952 L 862 246.952 L 862 250.952 L 858 250.952 Z" opacity="1" class="highcharts-point highcharts-color-2"></path><path fill="#fbaa34" d="M 972 245.94 L 976 245.94 L 976 249.94 L 972 249.94 Z" opacity="1" class="highcharts-point highcharts-color-2"></path></g></g><g class="highcharts-exporting-group" data-z-index="3"><g class="highcharts-button highcharts-contextbutton" stroke-linecap="round" transform="translate(1112,10)"><rect fill="#ffffff" class="highcharts-button-box" x="0.5" y="0.5" width="24" height="22" rx="2" ry="2" stroke="none" stroke-width="1"></rect><title>Chart context menu</title><path fill="#666666" d="M 6 6.5 L 20 6.5 M 6 11.5 L 20 11.5 M 6 16.5 L 20 16.5" class="highcharts-button-symbol" data-z-index="1" stroke="#666666" stroke-width="3"></path><text x="0" data-z-index="1" y="12" style="color:#333333;cursor:pointer;font-weight:normal;fill:#333333;"></text></g></g><text x="10" text-anchor="start" class="highcharts-caption" data-z-index="4" style="color:#666666;fill:#666666;" y="397"></text><g class="highcharts-legend" data-z-index="7" transform="translate(384,361)"><rect fill="none" class="highcharts-legend-box" rx="0" ry="0" x="0" y="0" width="379" height="24" visibility="visible"></rect><g data-z-index="1"><g><g class="highcharts-legend-item highcharts-line-series highcharts-color-0 highcharts-series-0" data-z-index="1" transform="translate(8,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#405482" stroke-width="2"></path><path fill="#405482" d="M 8 13 A 2 2 0 1 1 8.001999999666667 12.999999000000084 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-1 highcharts-series-1" data-z-index="1" transform="translate(133,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#00af86" stroke-width="2"></path><path fill="#00af86" d="M 8 9 L 10 11 L 8 13 L 6 11 Z" class="highcharts-point" opacity="1"></path></g><g class="highcharts-legend-item highcharts-line-series highcharts-color-2 highcharts-series-2" data-z-index="1" transform="translate(297,3)"><path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#fbaa34" stroke-width="2"></path><path fill="#fbaa34" d="M 6 9 L 10 9 L 10 13 L 6 13 Z" class="highcharts-point" opacity="1"></path></g></g></g></g><g class="highcharts-axis-labels highcharts-xaxis-labels" data-z-index="7"><text x="121.33333333333667" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>March</tspan></text><text x="235.99999999999667" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>April</tspan></text><text x="350.6666666666667" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>May</tspan></text><text x="465.3333333333367" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>June</tspan></text><text x="579.9999999999966" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>July</tspan></text><text x="694.6666666666666" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>August</tspan></text><text x="809.3333333333367" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>September</tspan></text><text x="923.9999999999966" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>October</tspan></text><text x="1038.6666666666667" style="color:#666666;cursor:default;font-size:10px;use-h-t-m-l:true;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="347" opacity="1"><tspan>November</tspan></text></g><g class="highcharts-axis-labels highcharts-yaxis-labels" data-z-index="7"></g><text x="1136" class="highcharts-credits" text-anchor="end" data-z-index="8" style="cursor:context-menu;color:#999999;font-size:9px;fill:#999999;" y="395"><tspan>Source: CSO Ireland</tspan></text></svg><span class="highcharts-title" data-z-index="4" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 14px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 251.5px; top: 7px; color: rgb(51, 51, 51); text-align: center;">Figure 2 - Mortality, Hospitalisation and ICU Admission Rates (per 1,000 confirmed cases) by Month</span><span class="highcharts-subtitle" data-z-index="4" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 0px; top: 373px; color: rgb(102, 102, 102);"></span><div class="highcharts-legend" style="position: absolute; left: 384px; top: 361px; opacity: 1;"><div style="position: absolute; left: 0px; top: 0px; opacity: 1;"><div style="position: absolute; left: 0px; top: 0px; opacity: 1;"><div class="highcharts-legend-item highcharts-line-series highcharts-color-0 highcharts-series-0" style="position: absolute; left: 8px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">Mortality Rate</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-1 highcharts-series-1" style="position: absolute; left: 133px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">Hospitalisation Rate</span></div><div class="highcharts-legend-item highcharts-line-series highcharts-color-2 highcharts-series-2" style="position: absolute; left: 297px; top: 3px; opacity: 1;"><span data-z-index="2" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(51, 51, 51); cursor: pointer; font-weight: bold; text-overflow: ellipsis; overflow: hidden; margin-left: 0px; margin-top: 0px; left: 21px; top: 3px; fill: rgb(51, 51, 51);">ICU Rate</span></div></div></div></div><div class="highcharts-axis-labels highcharts-yaxis-labels" style="position: absolute; left: 0px; top: 0px; opacity: 1;"><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 44px; top: 323px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">0</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 38px; top: 272px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">50</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 222px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">100</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 171px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">150</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 121px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">200</span><span opacity="1" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 11px; white-space: nowrap; margin-left: 0px; margin-top: 0px; left: 33px; top: 70px; color: rgb(102, 102, 102); cursor: default; transform: rotate(0deg); transform-origin: 100% 11px; text-overflow: clip; opacity: 1;">250</span></div><div class="highcharts-axis highcharts-yaxis" style="position: absolute; left: 0px; top: 0px; opacity: 1;"><span data-z-index="7" class="highcharts-axis-title" style="position: absolute; font-family: &quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif; font-size: 12px; white-space: nowrap; color: rgb(102, 102, 102); margin-left: 0px; margin-top: 0px; transform: rotate(270deg); transform-origin: 50% 12px; left: -51px; top: 190.5px; visibility: inherit;">per 1,000 confirmed cases</span></div></div></div><div class="highchartTable" id="262830datatable">
 
   <!-- Livestock Survey December - LSD2012   FIG4  Created:  2020/8/13 14:45 -->
<td< tr=""></td<><table id="262830table"><thead><tr>
<th></th><td class="line">Mortality Rate</td><td class="line">Hospitalisation Rate</td><td class="line">ICU Rate</td></tr></thead><tbody>
<tr><th>March</th><td>48</td><td>192</td><td>28</td></tr>
<tr><th>April</th><td>74</td><td>142</td><td>11</td></tr>
<tr><th>May</th><td>42</td><td>140</td><td>10</td></tr>
<tr><th>June</th><td>38</td><td>121</td><td>0</td></tr>
<tr><th>July</th><td>0</td><td>63</td><td>0</td></tr>
<tr><th>August</th><td>5</td><td>39</td><td>4</td></tr>
<tr><th>September</th><td>6</td><td>48</td><td>5</td></tr>
<tr><th>October</th><td>6</td><td>36</td><td>4</td></tr>
<tr><th>November</th><td>12</td><td>64</td><td>5</td></tr>
</tbody></table>
 
     </div>
          
 

<div style="clear: both"></div>

<div class="highchartText">
 
</div>
 <div style="clear: both"></div>  





<script language="JavaScript" type="text/JavaScript">
$(function () {

	// On document ready, call visualize on the datatable.
	$(document).ready(function () {
		/**
		 * Visualize an HTML table using Highcharts. The top (horizontal) header
		 * is used for series names, and the left (vertical) header is used
		 * for category names. This function is based on jQuery.
		 * @param {Object} table The reference to the HTML table to visualize
		 * @param {Object} options Highcharts options
		 */

		$("#262830datatable table").attr('id', '262830table');

		Highcharts.visualize = function (table, options) {
			// the categories
			options.xAxis.categories = [];
			$('tbody th', table).each(function (i) {
				options.xAxis.categories.push(this.innerHTML);
			});

			Highcharts.setOptions({
				lang: {
					thousandsSep: ',',
					decimalPoint: '.',
					numericSymbols: ['k', ' million', ' billion', ' trillion']
				}
			});

			// the data series
			options.series = [];

			$('tr', table).each(function (i) {
				var tr = this;

				$('th, td', tr).each(function (j) {
					if (j > 0) { // skip first column
						if (i == 0) { // get the name and init the series
							options.series[j - 1] = {
								name: this.innerHTML,
								data: [],

								color: $(this).attr("color"),

								connectNulls: true,

								type: $(this).attr("class")
							};
						} else { // add values
							options.series[j - 1].data.push(parseFloat(this.innerHTML));

						}
					}
				});
			});

			var chart = new Highcharts.Chart(options);
		}

		

		var screenWidth = $(window).width();
		
		if (screenWidth < 800) {


		} else {

			
		}

		var table = document.getElementById('262830table');
		var credits = 'Source: CSO Ireland';

		if (credits == '') {
			credits = 'Source: CSO Ireland';
		} else {
			

		}
		
		var yAxisMax = null;
		var yAxisMaxStr = '';
		
		if(yAxisMaxStr.length > 0) {
			yAxisMax = parseInt(yAxisMaxStr);
		};



		options = {

			chart: {
  
  
  
  
  
  
  
  
  events: {
            beforePrint: function () {
                this.oldhasUserSize = this.hasUserSize;
                this.resetParams = [this.chartWidth, this.chartHeight, false];
                this.setSize(600, 400, false);
            },
            afterPrint: function () {
                this.setSize.apply(this, this.resetParams);
                this.hasUserSize = this.oldhasUserSize;
            }
        },

				renderTo: 'highchartDiv262830',

				zoomType: 'none',
				marginRight: 50,

				height:  400

			},

			subtitle: {
				text: '',
				x: -10,
				verticalAlign: 'bottom',
				y: 0,
				align: 'left',
				widthAdjust: -200,
				useHTML: true

			},

			credits: {
				text: credits,
				href: '',
				style: {
					cursor: 'context-menu'
				}

			},

			colors: [
				'#405482',
				'#00af86',
				'#fbaa34',
				'#3c5daa',				
				'#b7be34',
				'#0099b4',
				'#5b6670',
				'#ffc629',
				'#566db4',
				'#6ac5ad',
				'#FFCC66',
				'#6699CC'
			],

			title: {

				style: {
					fontSize: '14px',
					textAlign: 'center'
				},

				text: 'Figure 2 - Mortality, Hospitalisation and ICU Admission Rates (per 1,000 confirmed cases) by Month',
				useHTML: true,
				margin: 50
			},

			xAxis:
			{

				tickInterval:  0 ,

				labels: {

					 rotation: 0.0 ,

						style: {
						fontSize: '10px',
						width: 'auto',
						useHTML: true

					},
					
				}

			},

			plotOptions: {
				series: {

					marker: {

						radius: 2

					},

					shadow: false,
					border: true

				}
			},
			 

				tooltip: {

				useHTML: true,

				formatter: function () {

					function addCommas(nStr) {
						nStr += '';
						var x = nStr.split('.');
						var x1 = x[0];
						var x2 = x.length > 1 ? '.' + x[1] : '';
						var rgx = /(\d+)(\d{3})/;
						while (rgx.test(x1)) {
							x1 = x1.replace(rgx, '$1' + ',' + '$2');
						}
						return x1 + x2;
					}

					var numDecimals = Math.pow(10,  0 );
					var number = this.y;

					if (number >= 0) {

						return this.x + '</br>' + this.series.name + ': <b>' + addCommas(Math.round((this.y + 0.0000001) * numDecimals) / numDecimals) + ' per 1,000 confirmed cases</b>';

					} else {

						return this.x + '</br>' + this.series.name + ': <b>' + addCommas(Math.round((this.y - 0.0000001) * numDecimals) / numDecimals) + ' per 1,000 confirmed cases</b>';

					}

				}

			},
			legend: {useHTML: true},
			yAxis:
			{
				labels:{
					useHTML: true
				
				},
                useHTML: true,
				plotLines: [{

						 

					}
				],

				startOnTick: true,

				 

					max: yAxisMax,
					title: {
					text: 'per 1,000 confirmed cases',
                    useHTML: true
				}

			}
			

		};
		
			
		
		
		if ($("#262830stacking").text() == '') {	
			
			

			
			

		} else if ($("#262830stacking").text() == 'null') {

			

		} else if ($("#262830stacking").text() == 'normal') {

			options.plotOptions.series = {

					marker: {

						radius: 2

					},

					shadow: false,
					border: true,
					stacking: 'normal'
					

				}

		} else if ($("#262830stacking").text() == 'percent') {

			options.plotOptions.series = {

					marker: {

						radius: 2

					},

					shadow: false,
					border: true,
					stacking: 'percent'
					

				}

		} else {

			

		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//var test = $.extend(true, options, {});
		//debugger
		
		
		
		
		
		
		
		

		Highcharts.visualize(table, options);
	});

});
</script>
  
   
  
        
       <script language="JavaScript" type="text/JavaScript">
      
      $(document).ready(function () {

      	$("#highchartTableShow262830").click(function () {
      		$("#262830datatable").slideToggle(1000);

      		var $span = $(this).find('#buttonText262830');

      		if ($span.text() == "Show chart data") {
      			$span.text("Hide chart data");
      		} else {
      			$span.text("Show chart data");
      		}

      	});
      });
         

  
</script>
                      <div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262843_description">
    <span id="#262843_openClose">Show Table</span>: Table A: COVID-19 Mortality, Hospitalisation and Intensive Care Unit (ICU) admission rates (per 1,000 confirmed cases) by Month
  </div>

<div style="clear: both"></div>

<div id="262843_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262843-insertexceltable">
<div id="table-262843-1-insertexceltable">
<table class="excel-262843-media-t1">
<colgroup>
<col width="296">
<col width="97">
<col width="97">
<col width="97">
<col width="97">
<col width="97">
<col width="97">
<col width="97">
<col width="97">
<col width="97">
<col width="70">
</colgroup>
<tbody>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c1" colspan="11">Table A: COVID-19  Mortality, Hospitalisation and Intensive Care Unit (ICU) admission rates (per 1,000 confirmed cases) by Month</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c1">&nbsp;</td><td class="excel-262843-media-c2" colspan="10">All cases</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c1">&nbsp;</td><td class="excel-262843-media-c2" colspan="10">Month</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c3">&nbsp;</td><td class="excel-262843-media-c4">March</td><td class="excel-262843-media-c4">April</td><td class="excel-262843-media-c4">May</td><td class="excel-262843-media-c4">June</td><td class="excel-262843-media-c4">July</td><td class="excel-262843-media-c4">August</td><td class="excel-262843-media-c4">September</td><td class="excel-262843-media-c4">October</td><td class="excel-262843-media-c5">November*</td><td class="excel-262843-media-c4">All</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c6">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c9">Mortality Rate</td><td class="excel-262843-media-c7">48</td><td class="excel-262843-media-c7">74</td><td class="excel-262843-media-c7">42</td><td class="excel-262843-media-c7">38</td><td class="excel-262843-media-c7">..</td><td class="excel-262843-media-c7">5</td><td class="excel-262843-media-c7">6</td><td class="excel-262843-media-c7">6</td><td class="excel-262843-media-c7">12</td><td class="excel-262843-media-c7">24</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c9">Hospitalisation Rate</td><td class="excel-262843-media-c7">192</td><td class="excel-262843-media-c7">142</td><td class="excel-262843-media-c7">140</td><td class="excel-262843-media-c7">121</td><td class="excel-262843-media-c7">63</td><td class="excel-262843-media-c7">39</td><td class="excel-262843-media-c7">48</td><td class="excel-262843-media-c7">36</td><td class="excel-262843-media-c7">64</td><td class="excel-262843-media-c7">82</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c9">Intensive Care Unit (ICU) Rate</td><td class="excel-262843-media-c7">28</td><td class="excel-262843-media-c7">11</td><td class="excel-262843-media-c7">10</td><td class="excel-262843-media-c7">..</td><td class="excel-262843-media-c7">..</td><td class="excel-262843-media-c7">4</td><td class="excel-262843-media-c7">5</td><td class="excel-262843-media-c7">4</td><td class="excel-262843-media-c7">5</td><td class="excel-262843-media-c7">8</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c9">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c7">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td><td class="excel-262843-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c10" colspan="11">* latest month is preliminary</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c9" colspan="11"><sup>1 </sup>Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to 30th November 2020 and is subject to revision</td>
</tr>
<tr class="excel-262843-media-r1">
<td class="excel-262843-media-c9" colspan="11"><sup>2 </sup>Cases defined by epidemiological date which is the earliest of onset date, date of diagnosis, laboratory specimen collection date, laboratory received date, laboratory reported date and event creation/notification date</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBLA.xlsx">COVID-19 Deaths and Cases Series 18 - Table A (XLS 11KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262843_description").click(function(){
    $("#262843_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262843_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script>
<a name="d.en.262821"></a>
<p><strong>Deaths</strong></p>
<p>The results produced by the CSO in Table 2 are based on the&nbsp;<em>Actual Date of Death</em>. Using this method, the CSO has found that the number of people who have died from COVID-19 has been greater than 20 for each of the last nine weeks and Dublin continues to be the worst hit.</p>
<p>Since the start of the pandemic, the total number of people who have died from COVID-19 in Ireland is 1,862, with a further 258 deaths cited as probable deaths linked to the virus. For the week ending 11 December, 22 deaths were recorded.</p>
<p>The virus claimed the lives of 88 more men than women up to and including the week ending 11 December. It also continues to impact the older age groups the hardest, with 64% of all confirmed COVID-19 deaths to date in the 80 years old or older age group.</p>
<p>From Table A we can see the overall mortality rate is 24 per 1,000 confirmed cases, this was highest in April at 74 per 1,000 confirmed cases. The mortality rate was 12 per 1,000 in November, up from 6 in October. (Note: These figures may need to be revised as there is a time lag between onset of symptoms and death.)</p>
<p><strong>Outbreaks</strong></p>
<p>Since the start of the pandemic, there have been 42,163 positive COVID-19 cases linked to an outbreak, which is defined as two or more cases in the same location and time. Women account for 51% of all cases linked to an outbreak.</p>
<p>The median age of confirmed cases related to an outbreak is 40.</p>
<p>Donegal and Mayo&nbsp;made up 30% of all cases linked to an outbreak for the week ending 11 December.</p>
<p>Outbreaks in hospitals accounted for 14% of cases, and nursing homes for 9% of cases linked to an outbreak in November and December, up from 2% and 5% of cases linked to an outbreak in September and October.</p>
<p><strong>Underlying Conditions</strong></p>
<p>Since the start of the pandemic, there have been 1,739 deaths of people with underlying conditions from 19,653 confirmed cases with underlying conditions. The median age of those dying with underlying conditions is 83.</p>
<p>There were 1,617 deaths of people with underlying conditions in the over 65 age group. Of the 131 deaths in the 25-64 age group, 121 had underlying conditions.</p>
<p>In terms of underlying conditions, chronic heart disease was present in 44% of deaths.</p>

<a name="d.en.262831"></a>
<p>For further COVID-19 related information go to the CSO <a href="https://www.cso.ie/en/releasesandpublications/ep/p-covid19/covid-19informationhub/">COVID-19 Information Hub</a></p>
<div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262842_description">
    <span id="#262842_openClose">Show Table</span>: Table 1 Profile of COVID-19 Deaths and Cases up to and including Friday December 11 2020
  </div>

<div style="clear: both"></div>

<div id="262842_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262842-insertexceltable">
<div id="table-262842-1-insertexceltable">
<table class="excel-262842-media-t1">
<colgroup>
<col width="257">
<col width="115">
<col width="12">
<col width="115">
<col width="115">
<col width="12">
<col width="115">
</colgroup>
<tbody>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c1" colspan="7">Table 1: Profile of COVID-19 Deaths and Cases up to and including Friday December 11 2020 <b><sup>1, 5</sup></b></td>
</tr>
<tr class="excel-262842-media-r2">
<td class="excel-262842-media-c2">&nbsp;</td><td class="excel-262842-media-c3">Total Deaths <b><sup>2</sup></b></td><td class="excel-262842-media-c4">&nbsp;</td><td class="excel-262842-media-c4">Median Age of Deaths</td><td class="excel-262842-media-c4">Total Cases <b><sup>3</sup></b></td><td class="excel-262842-media-c4">&nbsp;</td><td class="excel-262842-media-c4">Median Age of Cases</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5">Total</td><td class="excel-262842-media-c6">2,120</td><td class="excel-262842-media-c6">&nbsp;</td><td class="excel-262842-media-c6">&nbsp;</td><td class="excel-262842-media-c6">76,279</td><td class="excel-262842-media-c6">&nbsp;</td><td class="excel-262842-media-c6">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Confirmed cases</td><td class="excel-262842-media-c8">1,862</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">83</td><td class="excel-262842-media-c8">76,279</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Probable cases <sup>4</sup></td><td class="excel-262842-media-c8">258</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">0</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">0</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5" colspan="7">Profile of the confirmed cases follows:</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5">Sex</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Female</td><td class="excel-262842-media-c8">887</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">85</td><td class="excel-262842-media-c8">40,255</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Male</td><td class="excel-262842-media-c8">975</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">81</td><td class="excel-262842-media-c8">35,988</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">38</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Not Specified</td><td class="excel-262842-media-c8">0</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">0</td><td class="excel-262842-media-c8">36</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">28</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5">Age</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">0-14</td><td class="excel-262842-media-c8">0</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">0</td><td class="excel-262842-media-c8">7,136</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">8</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">15-24</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">13,266</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">20</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">25-44</td><td class="excel-262842-media-c8">17</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">36</td><td class="excel-262842-media-c8">24,762</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">34</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">45-64</td><td class="excel-262842-media-c8">114</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">58</td><td class="excel-262842-media-c8">19,610</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">53</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">65-79</td><td class="excel-262842-media-c8">532</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">74</td><td class="excel-262842-media-c8">6,166</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">72</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">80+</td><td class="excel-262842-media-c8">1,197</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">87</td><td class="excel-262842-media-c8">5,311</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">86</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Not Specified</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">28</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">0</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5">County</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Carlow</td><td class="excel-262842-media-c8">19</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">81</td><td class="excel-262842-media-c8">691</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">43</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Cavan</td><td class="excel-262842-media-c8">53</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">84</td><td class="excel-262842-media-c8">2,269</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Clare</td><td class="excel-262842-media-c8">45</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">82</td><td class="excel-262842-media-c8">1,528</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">38</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Cork</td><td class="excel-262842-media-c8">76</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">84</td><td class="excel-262842-media-c8">6,527</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">35</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Donegal</td><td class="excel-262842-media-c8">62</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">84</td><td class="excel-262842-media-c8">3,324</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Dublin</td><td class="excel-262842-media-c8">868</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">83</td><td class="excel-262842-media-c8">28,239</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Galway</td><td class="excel-262842-media-c8">20</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">83</td><td class="excel-262842-media-c8">2,805</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">26</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Kerry</td><td class="excel-262842-media-c8">20</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">84</td><td class="excel-262842-media-c8">1,370</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">38</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Kildare</td><td class="excel-262842-media-c8">171</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">82</td><td class="excel-262842-media-c8">4,203</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">41</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Kilkenny</td><td class="excel-262842-media-c8">23</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">80</td><td class="excel-262842-media-c8">1,234</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Laois</td><td class="excel-262842-media-c8">28</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">77</td><td class="excel-262842-media-c8">1,065</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">40</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Leitrim</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">273</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">38</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Limerick</td><td class="excel-262842-media-c8">37</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">80</td><td class="excel-262842-media-c8">3,007</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">33</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Longford</td><td class="excel-262842-media-c8">8</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">85</td><td class="excel-262842-media-c8">686</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">37</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Louth</td><td class="excel-262842-media-c8">58</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">83</td><td class="excel-262842-media-c8">2,355</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">41</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Mayo</td><td class="excel-262842-media-c8">52</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">82</td><td class="excel-262842-media-c8">1,577</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">43</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Meath</td><td class="excel-262842-media-c8">66</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">81</td><td class="excel-262842-media-c8">3,503</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Monaghan</td><td class="excel-262842-media-c8">58</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">85</td><td class="excel-262842-media-c8">1,319</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">41</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Offaly</td><td class="excel-262842-media-c8">21</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">81</td><td class="excel-262842-media-c8">1,214</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">40</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Roscommon</td><td class="excel-262842-media-c8">18</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">89</td><td class="excel-262842-media-c8">978</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">40</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Sligo</td><td class="excel-262842-media-c8">7</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">85</td><td class="excel-262842-media-c8">781</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">34</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Tipperary</td><td class="excel-262842-media-c8">31</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">89</td><td class="excel-262842-media-c8">1,649</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Waterford</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">..</td><td class="excel-262842-media-c8">1,125</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">37</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Westmeath</td><td class="excel-262842-media-c8">34</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">85</td><td class="excel-262842-media-c8">1,602</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Wexford</td><td class="excel-262842-media-c8">28</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">80</td><td class="excel-262842-media-c8">1,265</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">38</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Wicklow</td><td class="excel-262842-media-c8">52</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">81</td><td class="excel-262842-media-c8">1,690</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">44</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5">Health Care Worker (HCW)</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Yes</td><td class="excel-262842-media-c8">7</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">51</td><td class="excel-262842-media-c8">12,485</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">40</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">No</td><td class="excel-262842-media-c8">1,780</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">83</td><td class="excel-262842-media-c8">54,180</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">37</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Not Specified</td><td class="excel-262842-media-c8">75</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">59</td><td class="excel-262842-media-c8">9,614</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">39</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5">Related to Outbreak</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Yes </td><td class="excel-262842-media-c8">1,382</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">84</td><td class="excel-262842-media-c8">42,163</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">40</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">No</td><td class="excel-262842-media-c8">480</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">78</td><td class="excel-262842-media-c8">34,116</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">38</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c5">Underlying Condition</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">Yes</td><td class="excel-262842-media-c8">1,739</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">83</td><td class="excel-262842-media-c8">19,653</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">54</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7">No</td><td class="excel-262842-media-c8">50</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">84</td><td class="excel-262842-media-c8">44,349</td><td class="excel-262842-media-c8">&nbsp;</td><td class="excel-262842-media-c8">32</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c9">Not Specified</td><td class="excel-262842-media-c10">73</td><td class="excel-262842-media-c10">&nbsp;</td><td class="excel-262842-media-c10">83</td><td class="excel-262842-media-c10">12,277</td><td class="excel-262842-media-c10">&nbsp;</td><td class="excel-262842-media-c10">43</td>
</tr>
<tr class="excel-262842-media-r2">
<td class="excel-262842-media-c11" colspan="7"><sup>1 </sup>Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7" colspan="7"><sup>2 </sup>Data is defined by date of death.</td>
</tr>
<tr class="excel-262842-media-r3">
<td class="excel-262842-media-c7" colspan="7"><sup>3 </sup>Data is defined by epidemiological date which is the earliest of onset date, date of diagnosis, laboratory specimen collection date, laboratory received date, laboratory reported date and event creation/notification date.</td>
</tr>
<tr class="excel-262842-media-r4">
<td class="excel-262842-media-c7" colspan="7"><sup>4 </sup>Probable deaths are still awaiting validation so further details are not available. This involves cases that may be waiting for lab confirmation etc. Probable deaths may be reclassified as confirmed deaths or denotified at a later date. </td>
</tr>
<tr class="excel-262842-media-r1">
<td class="excel-262842-media-c7" colspan="7"><sup>5</sup> '..' Indicates a cell number &lt; 5 or a cell number &lt; 5 can be identified.</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBL1.xlsx">COVID-19 Deaths and Cases Series 18 - Table 1 (XLS 14KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262842_description").click(function(){
    $("#262842_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262842_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262835_description">
    <span id="#262835_openClose">Show Table</span>: Table 2 &amp; 2A Weekly Profile of COVID-19 Confirmed Deaths
  </div>

<div style="clear: both"></div>

<div id="262835_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262835-insertexceltable">
<div id="table-262835-1-insertexceltable">
<table class="excel-262835-media-t1">
<colgroup>
<col width="162">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="69">
</colgroup>
<tbody>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c1" colspan="15">Table 2: Weekly Profile of COVID-19 Confirmed Deaths <b><sup>1,3</sup></b></td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c2">&nbsp;</td><td class="excel-262835-media-c3" colspan="14">2020</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c4">&nbsp;</td><td class="excel-262835-media-c5">11/09</td><td class="excel-262835-media-c5">18/09</td><td class="excel-262835-media-c5">25/09</td><td class="excel-262835-media-c5">02/10</td><td class="excel-262835-media-c5">09/10</td><td class="excel-262835-media-c5">16/10</td><td class="excel-262835-media-c5">23/10</td><td class="excel-262835-media-c5">30/10</td><td class="excel-262835-media-c5">06/11</td><td class="excel-262835-media-c5">13/11</td><td class="excel-262835-media-c5">20/11</td><td class="excel-262835-media-c5">27/11</td><td class="excel-262835-media-c5">04/12</td><td class="excel-262835-media-c5">11/12*</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Total</td><td class="excel-262835-media-c7">13</td><td class="excel-262835-media-c8">11</td><td class="excel-262835-media-c8">11</td><td class="excel-262835-media-c8">10</td><td class="excel-262835-media-c8">18</td><td class="excel-262835-media-c8">27</td><td class="excel-262835-media-c8">28</td><td class="excel-262835-media-c8">37</td><td class="excel-262835-media-c8">33</td><td class="excel-262835-media-c8">33</td><td class="excel-262835-media-c7">40</td><td class="excel-262835-media-c7">35</td><td class="excel-262835-media-c7">30</td><td class="excel-262835-media-c9">22</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c12">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c13">&nbsp;</td><td class="excel-262835-media-c12">&nbsp;</td><td class="excel-262835-media-c14">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c11">&nbsp;</td><td class="excel-262835-media-c14">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Sex</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Female</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">12</td><td class="excel-262835-media-c15">13</td><td class="excel-262835-media-c15">15</td><td class="excel-262835-media-c15">9</td><td class="excel-262835-media-c15">16</td><td class="excel-262835-media-c15">18</td><td class="excel-262835-media-c15">17</td><td class="excel-262835-media-c15">11</td><td class="excel-262835-media-c16">11</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Male</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">15</td><td class="excel-262835-media-c15">15</td><td class="excel-262835-media-c15">22</td><td class="excel-262835-media-c15">24</td><td class="excel-262835-media-c15">17</td><td class="excel-262835-media-c15">22</td><td class="excel-262835-media-c15">18</td><td class="excel-262835-media-c15">19</td><td class="excel-262835-media-c16">11</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Age</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">0-14</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">15-24</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">25-44</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">45-64</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">65-79</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">13</td><td class="excel-262835-media-c15">11</td><td class="excel-262835-media-c15">11</td><td class="excel-262835-media-c15">9</td><td class="excel-262835-media-c15">14</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">80+</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">15</td><td class="excel-262835-media-c15">20</td><td class="excel-262835-media-c15">22</td><td class="excel-262835-media-c15">21</td><td class="excel-262835-media-c15">21</td><td class="excel-262835-media-c15">30</td><td class="excel-262835-media-c15">19</td><td class="excel-262835-media-c15">21</td><td class="excel-262835-media-c16">16</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Not Specified</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Median Age </td><td class="excel-262835-media-c15">81</td><td class="excel-262835-media-c15">78</td><td class="excel-262835-media-c15">65</td><td class="excel-262835-media-c15">78</td><td class="excel-262835-media-c15">80</td><td class="excel-262835-media-c15">80</td><td class="excel-262835-media-c15">85</td><td class="excel-262835-media-c15">81</td><td class="excel-262835-media-c15">84</td><td class="excel-262835-media-c15">82</td><td class="excel-262835-media-c15">84</td><td class="excel-262835-media-c15">80</td><td class="excel-262835-media-c15">83</td><td class="excel-262835-media-c16">84</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c17">&nbsp;</td><td></td><td></td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">County</td><td class="excel-262835-media-c17">&nbsp;</td><td></td><td></td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Carlow</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Cavan</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Clare</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Cork</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Donegal</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">6</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Dublin</td><td class="excel-262835-media-c15">6</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">11</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">11</td><td class="excel-262835-media-c15">9</td><td class="excel-262835-media-c16">9</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Galway</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Kerry</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Kildare</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Kilkenny</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Laois</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Leitrim</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Limerick</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Longford</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Louth</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Mayo</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Meath</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Monaghan</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Offaly</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Roscommon</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Sligo</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Tipperary</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Waterford</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Westmeath</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Wexford</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Wicklow</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Health Care Worker (HCW)</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Yes</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c15">0</td><td class="excel-262835-media-c16">0</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">No</td><td class="excel-262835-media-c15">11</td><td class="excel-262835-media-c15">10</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">13</td><td class="excel-262835-media-c15">18</td><td class="excel-262835-media-c15">20</td><td class="excel-262835-media-c15">30</td><td class="excel-262835-media-c15">27</td><td class="excel-262835-media-c15">29</td><td class="excel-262835-media-c15">35</td><td class="excel-262835-media-c15">32</td><td class="excel-262835-media-c15">22</td><td class="excel-262835-media-c16">20</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Not Specified</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">6</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Related to Outbreak</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Yes </td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">9</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">13</td><td class="excel-262835-media-c15">20</td><td class="excel-262835-media-c15">22</td><td class="excel-262835-media-c15">29</td><td class="excel-262835-media-c15">26</td><td class="excel-262835-media-c15">29</td><td class="excel-262835-media-c15">32</td><td class="excel-262835-media-c15">29</td><td class="excel-262835-media-c15">23</td><td class="excel-262835-media-c16">14</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Not Specified</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">5</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">6</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">4</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">6</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c16">8</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c18">&nbsp;</td><td class="excel-262835-media-c19">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Underlying Condition</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c9">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c7">&nbsp;</td><td class="excel-262835-media-c9">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Yes</td><td class="excel-262835-media-c15">9</td><td class="excel-262835-media-c15">8</td><td class="excel-262835-media-c15">9</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">12</td><td class="excel-262835-media-c15">22</td><td class="excel-262835-media-c15">26</td><td class="excel-262835-media-c15">25</td><td class="excel-262835-media-c15">26</td><td class="excel-262835-media-c15">27</td><td class="excel-262835-media-c15">33</td><td class="excel-262835-media-c15">33</td><td class="excel-262835-media-c15">21</td><td class="excel-262835-media-c16">16</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">No</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">7</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c15">..</td><td class="excel-262835-media-c16">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c20">Not Specified</td><td class="excel-262835-media-c21">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">5</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c22">..</td><td class="excel-262835-media-c21">..</td>
</tr>
<tr class="excel-262835-media-r1">
<td></td><td></td><td></td><td class="excel-262835-media-c2">&nbsp;</td><td></td><td></td><td></td><td class="excel-262835-media-c2">&nbsp;</td><td></td><td></td><td></td><td class="excel-262835-media-c2">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c1" colspan="16">Table 2A: Weekly Profile of Cumulative COVID-19 Confirmed Deaths (%) <b><sup>1,3</sup></b></td>
</tr>
<tr class="excel-262835-media-r1">
<td></td><td class="excel-262835-media-c23" colspan="15">2020</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c4">&nbsp;</td><td class="excel-262835-media-c5">11/09</td><td class="excel-262835-media-c5">18/09</td><td class="excel-262835-media-c5">25/09</td><td class="excel-262835-media-c5">02/10</td><td class="excel-262835-media-c5">09/10</td><td class="excel-262835-media-c5">16/10</td><td class="excel-262835-media-c5">23/10</td><td class="excel-262835-media-c5">30/10</td><td class="excel-262835-media-c5">06/11</td><td class="excel-262835-media-c5">13/11</td><td class="excel-262835-media-c5">20/11</td><td class="excel-262835-media-c5">27/11</td><td class="excel-262835-media-c5">04/12</td><td class="excel-262835-media-c5">11/12*</td><td class="excel-262835-media-c5">% Gen Pop<b><sup>5</sup></b></td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Sex</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Female</td><td class="excel-262835-media-c15">49%</td><td class="excel-262835-media-c15">49%</td><td class="excel-262835-media-c15">49%</td><td class="excel-262835-media-c15">49%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c16">48%</td><td class="excel-262835-media-c7">51%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Male</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c15">52%</td><td class="excel-262835-media-c16">52%</td><td class="excel-262835-media-c7">49%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Age</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">0-14</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c16">0%</td><td class="excel-262835-media-c7">21%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">15-24</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c16">0%</td><td class="excel-262835-media-c7">12%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">25-44</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c16">1%</td><td class="excel-262835-media-c7">30%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">45-64</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">7%</td><td class="excel-262835-media-c15">6%</td><td class="excel-262835-media-c15">6%</td><td class="excel-262835-media-c15">6%</td><td class="excel-262835-media-c16">6%</td><td class="excel-262835-media-c7">24%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">65-79</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">28%</td><td class="excel-262835-media-c15">29%</td><td class="excel-262835-media-c15">29%</td><td class="excel-262835-media-c15">29%</td><td class="excel-262835-media-c16">29%</td><td class="excel-262835-media-c7">10%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">80+</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c15">64%</td><td class="excel-262835-media-c16">64%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">County</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Carlow</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c16">1%</td><td class="excel-262835-media-c7">1%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Cavan</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c16">3%</td><td class="excel-262835-media-c7">2%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Clare</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c16">2%</td><td class="excel-262835-media-c7">2%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Cork</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c16">4%</td><td class="excel-262835-media-c7">12%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Donegal</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c16">3%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Dublin</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">51%</td><td class="excel-262835-media-c15">50%</td><td class="excel-262835-media-c15">50%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">48%</td><td class="excel-262835-media-c15">47%</td><td class="excel-262835-media-c15">47%</td><td class="excel-262835-media-c15">47%</td><td class="excel-262835-media-c16">47%</td><td class="excel-262835-media-c7">28%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Galway</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c16">1%</td><td class="excel-262835-media-c7">6%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Kerry</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c16">1%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Kildare</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c15">9%</td><td class="excel-262835-media-c16">9%</td><td class="excel-262835-media-c7">5%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Kilkenny</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c16">1%</td><td class="excel-262835-media-c7">2%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Laois</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c16">2%</td><td class="excel-262835-media-c7">2%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Leitrim</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c16">0%</td><td class="excel-262835-media-c7">1%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Limerick</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c16">2%</td><td class="excel-262835-media-c7">4%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Longford</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c16">0%</td><td class="excel-262835-media-c7">1%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Louth</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c16">3%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Mayo</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c16">3%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Meath</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c16">4%</td><td class="excel-262835-media-c7">4%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Monaghan</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c16">3%</td><td class="excel-262835-media-c7">1%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Offaly</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c16">1%</td><td class="excel-262835-media-c7">2%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Roscommon</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c16">1%</td><td class="excel-262835-media-c7">1%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Sligo</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c16">0%</td><td class="excel-262835-media-c7">1%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Tipperary</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c16">2%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Waterford</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c16">0%</td><td class="excel-262835-media-c7">2%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Westmeath</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c16">2%</td><td class="excel-262835-media-c7">2%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Wexford</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">1%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c16">2%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Wicklow</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c16">3%</td><td class="excel-262835-media-c7">3%</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Health Care Worker (HCW)</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Yes</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c15">0%</td><td class="excel-262835-media-c16">0%</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">No</td><td class="excel-262835-media-c15">98%</td><td class="excel-262835-media-c15">98%</td><td class="excel-262835-media-c15">98%</td><td class="excel-262835-media-c15">98%</td><td class="excel-262835-media-c15">97%</td><td class="excel-262835-media-c15">97%</td><td class="excel-262835-media-c15">96%</td><td class="excel-262835-media-c15">96%</td><td class="excel-262835-media-c15">96%</td><td class="excel-262835-media-c15">96%</td><td class="excel-262835-media-c15">96%</td><td class="excel-262835-media-c15">96%</td><td class="excel-262835-media-c15">96%</td><td class="excel-262835-media-c16">96%</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Not Specified</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c15">4%</td><td class="excel-262835-media-c16">4%</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Related to Outbreak</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Yes </td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">73%</td><td class="excel-262835-media-c15">74%</td><td class="excel-262835-media-c15">74%</td><td class="excel-262835-media-c15">74%</td><td class="excel-262835-media-c15">74%</td><td class="excel-262835-media-c15">74%</td><td class="excel-262835-media-c16">74%</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Not Specified</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">27%</td><td class="excel-262835-media-c15">26%</td><td class="excel-262835-media-c15">26%</td><td class="excel-262835-media-c15">26%</td><td class="excel-262835-media-c15">26%</td><td class="excel-262835-media-c15">26%</td><td class="excel-262835-media-c16">26%</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c6">Underlying Condition</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c15">&nbsp;</td><td class="excel-262835-media-c16">&nbsp;</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">Yes</td><td class="excel-262835-media-c15">95%</td><td class="excel-262835-media-c15">95%</td><td class="excel-262835-media-c15">95%</td><td class="excel-262835-media-c15">95%</td><td class="excel-262835-media-c15">95%</td><td class="excel-262835-media-c15">95%</td><td class="excel-262835-media-c15">94%</td><td class="excel-262835-media-c15">94%</td><td class="excel-262835-media-c15">93%</td><td class="excel-262835-media-c15">94%</td><td class="excel-262835-media-c15">94%</td><td class="excel-262835-media-c15">94%</td><td class="excel-262835-media-c15">94%</td><td class="excel-262835-media-c16">94%</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10">No</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">2%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c15">3%</td><td class="excel-262835-media-c16">3%</td><td class="excel-262835-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c20">Not Specified</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">4%</td><td class="excel-262835-media-c22">4%</td><td class="excel-262835-media-c22">4%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c22">3%</td><td class="excel-262835-media-c21">3%</td><td class="excel-262835-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c24" colspan="16">* latest week is preliminary</td>
</tr>
<tr class="excel-262835-media-r2">
<td class="excel-262835-media-c10" colspan="16"><sup>1</sup> Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10" colspan="16"><sup>2 </sup>Data is defined by date of death in CIDR</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10" colspan="16"><sup>3</sup> '..' Indicates a cell number &lt; 5 or a cell number &lt; 5 can be identified</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10" colspan="16"><sup>4 </sup>Week ending 20/03/2020 includes all deaths up to that date, including previous weeks.</td>
</tr>
<tr class="excel-262835-media-r1">
<td class="excel-262835-media-c10" colspan="16"><sup>5</sup> General Population from Census 2016</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL2.xlsx">COVID-19 Deaths and Cases Series 18 - Table 2 (XLS 19KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262835_description").click(function(){
    $("#262835_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262835_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262832_description">
    <span id="#262832_openClose">Show Table</span>: Table 3 &amp; 3A Weekly Profile of COVID-19 Confirmed Cases
  </div>

<div style="clear: both"></div>

<div id="262832_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262832-insertexceltable">
<div id="table-262832-1-insertexceltable">
<table class="excel-262832-media-t1">
<colgroup>
<col width="147">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="74">
<col width="56">
</colgroup>
<tbody>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c1" colspan="15">Table 3: Weekly Profile of COVID-19 Confirmed Cases <b><sup>1,2,3,4</sup></b></td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c1">&nbsp;</td><td class="excel-262832-media-c2" colspan="14">2020</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c3">&nbsp;</td><td class="excel-262832-media-c4">11/09</td><td class="excel-262832-media-c4">18/09</td><td class="excel-262832-media-c4">25/09</td><td class="excel-262832-media-c4">02/10</td><td class="excel-262832-media-c4">09/10</td><td class="excel-262832-media-c4">16/10</td><td class="excel-262832-media-c4">23/10</td><td class="excel-262832-media-c4">30/10</td><td class="excel-262832-media-c4">06/11</td><td class="excel-262832-media-c4">13/11</td><td class="excel-262832-media-c4">20/11</td><td class="excel-262832-media-c4">27/11</td><td class="excel-262832-media-c4">04/12</td><td class="excel-262832-media-c4">11/12*</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Total</td><td class="excel-262832-media-c6">1,654</td><td class="excel-262832-media-c6">2,080</td><td class="excel-262832-media-c6">2,443</td><td class="excel-262832-media-c6">3,194</td><td class="excel-262832-media-c6">5,651</td><td class="excel-262832-media-c6">7,025</td><td class="excel-262832-media-c6">6,463</td><td class="excel-262832-media-c6">4,196</td><td class="excel-262832-media-c6">3,033</td><td class="excel-262832-media-c6">2,694</td><td class="excel-262832-media-c6">2,198</td><td class="excel-262832-media-c6">1,842</td><td class="excel-262832-media-c6">1,937</td><td class="excel-262832-media-c7">1,694</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Gender</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Female</td><td class="excel-262832-media-c10">844</td><td class="excel-262832-media-c10">1,058</td><td class="excel-262832-media-c10">1,216</td><td class="excel-262832-media-c10">1,608</td><td class="excel-262832-media-c10">2,729</td><td class="excel-262832-media-c10">3,622</td><td class="excel-262832-media-c10">3,282</td><td class="excel-262832-media-c10">2,160</td><td class="excel-262832-media-c10">1,583</td><td class="excel-262832-media-c10">1,416</td><td class="excel-262832-media-c10">1,124</td><td class="excel-262832-media-c10">920</td><td class="excel-262832-media-c10">994</td><td class="excel-262832-media-c11">878</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Male</td><td class="excel-262832-media-c10">807</td><td class="excel-262832-media-c10">1,022</td><td class="excel-262832-media-c10">1,227</td><td class="excel-262832-media-c10">1,584</td><td class="excel-262832-media-c10">2,922</td><td class="excel-262832-media-c10">3,399</td><td class="excel-262832-media-c10">3,180</td><td class="excel-262832-media-c10">2,030</td><td class="excel-262832-media-c10">1,448</td><td class="excel-262832-media-c10">1,276</td><td class="excel-262832-media-c10">1,073</td><td class="excel-262832-media-c10">915</td><td class="excel-262832-media-c10">940</td><td class="excel-262832-media-c11">813</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">7</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c11">..</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c12">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c7">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c7">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Age</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c13">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">0-14</td><td class="excel-262832-media-c10">220</td><td class="excel-262832-media-c10">227</td><td class="excel-262832-media-c10">240</td><td class="excel-262832-media-c10">278</td><td class="excel-262832-media-c10">505</td><td class="excel-262832-media-c10">904</td><td class="excel-262832-media-c10">913</td><td class="excel-262832-media-c10">682</td><td class="excel-262832-media-c10">426</td><td class="excel-262832-media-c10">394</td><td class="excel-262832-media-c10">344</td><td class="excel-262832-media-c10">302</td><td class="excel-262832-media-c10">339</td><td class="excel-262832-media-c11">294</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">15-24</td><td class="excel-262832-media-c10">364</td><td class="excel-262832-media-c10">490</td><td class="excel-262832-media-c10">608</td><td class="excel-262832-media-c10">790</td><td class="excel-262832-media-c10">1,627</td><td class="excel-262832-media-c10">1,806</td><td class="excel-262832-media-c10">1,497</td><td class="excel-262832-media-c10">818</td><td class="excel-262832-media-c10">533</td><td class="excel-262832-media-c10">470</td><td class="excel-262832-media-c10">483</td><td class="excel-262832-media-c10">320</td><td class="excel-262832-media-c10">268</td><td class="excel-262832-media-c11">287</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">25-44</td><td class="excel-262832-media-c10">535</td><td class="excel-262832-media-c10">661</td><td class="excel-262832-media-c10">785</td><td class="excel-262832-media-c10">1,073</td><td class="excel-262832-media-c10">1,783</td><td class="excel-262832-media-c10">2,089</td><td class="excel-262832-media-c10">1,856</td><td class="excel-262832-media-c10">1,227</td><td class="excel-262832-media-c10">950</td><td class="excel-262832-media-c10">840</td><td class="excel-262832-media-c10">664</td><td class="excel-262832-media-c10">565</td><td class="excel-262832-media-c10">593</td><td class="excel-262832-media-c11">566</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">45-64</td><td class="excel-262832-media-c10">378</td><td class="excel-262832-media-c10">474</td><td class="excel-262832-media-c10">595</td><td class="excel-262832-media-c10">757</td><td class="excel-262832-media-c10">1,266</td><td class="excel-262832-media-c10">1,630</td><td class="excel-262832-media-c10">1,573</td><td class="excel-262832-media-c10">1,026</td><td class="excel-262832-media-c10">746</td><td class="excel-262832-media-c10">656</td><td class="excel-262832-media-c10">442</td><td class="excel-262832-media-c10">425</td><td class="excel-262832-media-c10">473</td><td class="excel-262832-media-c11">371</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">65-79</td><td class="excel-262832-media-c10">119</td><td class="excel-262832-media-c10">175</td><td class="excel-262832-media-c10">163</td><td class="excel-262832-media-c10">199</td><td class="excel-262832-media-c10">336</td><td class="excel-262832-media-c10">423</td><td class="excel-262832-media-c10">423</td><td class="excel-262832-media-c10">283</td><td class="excel-262832-media-c10">215</td><td class="excel-262832-media-c10">183</td><td class="excel-262832-media-c10">160</td><td class="excel-262832-media-c10">130</td><td class="excel-262832-media-c10">154</td><td class="excel-262832-media-c11">105</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">80+</td><td class="excel-262832-media-c10">38</td><td class="excel-262832-media-c10">53</td><td class="excel-262832-media-c10">52</td><td class="excel-262832-media-c10">97</td><td class="excel-262832-media-c10">132</td><td class="excel-262832-media-c10">171</td><td class="excel-262832-media-c10">200</td><td class="excel-262832-media-c10">156</td><td class="excel-262832-media-c10">163</td><td class="excel-262832-media-c10">151</td><td class="excel-262832-media-c10">104</td><td class="excel-262832-media-c10">100</td><td class="excel-262832-media-c10">110</td><td class="excel-262832-media-c11">71</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c10">0</td><td class="excel-262832-media-c11">0</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c14">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c14">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c14">&nbsp;</td><td class="excel-262832-media-c14">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c9">&nbsp;</td><td class="excel-262832-media-c14">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Median Age</td><td class="excel-262832-media-c10">33</td><td class="excel-262832-media-c10">33</td><td class="excel-262832-media-c10">33</td><td class="excel-262832-media-c10">34</td><td class="excel-262832-media-c10">31</td><td class="excel-262832-media-c10">31</td><td class="excel-262832-media-c10">33</td><td class="excel-262832-media-c10">34</td><td class="excel-262832-media-c10">37</td><td class="excel-262832-media-c10">36</td><td class="excel-262832-media-c10">33</td><td class="excel-262832-media-c10">36</td><td class="excel-262832-media-c10">37</td><td class="excel-262832-media-c11">33</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">County</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Carlow</td><td class="excel-262832-media-c10">6</td><td class="excel-262832-media-c10">11</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">14</td><td class="excel-262832-media-c10">38</td><td class="excel-262832-media-c10">65</td><td class="excel-262832-media-c10">78</td><td class="excel-262832-media-c10">43</td><td class="excel-262832-media-c10">26</td><td class="excel-262832-media-c10">22</td><td class="excel-262832-media-c10">22</td><td class="excel-262832-media-c10">24</td><td class="excel-262832-media-c10">46</td><td class="excel-262832-media-c11">40</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Cavan</td><td class="excel-262832-media-c10">8</td><td class="excel-262832-media-c10">15</td><td class="excel-262832-media-c10">26</td><td class="excel-262832-media-c10">89</td><td class="excel-262832-media-c10">306</td><td class="excel-262832-media-c10">377</td><td class="excel-262832-media-c10">273</td><td class="excel-262832-media-c10">74</td><td class="excel-262832-media-c10">42</td><td class="excel-262832-media-c10">40</td><td class="excel-262832-media-c10">26</td><td class="excel-262832-media-c10">17</td><td class="excel-262832-media-c10">30</td><td class="excel-262832-media-c11">57</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Clare</td><td class="excel-262832-media-c10">20</td><td class="excel-262832-media-c10">34</td><td class="excel-262832-media-c10">47</td><td class="excel-262832-media-c10">123</td><td class="excel-262832-media-c10">232</td><td class="excel-262832-media-c10">128</td><td class="excel-262832-media-c10">148</td><td class="excel-262832-media-c10">96</td><td class="excel-262832-media-c10">59</td><td class="excel-262832-media-c10">51</td><td class="excel-262832-media-c10">42</td><td class="excel-262832-media-c10">19</td><td class="excel-262832-media-c10">21</td><td class="excel-262832-media-c11">..</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Cork</td><td class="excel-262832-media-c10">40</td><td class="excel-262832-media-c10">161</td><td class="excel-262832-media-c10">261</td><td class="excel-262832-media-c10">361</td><td class="excel-262832-media-c10">792</td><td class="excel-262832-media-c10">931</td><td class="excel-262832-media-c10">770</td><td class="excel-262832-media-c10">598</td><td class="excel-262832-media-c10">217</td><td class="excel-262832-media-c10">189</td><td class="excel-262832-media-c10">248</td><td class="excel-262832-media-c10">111</td><td class="excel-262832-media-c10">71</td><td class="excel-262832-media-c11">59</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Donegal</td><td class="excel-262832-media-c10">54</td><td class="excel-262832-media-c10">120</td><td class="excel-262832-media-c10">212</td><td class="excel-262832-media-c10">258</td><td class="excel-262832-media-c10">282</td><td class="excel-262832-media-c10">225</td><td class="excel-262832-media-c10">280</td><td class="excel-262832-media-c10">223</td><td class="excel-262832-media-c10">211</td><td class="excel-262832-media-c10">186</td><td class="excel-262832-media-c10">173</td><td class="excel-262832-media-c10">182</td><td class="excel-262832-media-c10">182</td><td class="excel-262832-media-c11">156</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Dublin</td><td class="excel-262832-media-c10">941</td><td class="excel-262832-media-c10">1,149</td><td class="excel-262832-media-c10">1,091</td><td class="excel-262832-media-c10">1,039</td><td class="excel-262832-media-c10">1,402</td><td class="excel-262832-media-c10">1,745</td><td class="excel-262832-media-c10">1,512</td><td class="excel-262832-media-c10">1,275</td><td class="excel-262832-media-c10">881</td><td class="excel-262832-media-c10">790</td><td class="excel-262832-media-c10">648</td><td class="excel-262832-media-c10">616</td><td class="excel-262832-media-c10">614</td><td class="excel-262832-media-c11">472</td><td class="excel-262832-media-c12">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Galway</td><td class="excel-262832-media-c10">30</td><td class="excel-262832-media-c10">67</td><td class="excel-262832-media-c10">113</td><td class="excel-262832-media-c10">128</td><td class="excel-262832-media-c10">331</td><td class="excel-262832-media-c10">480</td><td class="excel-262832-media-c10">446</td><td class="excel-262832-media-c10">198</td><td class="excel-262832-media-c10">107</td><td class="excel-262832-media-c10">98</td><td class="excel-262832-media-c10">51</td><td class="excel-262832-media-c10">73</td><td class="excel-262832-media-c10">68</td><td class="excel-262832-media-c11">58</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Kerry</td><td class="excel-262832-media-c10">6</td><td class="excel-262832-media-c10">20</td><td class="excel-262832-media-c10">27</td><td class="excel-262832-media-c10">78</td><td class="excel-262832-media-c10">140</td><td class="excel-262832-media-c10">216</td><td class="excel-262832-media-c10">196</td><td class="excel-262832-media-c10">77</td><td class="excel-262832-media-c10">57</td><td class="excel-262832-media-c10">49</td><td class="excel-262832-media-c10">34</td><td class="excel-262832-media-c10">26</td><td class="excel-262832-media-c10">14</td><td class="excel-262832-media-c11">17</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Kildare</td><td class="excel-262832-media-c10">73</td><td class="excel-262832-media-c10">98</td><td class="excel-262832-media-c10">100</td><td class="excel-262832-media-c10">115</td><td class="excel-262832-media-c10">270</td><td class="excel-262832-media-c10">263</td><td class="excel-262832-media-c10">288</td><td class="excel-262832-media-c10">151</td><td class="excel-262832-media-c10">111</td><td class="excel-262832-media-c10">104</td><td class="excel-262832-media-c10">74</td><td class="excel-262832-media-c10">46</td><td class="excel-262832-media-c10">53</td><td class="excel-262832-media-c11">61</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Kilkenny</td><td class="excel-262832-media-c10">14</td><td class="excel-262832-media-c10">16</td><td class="excel-262832-media-c10">14</td><td class="excel-262832-media-c10">36</td><td class="excel-262832-media-c10">64</td><td class="excel-262832-media-c10">92</td><td class="excel-262832-media-c10">70</td><td class="excel-262832-media-c10">67</td><td class="excel-262832-media-c10">59</td><td class="excel-262832-media-c10">47</td><td class="excel-262832-media-c10">59</td><td class="excel-262832-media-c10">75</td><td class="excel-262832-media-c10">106</td><td class="excel-262832-media-c11">79</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Laois</td><td class="excel-262832-media-c10">20</td><td class="excel-262832-media-c10">13</td><td class="excel-262832-media-c10">21</td><td class="excel-262832-media-c10">55</td><td class="excel-262832-media-c10">65</td><td class="excel-262832-media-c10">108</td><td class="excel-262832-media-c10">94</td><td class="excel-262832-media-c10">72</td><td class="excel-262832-media-c10">30</td><td class="excel-262832-media-c10">25</td><td class="excel-262832-media-c10">28</td><td class="excel-262832-media-c10">26</td><td class="excel-262832-media-c10">22</td><td class="excel-262832-media-c11">50</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Leitrim</td><td class="excel-262832-media-c10">10</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">9</td><td class="excel-262832-media-c10">40</td><td class="excel-262832-media-c10">33</td><td class="excel-262832-media-c10">30</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">17</td><td class="excel-262832-media-c10">13</td><td class="excel-262832-media-c10">5</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c11">..</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Limerick</td><td class="excel-262832-media-c10">45</td><td class="excel-262832-media-c10">33</td><td class="excel-262832-media-c10">47</td><td class="excel-262832-media-c10">147</td><td class="excel-262832-media-c10">214</td><td class="excel-262832-media-c10">279</td><td class="excel-262832-media-c10">273</td><td class="excel-262832-media-c10">205</td><td class="excel-262832-media-c10">246</td><td class="excel-262832-media-c10">217</td><td class="excel-262832-media-c10">154</td><td class="excel-262832-media-c10">120</td><td class="excel-262832-media-c10">145</td><td class="excel-262832-media-c11">94</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Longford</td><td class="excel-262832-media-c10">16</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">38</td><td class="excel-262832-media-c10">29</td><td class="excel-262832-media-c10">38</td><td class="excel-262832-media-c10">57</td><td class="excel-262832-media-c10">47</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">26</td><td class="excel-262832-media-c10">21</td><td class="excel-262832-media-c10">17</td><td class="excel-262832-media-c10">21</td><td class="excel-262832-media-c10">23</td><td class="excel-262832-media-c11">25</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Louth</td><td class="excel-262832-media-c10">82</td><td class="excel-262832-media-c10">55</td><td class="excel-262832-media-c10">46</td><td class="excel-262832-media-c10">63</td><td class="excel-262832-media-c10">109</td><td class="excel-262832-media-c10">153</td><td class="excel-262832-media-c10">223</td><td class="excel-262832-media-c10">121</td><td class="excel-262832-media-c10">155</td><td class="excel-262832-media-c10">140</td><td class="excel-262832-media-c10">136</td><td class="excel-262832-media-c10">96</td><td class="excel-262832-media-c10">111</td><td class="excel-262832-media-c11">100</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Mayo</td><td class="excel-262832-media-c10">19</td><td class="excel-262832-media-c10">12</td><td class="excel-262832-media-c10">24</td><td class="excel-262832-media-c10">34</td><td class="excel-262832-media-c10">86</td><td class="excel-262832-media-c10">163</td><td class="excel-262832-media-c10">158</td><td class="excel-262832-media-c10">116</td><td class="excel-262832-media-c10">53</td><td class="excel-262832-media-c10">47</td><td class="excel-262832-media-c10">63</td><td class="excel-262832-media-c10">40</td><td class="excel-262832-media-c10">60</td><td class="excel-262832-media-c11">82</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Meath</td><td class="excel-262832-media-c10">35</td><td class="excel-262832-media-c10">43</td><td class="excel-262832-media-c10">65</td><td class="excel-262832-media-c10">132</td><td class="excel-262832-media-c10">406</td><td class="excel-262832-media-c10">622</td><td class="excel-262832-media-c10">527</td><td class="excel-262832-media-c10">225</td><td class="excel-262832-media-c10">142</td><td class="excel-262832-media-c10">126</td><td class="excel-262832-media-c10">96</td><td class="excel-262832-media-c10">45</td><td class="excel-262832-media-c10">46</td><td class="excel-262832-media-c11">63</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Monaghan</td><td class="excel-262832-media-c10">6</td><td class="excel-262832-media-c10">23</td><td class="excel-262832-media-c10">57</td><td class="excel-262832-media-c10">92</td><td class="excel-262832-media-c10">110</td><td class="excel-262832-media-c10">113</td><td class="excel-262832-media-c10">98</td><td class="excel-262832-media-c10">36</td><td class="excel-262832-media-c10">31</td><td class="excel-262832-media-c10">27</td><td class="excel-262832-media-c10">32</td><td class="excel-262832-media-c10">37</td><td class="excel-262832-media-c10">45</td><td class="excel-262832-media-c11">24</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Offaly</td><td class="excel-262832-media-c10">23</td><td class="excel-262832-media-c10">23</td><td class="excel-262832-media-c10">24</td><td class="excel-262832-media-c10">50</td><td class="excel-262832-media-c10">68</td><td class="excel-262832-media-c10">72</td><td class="excel-262832-media-c10">58</td><td class="excel-262832-media-c10">40</td><td class="excel-262832-media-c10">70</td><td class="excel-262832-media-c10">65</td><td class="excel-262832-media-c10">24</td><td class="excel-262832-media-c10">18</td><td class="excel-262832-media-c10">28</td><td class="excel-262832-media-c11">26</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Roscommon</td><td class="excel-262832-media-c10">13</td><td class="excel-262832-media-c10">25</td><td class="excel-262832-media-c10">51</td><td class="excel-262832-media-c10">48</td><td class="excel-262832-media-c10">67</td><td class="excel-262832-media-c10">55</td><td class="excel-262832-media-c10">109</td><td class="excel-262832-media-c10">59</td><td class="excel-262832-media-c10">79</td><td class="excel-262832-media-c10">69</td><td class="excel-262832-media-c10">28</td><td class="excel-262832-media-c10">16</td><td class="excel-262832-media-c10">17</td><td class="excel-262832-media-c11">10</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Sligo</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">12</td><td class="excel-262832-media-c10">13</td><td class="excel-262832-media-c10">46</td><td class="excel-262832-media-c10">84</td><td class="excel-262832-media-c10">118</td><td class="excel-262832-media-c10">149</td><td class="excel-262832-media-c10">55</td><td class="excel-262832-media-c10">26</td><td class="excel-262832-media-c10">20</td><td class="excel-262832-media-c10">24</td><td class="excel-262832-media-c10">16</td><td class="excel-262832-media-c10">8</td><td class="excel-262832-media-c11">21</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Tipperary</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">20</td><td class="excel-262832-media-c10">22</td><td class="excel-262832-media-c10">58</td><td class="excel-262832-media-c10">76</td><td class="excel-262832-media-c10">108</td><td class="excel-262832-media-c10">98</td><td class="excel-262832-media-c10">106</td><td class="excel-262832-media-c10">96</td><td class="excel-262832-media-c10">88</td><td class="excel-262832-media-c10">62</td><td class="excel-262832-media-c10">75</td><td class="excel-262832-media-c10">58</td><td class="excel-262832-media-c11">48</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Waterford</td><td class="excel-262832-media-c10">64</td><td class="excel-262832-media-c10">48</td><td class="excel-262832-media-c10">18</td><td class="excel-262832-media-c10">23</td><td class="excel-262832-media-c10">56</td><td class="excel-262832-media-c10">121</td><td class="excel-262832-media-c10">130</td><td class="excel-262832-media-c10">90</td><td class="excel-262832-media-c10">129</td><td class="excel-262832-media-c10">120</td><td class="excel-262832-media-c10">47</td><td class="excel-262832-media-c10">44</td><td class="excel-262832-media-c10">41</td><td class="excel-262832-media-c11">44</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Westmeath</td><td class="excel-262832-media-c10">30</td><td class="excel-262832-media-c10">12</td><td class="excel-262832-media-c10">37</td><td class="excel-262832-media-c10">46</td><td class="excel-262832-media-c10">110</td><td class="excel-262832-media-c10">168</td><td class="excel-262832-media-c10">165</td><td class="excel-262832-media-c10">108</td><td class="excel-262832-media-c10">82</td><td class="excel-262832-media-c10">71</td><td class="excel-262832-media-c10">21</td><td class="excel-262832-media-c10">13</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c11">17</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Wexford</td><td class="excel-262832-media-c10">30</td><td class="excel-262832-media-c10">16</td><td class="excel-262832-media-c10">36</td><td class="excel-262832-media-c10">58</td><td class="excel-262832-media-c10">188</td><td class="excel-262832-media-c10">236</td><td class="excel-262832-media-c10">153</td><td class="excel-262832-media-c10">57</td><td class="excel-262832-media-c10">27</td><td class="excel-262832-media-c10">25</td><td class="excel-262832-media-c10">30</td><td class="excel-262832-media-c10">..</td><td class="excel-262832-media-c10">20</td><td class="excel-262832-media-c11">44</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Wicklow</td><td class="excel-262832-media-c10">59</td><td class="excel-262832-media-c10">50</td><td class="excel-262832-media-c10">39</td><td class="excel-262832-media-c10">63</td><td class="excel-262832-media-c10">77</td><td class="excel-262832-media-c10">97</td><td class="excel-262832-media-c10">90</td><td class="excel-262832-media-c10">72</td><td class="excel-262832-media-c10">54</td><td class="excel-262832-media-c10">44</td><td class="excel-262832-media-c10">54</td><td class="excel-262832-media-c10">73</td><td class="excel-262832-media-c10">95</td><td class="excel-262832-media-c11">36</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c12">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c15">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Health Care Worker (HCW)</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Yes</td><td class="excel-262832-media-c10">127</td><td class="excel-262832-media-c10">132</td><td class="excel-262832-media-c10">145</td><td class="excel-262832-media-c10">229</td><td class="excel-262832-media-c10">361</td><td class="excel-262832-media-c10">323</td><td class="excel-262832-media-c10">293</td><td class="excel-262832-media-c10">166</td><td class="excel-262832-media-c10">474</td><td class="excel-262832-media-c10">430</td><td class="excel-262832-media-c10">318</td><td class="excel-262832-media-c10">237</td><td class="excel-262832-media-c10">260</td><td class="excel-262832-media-c11">181</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">No</td><td class="excel-262832-media-c10">1,466</td><td class="excel-262832-media-c10">1,845</td><td class="excel-262832-media-c10">2,144</td><td class="excel-262832-media-c10">2,780</td><td class="excel-262832-media-c10">4,824</td><td class="excel-262832-media-c10">4,877</td><td class="excel-262832-media-c10">4,709</td><td class="excel-262832-media-c10">3,422</td><td class="excel-262832-media-c10">2,395</td><td class="excel-262832-media-c10">2,120</td><td class="excel-262832-media-c10">1,801</td><td class="excel-262832-media-c10">1,412</td><td class="excel-262832-media-c10">1,493</td><td class="excel-262832-media-c11">1,302</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">61</td><td class="excel-262832-media-c10">103</td><td class="excel-262832-media-c10">154</td><td class="excel-262832-media-c10">185</td><td class="excel-262832-media-c10">466</td><td class="excel-262832-media-c10">1,825</td><td class="excel-262832-media-c10">1,461</td><td class="excel-262832-media-c10">608</td><td class="excel-262832-media-c10">164</td><td class="excel-262832-media-c10">144</td><td class="excel-262832-media-c10">79</td><td class="excel-262832-media-c10">193</td><td class="excel-262832-media-c10">184</td><td class="excel-262832-media-c11">211</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c12">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Related to Outbreak</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Yes </td><td class="excel-262832-media-c10">1,072</td><td class="excel-262832-media-c10">1,399</td><td class="excel-262832-media-c10">1,622</td><td class="excel-262832-media-c10">1,958</td><td class="excel-262832-media-c10">2,685</td><td class="excel-262832-media-c10">3,613</td><td class="excel-262832-media-c10">3,149</td><td class="excel-262832-media-c10">2,294</td><td class="excel-262832-media-c10">1,699</td><td class="excel-262832-media-c10">1,515</td><td class="excel-262832-media-c10">1,558</td><td class="excel-262832-media-c10">1,028</td><td class="excel-262832-media-c10">966</td><td class="excel-262832-media-c11">413</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">582</td><td class="excel-262832-media-c10">681</td><td class="excel-262832-media-c10">821</td><td class="excel-262832-media-c10">1,236</td><td class="excel-262832-media-c10">2,966</td><td class="excel-262832-media-c10">3,412</td><td class="excel-262832-media-c10">3,314</td><td class="excel-262832-media-c10">1,902</td><td class="excel-262832-media-c10">1,334</td><td class="excel-262832-media-c10">1,179</td><td class="excel-262832-media-c10">640</td><td class="excel-262832-media-c10">814</td><td class="excel-262832-media-c10">971</td><td class="excel-262832-media-c11">1,281</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c12">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c15">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Underlying Condition</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c7">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Yes</td><td class="excel-262832-media-c10">479</td><td class="excel-262832-media-c10">638</td><td class="excel-262832-media-c10">709</td><td class="excel-262832-media-c10">682</td><td class="excel-262832-media-c10">919</td><td class="excel-262832-media-c10">513</td><td class="excel-262832-media-c10">241</td><td class="excel-262832-media-c10">343</td><td class="excel-262832-media-c10">830</td><td class="excel-262832-media-c10">739</td><td class="excel-262832-media-c10">614</td><td class="excel-262832-media-c10">591</td><td class="excel-262832-media-c10">624</td><td class="excel-262832-media-c11">481</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">No</td><td class="excel-262832-media-c10">1,089</td><td class="excel-262832-media-c10">1,336</td><td class="excel-262832-media-c10">1,608</td><td class="excel-262832-media-c10">2,335</td><td class="excel-262832-media-c10">4,301</td><td class="excel-262832-media-c10">4,681</td><td class="excel-262832-media-c10">4,701</td><td class="excel-262832-media-c10">3,048</td><td class="excel-262832-media-c10">2,034</td><td class="excel-262832-media-c10">1,808</td><td class="excel-262832-media-c10">1,522</td><td class="excel-262832-media-c10">1,059</td><td class="excel-262832-media-c10">1,154</td><td class="excel-262832-media-c11">1,039</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c16">Not Specified</td><td class="excel-262832-media-c17">86</td><td class="excel-262832-media-c17">106</td><td class="excel-262832-media-c17">126</td><td class="excel-262832-media-c17">177</td><td class="excel-262832-media-c17">431</td><td class="excel-262832-media-c17">1,831</td><td class="excel-262832-media-c17">1,521</td><td class="excel-262832-media-c17">805</td><td class="excel-262832-media-c17">169</td><td class="excel-262832-media-c17">147</td><td class="excel-262832-media-c17">62</td><td class="excel-262832-media-c17">192</td><td class="excel-262832-media-c17">159</td><td class="excel-262832-media-c18">174</td>
</tr>
<tr class="excel-262832-media-r1"></tr>
<tr class="excel-262832-media-r1"></tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c1" colspan="16">Table 3A: Weekly Profile of Cumulative COVID-19 Confirmed Cases (%) <b><sup>1,2,3,5</sup></b></td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c1">&nbsp;</td><td class="excel-262832-media-c19" colspan="15">2020</td>
</tr>
<tr class="excel-262832-media-r2">
<td class="excel-262832-media-c3">&nbsp;</td><td class="excel-262832-media-c4">11/09</td><td class="excel-262832-media-c4">18/09</td><td class="excel-262832-media-c4">25/09</td><td class="excel-262832-media-c4">02/10</td><td class="excel-262832-media-c4">09/10</td><td class="excel-262832-media-c4">16/10</td><td class="excel-262832-media-c4">23/10</td><td class="excel-262832-media-c4">30/10</td><td class="excel-262832-media-c4">06/11</td><td class="excel-262832-media-c4">13/11</td><td class="excel-262832-media-c4">20/11</td><td class="excel-262832-media-c4">27/11</td><td class="excel-262832-media-c4">04/12</td><td class="excel-262832-media-c4">11/12*</td><td class="excel-262832-media-c4">% Gen Pop</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Gender</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Female</td><td class="excel-262832-media-c10">56%</td><td class="excel-262832-media-c10">55%</td><td class="excel-262832-media-c10">55%</td><td class="excel-262832-media-c10">55%</td><td class="excel-262832-media-c10">54%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c11">53%</td><td class="excel-262832-media-c6">51%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Male</td><td class="excel-262832-media-c10">44%</td><td class="excel-262832-media-c10">45%</td><td class="excel-262832-media-c10">45%</td><td class="excel-262832-media-c10">45%</td><td class="excel-262832-media-c10">46%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c11">47%</td><td class="excel-262832-media-c6">49%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c11">0%</td><td class="excel-262832-media-c5">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c15">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Age</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">0-14</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c11">9%</td><td class="excel-262832-media-c6">21%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">15-24</td><td class="excel-262832-media-c10">10%</td><td class="excel-262832-media-c10">11%</td><td class="excel-262832-media-c10">12%</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c10">15%</td><td class="excel-262832-media-c10">16%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">18%</td><td class="excel-262832-media-c10">18%</td><td class="excel-262832-media-c10">18%</td><td class="excel-262832-media-c11">18%</td><td class="excel-262832-media-c6">12%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">25-44</td><td class="excel-262832-media-c10">35%</td><td class="excel-262832-media-c10">35%</td><td class="excel-262832-media-c10">35%</td><td class="excel-262832-media-c10">35%</td><td class="excel-262832-media-c10">34%</td><td class="excel-262832-media-c10">33%</td><td class="excel-262832-media-c10">33%</td><td class="excel-262832-media-c10">33%</td><td class="excel-262832-media-c10">33%</td><td class="excel-262832-media-c10">33%</td><td class="excel-262832-media-c10">32%</td><td class="excel-262832-media-c10">32%</td><td class="excel-262832-media-c10">32%</td><td class="excel-262832-media-c11">32%</td><td class="excel-262832-media-c6">30%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">45-64</td><td class="excel-262832-media-c10">29%</td><td class="excel-262832-media-c10">29%</td><td class="excel-262832-media-c10">28%</td><td class="excel-262832-media-c10">28%</td><td class="excel-262832-media-c10">27%</td><td class="excel-262832-media-c10">27%</td><td class="excel-262832-media-c10">27%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c11">26%</td><td class="excel-262832-media-c6">24%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">65-79</td><td class="excel-262832-media-c10">10%</td><td class="excel-262832-media-c10">10%</td><td class="excel-262832-media-c10">10%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c11">8%</td><td class="excel-262832-media-c6">10%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">80+</td><td class="excel-262832-media-c10">12%</td><td class="excel-262832-media-c10">11%</td><td class="excel-262832-media-c10">11%</td><td class="excel-262832-media-c10">10%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c11">7%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c11">0%</td><td class="excel-262832-media-c5">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td><td class="excel-262832-media-c13">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">County</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c5">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Carlow</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c11">1%</td><td class="excel-262832-media-c6">1%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Cavan</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c11">3%</td><td class="excel-262832-media-c6">2%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Clare</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">2%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Cork</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c10">9%</td><td class="excel-262832-media-c11">9%</td><td class="excel-262832-media-c6">12%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Donegal</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c11">4%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Dublin</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">46%</td><td class="excel-262832-media-c10">44%</td><td class="excel-262832-media-c10">41%</td><td class="excel-262832-media-c10">39%</td><td class="excel-262832-media-c10">39%</td><td class="excel-262832-media-c10">38%</td><td class="excel-262832-media-c10">38%</td><td class="excel-262832-media-c10">37%</td><td class="excel-262832-media-c10">37%</td><td class="excel-262832-media-c10">37%</td><td class="excel-262832-media-c11">37%</td><td class="excel-262832-media-c6">28%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Galway</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c11">4%</td><td class="excel-262832-media-c6">6%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Kerry</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Kildare</td><td class="excel-262832-media-c10">8%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">7%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c10">6%</td><td class="excel-262832-media-c11">6%</td><td class="excel-262832-media-c6">5%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Kilkenny</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c11">1%</td><td class="excel-262832-media-c6">2%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Laois</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c11">1%</td><td class="excel-262832-media-c6">2%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Leitrim</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c10">0%</td><td class="excel-262832-media-c11">0%</td><td class="excel-262832-media-c6">1%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Limerick</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c11">4%</td><td class="excel-262832-media-c6">4%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Longford</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c11">1%</td><td class="excel-262832-media-c6">1%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Louth</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c11">3%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Mayo</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Meath</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">4%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c10">5%</td><td class="excel-262832-media-c11">5%</td><td class="excel-262832-media-c6">4%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Monaghan</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">1%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Offaly</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">2%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Roscommon</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c11">1%</td><td class="excel-262832-media-c6">1%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Sligo</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c11">1%</td><td class="excel-262832-media-c6">1%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Tipperary</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Waterford</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c11">1%</td><td class="excel-262832-media-c6">2%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Westmeath</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">2%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Wexford</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">1%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Wicklow</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">3%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c10">2%</td><td class="excel-262832-media-c11">2%</td><td class="excel-262832-media-c6">3%</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c15">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Health Care Worker (HCW)</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Yes</td><td class="excel-262832-media-c10">28%</td><td class="excel-262832-media-c10">27%</td><td class="excel-262832-media-c10">25%</td><td class="excel-262832-media-c10">24%</td><td class="excel-262832-media-c10">22%</td><td class="excel-262832-media-c10">19%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">17%</td><td class="excel-262832-media-c10">16%</td><td class="excel-262832-media-c10">16%</td><td class="excel-262832-media-c10">16%</td><td class="excel-262832-media-c11">16%</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">No</td><td class="excel-262832-media-c10">59%</td><td class="excel-262832-media-c10">61%</td><td class="excel-262832-media-c10">63%</td><td class="excel-262832-media-c10">65%</td><td class="excel-262832-media-c10">67%</td><td class="excel-262832-media-c10">68%</td><td class="excel-262832-media-c10">68%</td><td class="excel-262832-media-c10">68%</td><td class="excel-262832-media-c10">70%</td><td class="excel-262832-media-c10">70%</td><td class="excel-262832-media-c10">71%</td><td class="excel-262832-media-c10">71%</td><td class="excel-262832-media-c10">71%</td><td class="excel-262832-media-c11">71%</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c10">12%</td><td class="excel-262832-media-c10">12%</td><td class="excel-262832-media-c10">11%</td><td class="excel-262832-media-c10">11%</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c10">15%</td><td class="excel-262832-media-c10">15%</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c10">13%</td><td class="excel-262832-media-c11">13%</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c12">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c13">&nbsp;</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Related to Outbreak</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c10">&nbsp;</td><td class="excel-262832-media-c11">&nbsp;</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Yes </td><td class="excel-262832-media-c10">56%</td><td class="excel-262832-media-c10">57%</td><td class="excel-262832-media-c10">57%</td><td class="excel-262832-media-c10">58%</td><td class="excel-262832-media-c10">56%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">50%</td><td class="excel-262832-media-c10">52%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">54%</td><td class="excel-262832-media-c10">55%</td><td class="excel-262832-media-c10">55%</td><td class="excel-262832-media-c10">55%</td><td class="excel-262832-media-c11">55%</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Not Specified</td><td class="excel-262832-media-c10">44%</td><td class="excel-262832-media-c10">43%</td><td class="excel-262832-media-c10">43%</td><td class="excel-262832-media-c10">42%</td><td class="excel-262832-media-c10">44%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">50%</td><td class="excel-262832-media-c10">48%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">46%</td><td class="excel-262832-media-c10">45%</td><td class="excel-262832-media-c10">45%</td><td class="excel-262832-media-c10">45%</td><td class="excel-262832-media-c11">45%</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c12">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c6">&nbsp;</td><td class="excel-262832-media-c7">&nbsp;</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c5">Underlying Condition</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c8">&nbsp;</td><td class="excel-262832-media-c15">&nbsp;</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">Yes</td><td class="excel-262832-media-c10">37%</td><td class="excel-262832-media-c10">37%</td><td class="excel-262832-media-c10">36%</td><td class="excel-262832-media-c10">35%</td><td class="excel-262832-media-c10">32%</td><td class="excel-262832-media-c10">29%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c10">25%</td><td class="excel-262832-media-c10">25%</td><td class="excel-262832-media-c10">25%</td><td class="excel-262832-media-c10">25%</td><td class="excel-262832-media-c10">25%</td><td class="excel-262832-media-c10">26%</td><td class="excel-262832-media-c11">26%</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8">No</td><td class="excel-262832-media-c10">42%</td><td class="excel-262832-media-c10">43%</td><td class="excel-262832-media-c10">45%</td><td class="excel-262832-media-c10">47%</td><td class="excel-262832-media-c10">51%</td><td class="excel-262832-media-c10">53%</td><td class="excel-262832-media-c10">55%</td><td class="excel-262832-media-c10">56%</td><td class="excel-262832-media-c10">57%</td><td class="excel-262832-media-c10">58%</td><td class="excel-262832-media-c10">58%</td><td class="excel-262832-media-c10">58%</td><td class="excel-262832-media-c10">58%</td><td class="excel-262832-media-c11">58%</td><td class="excel-262832-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c16">Not Specified</td><td class="excel-262832-media-c17">21%</td><td class="excel-262832-media-c17">20%</td><td class="excel-262832-media-c17">19%</td><td class="excel-262832-media-c17">18%</td><td class="excel-262832-media-c17">17%</td><td class="excel-262832-media-c17">18%</td><td class="excel-262832-media-c17">19%</td><td class="excel-262832-media-c17">19%</td><td class="excel-262832-media-c17">18%</td><td class="excel-262832-media-c17">17%</td><td class="excel-262832-media-c17">17%</td><td class="excel-262832-media-c17">17%</td><td class="excel-262832-media-c17">16%</td><td class="excel-262832-media-c18">16%</td><td class="excel-262832-media-c1">&nbsp;</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c21" colspan="16">* latest week is preliminary</td>
</tr>
<tr class="excel-262832-media-r3">
<td class="excel-262832-media-c8" colspan="16"><sup>1 </sup>Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
<tr class="excel-262832-media-r4">
<td class="excel-262832-media-c8" colspan="16"><sup>2 </sup>Data is defined by epidemiological date which is the earliest of onset date, date of diagnosis, laboratory specimen collection date, laboratory received date, laboratory reported date and event creation/notification date</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8" colspan="16"><sup>3</sup> '..' Indicates a cell number &lt; 5 or a cell number &lt; 5 can be identified</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8" colspan="16"><sup>4 </sup>Week ending 06/03/2020 includes all cases up to that date, including previous weeks.</td>
</tr>
<tr class="excel-262832-media-r1">
<td class="excel-262832-media-c8" colspan="16"><sup>5</sup> General Population from Census 2016</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL3.xlsx">COVID-19 Deaths and Cases Series 18 - Table 3 (XLS 21KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262832_description").click(function(){
    $("#262832_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262832_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262837_description">
    <span id="#262837_openClose">Show Table</span>: Table 4 &amp; 4A Weekly Electoral Division (ED) Analysis of Confirmed Covid-19 Cases
  </div>

<div style="clear: both"></div>

<div id="262837_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262837-insertexceltable">
<div id="table-262837-1-insertexceltable">
<table class="excel-262837-media-t1">
<colgroup>
<col width="273">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="67">
<col width="54">
</colgroup>
<tbody>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c1" colspan="15">Table 4 &amp; 4A Weekly Electoral Division (ED) Analysis of Confirmed Covid-19 Cases</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c1">&nbsp;</td><td class="excel-262837-media-c2" colspan="14">2020</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c3">&nbsp;</td><td class="excel-262837-media-c4">11/09</td><td class="excel-262837-media-c4">18/09</td><td class="excel-262837-media-c4">25/09</td><td class="excel-262837-media-c4">02/10</td><td class="excel-262837-media-c4">09/10</td><td class="excel-262837-media-c4">16/10</td><td class="excel-262837-media-c4">23/10</td><td class="excel-262837-media-c4">30/11</td><td class="excel-262837-media-c4">06/11</td><td class="excel-262837-media-c4">13/11</td><td class="excel-262837-media-c4">20/11</td><td class="excel-262837-media-c4">27/11</td><td class="excel-262837-media-c4">04/12</td><td class="excel-262837-media-c4">11/12*</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Total</td><td class="excel-262837-media-c6">1,654</td><td class="excel-262837-media-c6">2,080</td><td class="excel-262837-media-c6">2,443</td><td class="excel-262837-media-c6">3,194</td><td class="excel-262837-media-c6">5,651</td><td class="excel-262837-media-c6">7,025</td><td class="excel-262837-media-c6">6,463</td><td class="excel-262837-media-c6">4,196</td><td class="excel-262837-media-c6">3,033</td><td class="excel-262837-media-c6">2,694</td><td class="excel-262837-media-c6">2,198</td><td class="excel-262837-media-c6">1,842</td><td class="excel-262837-media-c6">1,937</td><td class="excel-262837-media-c7">1,694</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c8">&nbsp;</td><td class="excel-262837-media-c8">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c8">&nbsp;</td><td class="excel-262837-media-c8">&nbsp;</td><td class="excel-262837-media-c8">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c7">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Urban / Rural <b><sup>4</sup></b></td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Cities</td><td class="excel-262837-media-c12">829</td><td class="excel-262837-media-c12">1,093</td><td class="excel-262837-media-c12">1,200</td><td class="excel-262837-media-c12">1,291</td><td class="excel-262837-media-c12">2,107</td><td class="excel-262837-media-c12">2,505</td><td class="excel-262837-media-c12">2,025</td><td class="excel-262837-media-c12">1,363</td><td class="excel-262837-media-c12">1,055</td><td class="excel-262837-media-c12">1,072</td><td class="excel-262837-media-c12">880</td><td class="excel-262837-media-c12">730</td><td class="excel-262837-media-c12">661</td><td class="excel-262837-media-c13">510</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Satellite urban towns</td><td class="excel-262837-media-c12">409</td><td class="excel-262837-media-c12">370</td><td class="excel-262837-media-c12">338</td><td class="excel-262837-media-c12">361</td><td class="excel-262837-media-c12">797</td><td class="excel-262837-media-c12">1,108</td><td class="excel-262837-media-c12">986</td><td class="excel-262837-media-c12">594</td><td class="excel-262837-media-c12">439</td><td class="excel-262837-media-c12">292</td><td class="excel-262837-media-c12">268</td><td class="excel-262837-media-c12">278</td><td class="excel-262837-media-c12">245</td><td class="excel-262837-media-c13">203</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Independent urban towns</td><td class="excel-262837-media-c12">201</td><td class="excel-262837-media-c12">269</td><td class="excel-262837-media-c12">319</td><td class="excel-262837-media-c12">609</td><td class="excel-262837-media-c12">1,020</td><td class="excel-262837-media-c12">1,345</td><td class="excel-262837-media-c12">1,325</td><td class="excel-262837-media-c12">689</td><td class="excel-262837-media-c12">590</td><td class="excel-262837-media-c12">594</td><td class="excel-262837-media-c12">444</td><td class="excel-262837-media-c12">336</td><td class="excel-262837-media-c12">454</td><td class="excel-262837-media-c13">457</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Rural areas with high urban influence</td><td class="excel-262837-media-c12">95</td><td class="excel-262837-media-c12">143</td><td class="excel-262837-media-c12">225</td><td class="excel-262837-media-c12">369</td><td class="excel-262837-media-c12">794</td><td class="excel-262837-media-c12">992</td><td class="excel-262837-media-c12">902</td><td class="excel-262837-media-c12">406</td><td class="excel-262837-media-c12">403</td><td class="excel-262837-media-c12">346</td><td class="excel-262837-media-c12">265</td><td class="excel-262837-media-c12">209</td><td class="excel-262837-media-c12">245</td><td class="excel-262837-media-c13">239</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Rural areas with moderate urban influence</td><td class="excel-262837-media-c12">65</td><td class="excel-262837-media-c12">131</td><td class="excel-262837-media-c12">188</td><td class="excel-262837-media-c12">314</td><td class="excel-262837-media-c12">572</td><td class="excel-262837-media-c12">614</td><td class="excel-262837-media-c12">611</td><td class="excel-262837-media-c12">390</td><td class="excel-262837-media-c12">272</td><td class="excel-262837-media-c12">229</td><td class="excel-262837-media-c12">200</td><td class="excel-262837-media-c12">200</td><td class="excel-262837-media-c12">221</td><td class="excel-262837-media-c13">181</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Highly rural / remote areas</td><td class="excel-262837-media-c12">40</td><td class="excel-262837-media-c12">52</td><td class="excel-262837-media-c12">137</td><td class="excel-262837-media-c12">220</td><td class="excel-262837-media-c12">306</td><td class="excel-262837-media-c12">372</td><td class="excel-262837-media-c12">383</td><td class="excel-262837-media-c12">204</td><td class="excel-262837-media-c12">171</td><td class="excel-262837-media-c12">125</td><td class="excel-262837-media-c12">112</td><td class="excel-262837-media-c12">73</td><td class="excel-262837-media-c12">94</td><td class="excel-262837-media-c13">91</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">15</td><td class="excel-262837-media-c12">22</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">55</td><td class="excel-262837-media-c12">89</td><td class="excel-262837-media-c12">231</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c12">103</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">16</td><td class="excel-262837-media-c12">17</td><td class="excel-262837-media-c13">13</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c9">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Population Density <b><sup>5</sup></b></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">0- 50 people per km<sup>2</sup></td><td class="excel-262837-media-c12">213</td><td class="excel-262837-media-c12">371</td><td class="excel-262837-media-c12">392</td><td class="excel-262837-media-c12">629</td><td class="excel-262837-media-c12">1,289</td><td class="excel-262837-media-c12">1,401</td><td class="excel-262837-media-c12">1,554</td><td class="excel-262837-media-c12">1,014</td><td class="excel-262837-media-c12">692</td><td class="excel-262837-media-c12">500</td><td class="excel-262837-media-c12">644</td><td class="excel-262837-media-c12">329</td><td class="excel-262837-media-c12">440</td><td class="excel-262837-media-c13">402</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">50 - 500 people per km<sup>2</sup></td><td class="excel-262837-media-c12">265</td><td class="excel-262837-media-c12">394</td><td class="excel-262837-media-c12">565</td><td class="excel-262837-media-c12">900</td><td class="excel-262837-media-c12">1,625</td><td class="excel-262837-media-c12">2,312</td><td class="excel-262837-media-c12">1,691</td><td class="excel-262837-media-c12">906</td><td class="excel-262837-media-c12">824</td><td class="excel-262837-media-c12">761</td><td class="excel-262837-media-c12">541</td><td class="excel-262837-media-c12">585</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c13">514</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">500 - 2,500 people per km<sup>2</sup></td><td class="excel-262837-media-c12">242</td><td class="excel-262837-media-c12">464</td><td class="excel-262837-media-c12">530</td><td class="excel-262837-media-c12">656</td><td class="excel-262837-media-c12">1,250</td><td class="excel-262837-media-c12">1,514</td><td class="excel-262837-media-c12">1,592</td><td class="excel-262837-media-c12">901</td><td class="excel-262837-media-c12">792</td><td class="excel-262837-media-c12">626</td><td class="excel-262837-media-c12">584</td><td class="excel-262837-media-c12">372</td><td class="excel-262837-media-c12">411</td><td class="excel-262837-media-c13">356</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&gt; 2,500 people per km<sup>2</sup></td><td class="excel-262837-media-c12">660</td><td class="excel-262837-media-c12">829</td><td class="excel-262837-media-c12">920</td><td class="excel-262837-media-c12">979</td><td class="excel-262837-media-c12">1,432</td><td class="excel-262837-media-c12">1,709</td><td class="excel-262837-media-c12">1,395</td><td class="excel-262837-media-c12">825</td><td class="excel-262837-media-c12">622</td><td class="excel-262837-media-c12">771</td><td class="excel-262837-media-c12">400</td><td class="excel-262837-media-c12">540</td><td class="excel-262837-media-c12">519</td><td class="excel-262837-media-c13">409</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">15</td><td class="excel-262837-media-c12">22</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">55</td><td class="excel-262837-media-c12">89</td><td class="excel-262837-media-c12">231</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c12">103</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">16</td><td class="excel-262837-media-c12">17</td><td class="excel-262837-media-c13">13</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Median Household Income <b><sup>6</sup></b></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt; 30k</td><td class="excel-262837-media-c12">95</td><td class="excel-262837-media-c12">137</td><td class="excel-262837-media-c12">161</td><td class="excel-262837-media-c12">272</td><td class="excel-262837-media-c12">421</td><td class="excel-262837-media-c12">512</td><td class="excel-262837-media-c12">514</td><td class="excel-262837-media-c12">253</td><td class="excel-262837-media-c12">229</td><td class="excel-262837-media-c12">262</td><td class="excel-262837-media-c12">192</td><td class="excel-262837-media-c12">143</td><td class="excel-262837-media-c12">166</td><td class="excel-262837-media-c13">206</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">30k - 40k </td><td class="excel-262837-media-c12">415</td><td class="excel-262837-media-c12">417</td><td class="excel-262837-media-c12">575</td><td class="excel-262837-media-c12">910</td><td class="excel-262837-media-c12">1,555</td><td class="excel-262837-media-c12">1,777</td><td class="excel-262837-media-c12">1,574</td><td class="excel-262837-media-c12">917</td><td class="excel-262837-media-c12">754</td><td class="excel-262837-media-c12">742</td><td class="excel-262837-media-c12">647</td><td class="excel-262837-media-c12">437</td><td class="excel-262837-media-c12">508</td><td class="excel-262837-media-c13">447</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">40k - 50k</td><td class="excel-262837-media-c12">467</td><td class="excel-262837-media-c12">575</td><td class="excel-262837-media-c12">672</td><td class="excel-262837-media-c12">939</td><td class="excel-262837-media-c12">1,568</td><td class="excel-262837-media-c12">1,932</td><td class="excel-262837-media-c12">1,849</td><td class="excel-262837-media-c12">993</td><td class="excel-262837-media-c12">874</td><td class="excel-262837-media-c12">746</td><td class="excel-262837-media-c12">629</td><td class="excel-262837-media-c12">584</td><td class="excel-262837-media-c12">587</td><td class="excel-262837-media-c13">488</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">50k - 60k</td><td class="excel-262837-media-c12">332</td><td class="excel-262837-media-c12">396</td><td class="excel-262837-media-c12">496</td><td class="excel-262837-media-c12">543</td><td class="excel-262837-media-c12">1,083</td><td class="excel-262837-media-c12">1,469</td><td class="excel-262837-media-c12">1,240</td><td class="excel-262837-media-c12">740</td><td class="excel-262837-media-c12">603</td><td class="excel-262837-media-c12">519</td><td class="excel-262837-media-c12">395</td><td class="excel-262837-media-c12">394</td><td class="excel-262837-media-c12">345</td><td class="excel-262837-media-c13">280</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">60k - 70k </td><td class="excel-262837-media-c12">228</td><td class="excel-262837-media-c12">289</td><td class="excel-262837-media-c12">358</td><td class="excel-262837-media-c12">355</td><td class="excel-262837-media-c12">736</td><td class="excel-262837-media-c12">873</td><td class="excel-262837-media-c12">748</td><td class="excel-262837-media-c12">593</td><td class="excel-262837-media-c12">334</td><td class="excel-262837-media-c12">299</td><td class="excel-262837-media-c12">229</td><td class="excel-262837-media-c12">184</td><td class="excel-262837-media-c12">178</td><td class="excel-262837-media-c13">165</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">70k - 80k</td><td class="excel-262837-media-c12">69</td><td class="excel-262837-media-c12">95</td><td class="excel-262837-media-c12">105</td><td class="excel-262837-media-c12">86</td><td class="excel-262837-media-c12">168</td><td class="excel-262837-media-c12">268</td><td class="excel-262837-media-c12">236</td><td class="excel-262837-media-c12">107</td><td class="excel-262837-media-c12">105</td><td class="excel-262837-media-c12">67</td><td class="excel-262837-media-c12">51</td><td class="excel-262837-media-c12">51</td><td class="excel-262837-media-c12">84</td><td class="excel-262837-media-c13">51</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">80k - 90k</td><td class="excel-262837-media-c12">28</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">51</td><td class="excel-262837-media-c12">58</td><td class="excel-262837-media-c12">93</td><td class="excel-262837-media-c12">61</td><td class="excel-262837-media-c12">38</td><td class="excel-262837-media-c12">25</td><td class="excel-262837-media-c12">18</td><td class="excel-262837-media-c12">21</td><td class="excel-262837-media-c12">28</td><td class="excel-262837-media-c12">47</td><td class="excel-262837-media-c13">..</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">90k +</td><td class="excel-262837-media-c12">5</td><td class="excel-262837-media-c12">13</td><td class="excel-262837-media-c12">11</td><td class="excel-262837-media-c12">8</td><td class="excel-262837-media-c12">7</td><td class="excel-262837-media-c12">12</td><td class="excel-262837-media-c12">10</td><td class="excel-262837-media-c12">5</td><td class="excel-262837-media-c12">6</td><td class="excel-262837-media-c12">5</td><td class="excel-262837-media-c12">5</td><td class="excel-262837-media-c12">5</td><td class="excel-262837-media-c12">5</td><td class="excel-262837-media-c13">..</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">15</td><td class="excel-262837-media-c12">22</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">55</td><td class="excel-262837-media-c12">89</td><td class="excel-262837-media-c12">231</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c12">103</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">16</td><td class="excel-262837-media-c12">17</td><td class="excel-262837-media-c13">13</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of HH's where working age social welfare was majority of income in ED <b><sup>7</sup></b></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">20% +</td><td class="excel-262837-media-c12">512</td><td class="excel-262837-media-c12">510</td><td class="excel-262837-media-c12">536</td><td class="excel-262837-media-c12">850</td><td class="excel-262837-media-c12">1,236</td><td class="excel-262837-media-c12">1,570</td><td class="excel-262837-media-c12">1,512</td><td class="excel-262837-media-c12">875</td><td class="excel-262837-media-c12">774</td><td class="excel-262837-media-c12">765</td><td class="excel-262837-media-c12">583</td><td class="excel-262837-media-c12">394</td><td class="excel-262837-media-c12">500</td><td class="excel-262837-media-c13">471</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">13%-19.99%</td><td class="excel-262837-media-c12">374</td><td class="excel-262837-media-c12">490</td><td class="excel-262837-media-c12">608</td><td class="excel-262837-media-c12">889</td><td class="excel-262837-media-c12">1,660</td><td class="excel-262837-media-c12">1,932</td><td class="excel-262837-media-c12">1,799</td><td class="excel-262837-media-c12">961</td><td class="excel-262837-media-c12">855</td><td class="excel-262837-media-c12">714</td><td class="excel-262837-media-c12">571</td><td class="excel-262837-media-c12">531</td><td class="excel-262837-media-c12">545</td><td class="excel-262837-media-c13">514</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">9%-12.99%</td><td class="excel-262837-media-c12">387</td><td class="excel-262837-media-c12">421</td><td class="excel-262837-media-c12">580</td><td class="excel-262837-media-c12">656</td><td class="excel-262837-media-c12">1,059</td><td class="excel-262837-media-c12">1,377</td><td class="excel-262837-media-c12">1,195</td><td class="excel-262837-media-c12">748</td><td class="excel-262837-media-c12">533</td><td class="excel-262837-media-c12">569</td><td class="excel-262837-media-c12">431</td><td class="excel-262837-media-c12">350</td><td class="excel-262837-media-c12">413</td><td class="excel-262837-media-c13">294</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;9%</td><td class="excel-262837-media-c12">366</td><td class="excel-262837-media-c12">637</td><td class="excel-262837-media-c12">683</td><td class="excel-262837-media-c12">769</td><td class="excel-262837-media-c12">1,641</td><td class="excel-262837-media-c12">2,057</td><td class="excel-262837-media-c12">1,726</td><td class="excel-262837-media-c12">1,062</td><td class="excel-262837-media-c12">769</td><td class="excel-262837-media-c12">610</td><td class="excel-262837-media-c12">584</td><td class="excel-262837-media-c12">551</td><td class="excel-262837-media-c12">462</td><td class="excel-262837-media-c13">402</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">15</td><td class="excel-262837-media-c12">22</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">55</td><td class="excel-262837-media-c12">89</td><td class="excel-262837-media-c12">231</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c12">103</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">16</td><td class="excel-262837-media-c12">17</td><td class="excel-262837-media-c13">13</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of HH's where state pension was majority of income in ED <b><sup>8</sup></b></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">20% +</td><td class="excel-262837-media-c12">150</td><td class="excel-262837-media-c12">199</td><td class="excel-262837-media-c12">305</td><td class="excel-262837-media-c12">382</td><td class="excel-262837-media-c12">721</td><td class="excel-262837-media-c12">758</td><td class="excel-262837-media-c12">728</td><td class="excel-262837-media-c12">424</td><td class="excel-262837-media-c12">324</td><td class="excel-262837-media-c12">322</td><td class="excel-262837-media-c12">286</td><td class="excel-262837-media-c12">186</td><td class="excel-262837-media-c12">203</td><td class="excel-262837-media-c13">198</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">13%-19.99%</td><td class="excel-262837-media-c12">351</td><td class="excel-262837-media-c12">670</td><td class="excel-262837-media-c12">715</td><td class="excel-262837-media-c12">1,094</td><td class="excel-262837-media-c12">1,802</td><td class="excel-262837-media-c12">2,264</td><td class="excel-262837-media-c12">2,117</td><td class="excel-262837-media-c12">1,081</td><td class="excel-262837-media-c12">998</td><td class="excel-262837-media-c12">846</td><td class="excel-262837-media-c12">683</td><td class="excel-262837-media-c12">624</td><td class="excel-262837-media-c12">706</td><td class="excel-262837-media-c13">594</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">9%-12.99%</td><td class="excel-262837-media-c12">503</td><td class="excel-262837-media-c12">456</td><td class="excel-262837-media-c12">571</td><td class="excel-262837-media-c12">766</td><td class="excel-262837-media-c12">1,342</td><td class="excel-262837-media-c12">1,635</td><td class="excel-262837-media-c12">1,492</td><td class="excel-262837-media-c12">1,011</td><td class="excel-262837-media-c12">665</td><td class="excel-262837-media-c12">653</td><td class="excel-262837-media-c12">526</td><td class="excel-262837-media-c12">416</td><td class="excel-262837-media-c12">481</td><td class="excel-262837-media-c13">418</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;9%</td><td class="excel-262837-media-c12">635</td><td class="excel-262837-media-c12">733</td><td class="excel-262837-media-c12">816</td><td class="excel-262837-media-c12">922</td><td class="excel-262837-media-c12">1,731</td><td class="excel-262837-media-c12">2,279</td><td class="excel-262837-media-c12">1,895</td><td class="excel-262837-media-c12">1,130</td><td class="excel-262837-media-c12">943</td><td class="excel-262837-media-c12">837</td><td class="excel-262837-media-c12">674</td><td class="excel-262837-media-c12">600</td><td class="excel-262837-media-c12">530</td><td class="excel-262837-media-c13">471</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">15</td><td class="excel-262837-media-c12">22</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">55</td><td class="excel-262837-media-c12">89</td><td class="excel-262837-media-c12">231</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c12">103</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">16</td><td class="excel-262837-media-c12">17</td><td class="excel-262837-media-c13">13</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of People Renting in ED</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&gt;40%</td><td class="excel-262837-media-c12">349</td><td class="excel-262837-media-c12">492</td><td class="excel-262837-media-c12">627</td><td class="excel-262837-media-c12">785</td><td class="excel-262837-media-c12">1,352</td><td class="excel-262837-media-c12">1,653</td><td class="excel-262837-media-c12">1,431</td><td class="excel-262837-media-c12">920</td><td class="excel-262837-media-c12">638</td><td class="excel-262837-media-c12">749</td><td class="excel-262837-media-c12">654</td><td class="excel-262837-media-c12">457</td><td class="excel-262837-media-c12">452</td><td class="excel-262837-media-c13">433</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">25%-40%</td><td class="excel-262837-media-c12">452</td><td class="excel-262837-media-c12">629</td><td class="excel-262837-media-c12">777</td><td class="excel-262837-media-c12">1,090</td><td class="excel-262837-media-c12">1,704</td><td class="excel-262837-media-c12">2,179</td><td class="excel-262837-media-c12">1,889</td><td class="excel-262837-media-c12">951</td><td class="excel-262837-media-c12">895</td><td class="excel-262837-media-c12">858</td><td class="excel-262837-media-c12">696</td><td class="excel-262837-media-c12">615</td><td class="excel-262837-media-c12">681</td><td class="excel-262837-media-c13">529</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">15%-24%</td><td class="excel-262837-media-c12">374</td><td class="excel-262837-media-c12">411</td><td class="excel-262837-media-c12">508</td><td class="excel-262837-media-c12">677</td><td class="excel-262837-media-c12">1,178</td><td class="excel-262837-media-c12">1,486</td><td class="excel-262837-media-c12">1,116</td><td class="excel-262837-media-c12">552</td><td class="excel-262837-media-c12">497</td><td class="excel-262837-media-c12">493</td><td class="excel-262837-media-c12">393</td><td class="excel-262837-media-c12">329</td><td class="excel-262837-media-c12">370</td><td class="excel-262837-media-c13">305</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;15%</td><td class="excel-262837-media-c12">464</td><td class="excel-262837-media-c12">526</td><td class="excel-262837-media-c12">495</td><td class="excel-262837-media-c12">612</td><td class="excel-262837-media-c12">1,362</td><td class="excel-262837-media-c12">1,618</td><td class="excel-262837-media-c12">1,796</td><td class="excel-262837-media-c12">1,223</td><td class="excel-262837-media-c12">900</td><td class="excel-262837-media-c12">558</td><td class="excel-262837-media-c12">426</td><td class="excel-262837-media-c12">425</td><td class="excel-262837-media-c12">417</td><td class="excel-262837-media-c13">414</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">15</td><td class="excel-262837-media-c12">22</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">55</td><td class="excel-262837-media-c12">89</td><td class="excel-262837-media-c12">231</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c12">103</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">16</td><td class="excel-262837-media-c12">17</td><td class="excel-262837-media-c13">13</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">HP Pobal Deprivation Index</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">First quintile - Very disadvantaged</td><td class="excel-262837-media-c12">249</td><td class="excel-262837-media-c12">309</td><td class="excel-262837-media-c12">314</td><td class="excel-262837-media-c12">510</td><td class="excel-262837-media-c12">733</td><td class="excel-262837-media-c12">935</td><td class="excel-262837-media-c12">931</td><td class="excel-262837-media-c12">519</td><td class="excel-262837-media-c12">415</td><td class="excel-262837-media-c12">392</td><td class="excel-262837-media-c12">334</td><td class="excel-262837-media-c12">227</td><td class="excel-262837-media-c12">286</td><td class="excel-262837-media-c13">310</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Second quintile - Disadvantaged</td><td class="excel-262837-media-c12">378</td><td class="excel-262837-media-c12">411</td><td class="excel-262837-media-c12">580</td><td class="excel-262837-media-c12">860</td><td class="excel-262837-media-c12">1,381</td><td class="excel-262837-media-c12">1,655</td><td class="excel-262837-media-c12">1,523</td><td class="excel-262837-media-c12">851</td><td class="excel-262837-media-c12">709</td><td class="excel-262837-media-c12">668</td><td class="excel-262837-media-c12">539</td><td class="excel-262837-media-c12">424</td><td class="excel-262837-media-c12">477</td><td class="excel-262837-media-c13">448</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Third quintile - Average</td><td class="excel-262837-media-c12">284</td><td class="excel-262837-media-c12">414</td><td class="excel-262837-media-c12">461</td><td class="excel-262837-media-c12">637</td><td class="excel-262837-media-c12">1,260</td><td class="excel-262837-media-c12">1,547</td><td class="excel-262837-media-c12">1,453</td><td class="excel-262837-media-c12">816</td><td class="excel-262837-media-c12">670</td><td class="excel-262837-media-c12">611</td><td class="excel-262837-media-c12">546</td><td class="excel-262837-media-c12">513</td><td class="excel-262837-media-c12">504</td><td class="excel-262837-media-c13">387</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Fourth quintile - Affluent</td><td class="excel-262837-media-c12">371</td><td class="excel-262837-media-c12">552</td><td class="excel-262837-media-c12">622</td><td class="excel-262837-media-c12">733</td><td class="excel-262837-media-c12">1,473</td><td class="excel-262837-media-c12">1,912</td><td class="excel-262837-media-c12">1,597</td><td class="excel-262837-media-c12">886</td><td class="excel-262837-media-c12">812</td><td class="excel-262837-media-c12">673</td><td class="excel-262837-media-c12">408</td><td class="excel-262837-media-c12">411</td><td class="excel-262837-media-c12">368</td><td class="excel-262837-media-c13">324</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Fifth quintile - Very affluent (least deprived)</td><td class="excel-262837-media-c12">291</td><td class="excel-262837-media-c12">371</td><td class="excel-262837-media-c12">441</td><td class="excel-262837-media-c12">424</td><td class="excel-262837-media-c12">722</td><td class="excel-262837-media-c12">908</td><td class="excel-262837-media-c12">728</td><td class="excel-262837-media-c12">504</td><td class="excel-262837-media-c12">324</td><td class="excel-262837-media-c12">314</td><td class="excel-262837-media-c12">342</td><td class="excel-262837-media-c12">251</td><td class="excel-262837-media-c12">285</td><td class="excel-262837-media-c13">212</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">81</td><td class="excel-262837-media-c12">23</td><td class="excel-262837-media-c12">25</td><td class="excel-262837-media-c12">30</td><td class="excel-262837-media-c12">82</td><td class="excel-262837-media-c12">68</td><td class="excel-262837-media-c12">231</td><td class="excel-262837-media-c12">550</td><td class="excel-262837-media-c12">103</td><td class="excel-262837-media-c12">36</td><td class="excel-262837-media-c12">29</td><td class="excel-262837-media-c12">16</td><td class="excel-262837-media-c12">17</td><td class="excel-262837-media-c13">13</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of medical card holders in ED<b><sup> 9</sup></b></td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">41% +</td><td class="excel-262837-media-c12">534</td><td class="excel-262837-media-c12">584</td><td class="excel-262837-media-c12">761</td><td class="excel-262837-media-c12">1,137</td><td class="excel-262837-media-c12">1,781</td><td class="excel-262837-media-c12">2,083</td><td class="excel-262837-media-c12">2,016</td><td class="excel-262837-media-c12">1,045</td><td class="excel-262837-media-c12">998</td><td class="excel-262837-media-c12">889</td><td class="excel-262837-media-c12">748</td><td class="excel-262837-media-c12">606</td><td class="excel-262837-media-c12">670</td><td class="excel-262837-media-c13">642</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">32%-40.99%</td><td class="excel-262837-media-c12">283</td><td class="excel-262837-media-c12">370</td><td class="excel-262837-media-c12">435</td><td class="excel-262837-media-c12">683</td><td class="excel-262837-media-c12">1,310</td><td class="excel-262837-media-c12">1,644</td><td class="excel-262837-media-c12">1,449</td><td class="excel-262837-media-c12">723</td><td class="excel-262837-media-c12">646</td><td class="excel-262837-media-c12">642</td><td class="excel-262837-media-c12">465</td><td class="excel-262837-media-c12">349</td><td class="excel-262837-media-c12">454</td><td class="excel-262837-media-c13">376</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">25%-31.99%</td><td class="excel-262837-media-c12">332</td><td class="excel-262837-media-c12">506</td><td class="excel-262837-media-c12">504</td><td class="excel-262837-media-c12">568</td><td class="excel-262837-media-c12">1,082</td><td class="excel-262837-media-c12">1,308</td><td class="excel-262837-media-c12">1,206</td><td class="excel-262837-media-c12">874</td><td class="excel-262837-media-c12">537</td><td class="excel-262837-media-c12">514</td><td class="excel-262837-media-c12">434</td><td class="excel-262837-media-c12">363</td><td class="excel-262837-media-c12">345</td><td class="excel-262837-media-c13">299</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;25%</td><td class="excel-262837-media-c12">490</td><td class="excel-262837-media-c12">598</td><td class="excel-262837-media-c12">707</td><td class="excel-262837-media-c12">776</td><td class="excel-262837-media-c12">1,423</td><td class="excel-262837-media-c12">1,901</td><td class="excel-262837-media-c12">1,561</td><td class="excel-262837-media-c12">1,004</td><td class="excel-262837-media-c12">749</td><td class="excel-262837-media-c12">613</td><td class="excel-262837-media-c12">522</td><td class="excel-262837-media-c12">508</td><td class="excel-262837-media-c12">451</td><td class="excel-262837-media-c13">364</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c14">Unknown</td><td class="excel-262837-media-c15">15</td><td class="excel-262837-media-c15">22</td><td class="excel-262837-media-c15">36</td><td class="excel-262837-media-c15">30</td><td class="excel-262837-media-c15">55</td><td class="excel-262837-media-c15">89</td><td class="excel-262837-media-c15">231</td><td class="excel-262837-media-c15">550</td><td class="excel-262837-media-c15">103</td><td class="excel-262837-media-c15">36</td><td class="excel-262837-media-c15">29</td><td class="excel-262837-media-c15">16</td><td class="excel-262837-media-c15">17</td><td class="excel-262837-media-c16">13</td>
</tr>
<tr class="excel-262837-media-r1"></tr>
<tr class="excel-262837-media-r1"></tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c1" colspan="16">Table 4a: Weekly Electoral Division (ED) Analysis of Cumulative Confirmed Covid-19 Cases (%) <b><sup>1,2,3,10,12</sup></b></td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c1">&nbsp;</td><td class="excel-262837-media-c17" colspan="15">2020</td>
</tr>
<tr class="excel-262837-media-r2">
<td class="excel-262837-media-c3">&nbsp;</td><td class="excel-262837-media-c4">11/09</td><td class="excel-262837-media-c4">18/09</td><td class="excel-262837-media-c4">25/09</td><td class="excel-262837-media-c4">02/10</td><td class="excel-262837-media-c4">09/10</td><td class="excel-262837-media-c4">16/10</td><td class="excel-262837-media-c4">23/10</td><td class="excel-262837-media-c4">30/11</td><td class="excel-262837-media-c4">06/11</td><td class="excel-262837-media-c4">13/11</td><td class="excel-262837-media-c4">20/11</td><td class="excel-262837-media-c4">27/11</td><td class="excel-262837-media-c4">04/12</td><td class="excel-262837-media-c4">11/12*</td><td class="excel-262837-media-c4">% Gen Pop</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Urban / Rural <b><sup>4</sup></b></td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Cities</td><td class="excel-262837-media-c12">43%</td><td class="excel-262837-media-c12">43%</td><td class="excel-262837-media-c12">44%</td><td class="excel-262837-media-c12">44%</td><td class="excel-262837-media-c12">43%</td><td class="excel-262837-media-c12">42%</td><td class="excel-262837-media-c12">41%</td><td class="excel-262837-media-c12">41%</td><td class="excel-262837-media-c12">41%</td><td class="excel-262837-media-c12">41%</td><td class="excel-262837-media-c12">40%</td><td class="excel-262837-media-c12">40%</td><td class="excel-262837-media-c12">40%</td><td class="excel-262837-media-c13">40%</td><td class="excel-262837-media-c6">33%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Satellite urban towns</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c13">14%</td><td class="excel-262837-media-c6">14%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Independent urban towns</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c13">16%</td><td class="excel-262837-media-c6">18%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Rural areas with high urban influence</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c13">12%</td><td class="excel-262837-media-c6">16%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Rural areas with moderate urban influence</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c13">9%</td><td class="excel-262837-media-c6">12%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Highly rural / remote areas</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c13">5%</td><td class="excel-262837-media-c6">7%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c7">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Population Density <b><sup>5</sup></b></td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c7">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">0- 50 people per km<sup>2</sup></td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">17%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c13">19%</td><td class="excel-262837-media-c6">26%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">50 - 500 people per km<sup>2</sup></td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c13">26%</td><td class="excel-262837-media-c6">28%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">500 - 2,500 people per km<sup>2</sup></td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c13">22%</td><td class="excel-262837-media-c6">21%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&gt; 2,500 people per km<sup>2</sup></td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c13">29%</td><td class="excel-262837-media-c6">25%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Median Household Income <b><sup>6</sup></b></td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c11">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt; 30k</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c13">6%</td><td class="excel-262837-media-c6">5%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">30k - 40k </td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c13">24%</td><td class="excel-262837-media-c6">25%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">40k - 50k</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c13">28%</td><td class="excel-262837-media-c6">30%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">50k - 60k</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c13">20%</td><td class="excel-262837-media-c6">21%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">60k - 70k </td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">15%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">14%</td><td class="excel-262837-media-c12">13%</td><td class="excel-262837-media-c13">13%</td><td class="excel-262837-media-c6">13%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">70k - 80k</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">3%</td><td class="excel-262837-media-c12">3%</td><td class="excel-262837-media-c12">3%</td><td class="excel-262837-media-c13">3%</td><td class="excel-262837-media-c6">4%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">80k - 90k</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c12">2%</td><td class="excel-262837-media-c13">2%</td><td class="excel-262837-media-c6">2%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">90k +</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">1%</td><td class="excel-262837-media-c12">0%</td><td class="excel-262837-media-c13">0%</td><td class="excel-262837-media-c6">0%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td></td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c7">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of HH's where working age social welfare was majority of income in ED <b><sup>7</sup></b></td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c11">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">20% +</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c13">22%</td><td class="excel-262837-media-c6">29%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">13%-19.99%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c12">26%</td><td class="excel-262837-media-c13">26%</td><td class="excel-262837-media-c6">23%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">9%-12.99%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c13">20%</td><td class="excel-262837-media-c6">24%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;9%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c13">28%</td><td class="excel-262837-media-c6">24%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c18">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td><td class="excel-262837-media-c7">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of HH's where state pension was majority of income in ED <b><sup>8</sup></b></td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c11">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">20% +</td><td class="excel-262837-media-c12">8%</td><td class="excel-262837-media-c12">8%</td><td class="excel-262837-media-c12">8%</td><td class="excel-262837-media-c12">8%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">9%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c13">10%</td><td class="excel-262837-media-c6">26%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">13%-19.99%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">30%</td><td class="excel-262837-media-c12">30%</td><td class="excel-262837-media-c12">30%</td><td class="excel-262837-media-c13">30%</td><td class="excel-262837-media-c6">25%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">9%-12.99%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c13">24%</td><td class="excel-262837-media-c6">24%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;9%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c13">32%</td><td class="excel-262837-media-c6">25%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of People Renting in ED</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&gt;40%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c13">23%</td><td class="excel-262837-media-c6">20%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">25%-40%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">33%</td><td class="excel-262837-media-c12">32%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c12">31%</td><td class="excel-262837-media-c13">31%</td><td class="excel-262837-media-c6">32%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">15%-24%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c13">19%</td><td class="excel-262837-media-c6">21%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;15%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c13">23%</td><td class="excel-262837-media-c6">27%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">HP Pobal Deprivation Index</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c12">&nbsp;</td><td class="excel-262837-media-c13">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">First quintile - Very disadvantaged</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c12">17%</td><td class="excel-262837-media-c12">17%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c12">16%</td><td class="excel-262837-media-c13">16%</td><td class="excel-262837-media-c6">12%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Second quintile - Disadvantaged</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">25%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c12">24%</td><td class="excel-262837-media-c13">24%</td><td class="excel-262837-media-c6">25%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Third quintile - Average</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c13">21%</td><td class="excel-262837-media-c6">24%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Fourth quintile - Affluent</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">22%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c12">23%</td><td class="excel-262837-media-c13">23%</td><td class="excel-262837-media-c6">25%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Fifth quintile - Very affluent (least deprived)</td><td class="excel-262837-media-c12">10%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">11%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c12">12%</td><td class="excel-262837-media-c13">12%</td><td class="excel-262837-media-c6">15%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">Unknown</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c18">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c19">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c5">Proportion of medical card holders in ED<b><sup> 9</sup></b></td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c5">&nbsp;</td><td class="excel-262837-media-c19">&nbsp;</td><td class="excel-262837-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">41% +</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">28%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">30%</td><td class="excel-262837-media-c13">30%</td><td class="excel-262837-media-c6">24%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">32%-40.99%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">20%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c12">21%</td><td class="excel-262837-media-c13">21%</td><td class="excel-262837-media-c6">24%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">25%-31.99%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">19%</td><td class="excel-262837-media-c12">18%</td><td class="excel-262837-media-c13">18%</td><td class="excel-262837-media-c6">23%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10">&lt;25%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">29%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c12">27%</td><td class="excel-262837-media-c13">27%</td><td class="excel-262837-media-c6">29%</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c14">Unknown</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">6%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">5%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c12">4%</td><td class="excel-262837-media-c13">4%</td><td class="excel-262837-media-c20">&nbsp;</td>
</tr>
<tr class="excel-262837-media-r3">
<td class="excel-262837-media-c21" colspan="16">* latest week is preliminary</td>
</tr>
<tr class="excel-262837-media-r4">
<td class="excel-262837-media-c10" colspan="16"><sup>1 </sup>Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
<tr class="excel-262837-media-r3">
<td class="excel-262837-media-c10" colspan="16"><sup>2 </sup>Data is defined by epidemiological date which is the earliest of onset date, date of diagnosis, laboratory specimen collection date, laboratory received date, laboratory reported date and event creation/notification date</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10" colspan="16"><sup>3</sup> '..' Indicates a cell number &lt; 5 or a cell number &lt; 5 can be identified</td>
</tr>
<tr class="excel-262837-media-r4">
<td class="excel-262837-media-c10" colspan="16"><sup>4</sup> Urban Rural definitions from Urban and Rural Life in Ireland 2019, https://www.cso.ie/en/releasesandpublications/ep/p-urli/urbanandrurallifeinireland2019/</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10" colspan="16"><sup>5</sup> Census of Population 2016</td>
</tr>
<tr class="excel-262837-media-r1">
<td class="excel-262837-media-c10" colspan="16"><sup>6</sup> Median Household Income per Electoral Division from Geographical Profiles of Income in Ireland 2016, https://www.cso.ie/en/releasesandpublications/ep/p-gpii/geographicalprofilesofincomeinireland2016/</td>
</tr>
<tr class="excel-262837-media-r5">
<td class="excel-262837-media-c10" colspan="16"><sup>7</sup> Proportion of households where working age social welfare was majority of income by ED from Geographical Profiles of Income in Ireland 2016, https://www.cso.ie/en/releasesandpublications/ep/p-gpii/geographicalprofilesofincomeinireland2016/</td>
</tr>
<tr class="excel-262837-media-r6">
<td class="excel-262837-media-c10" colspan="16"><sup>8</sup> Proportion of households where state pension was majority of income by ED from Geographical Profiles of Income in Ireland 2016, https://www.cso.ie/en/releasesandpublications/ep/p-gpii/geographicalprofilesofincomeinireland2016/</td>
</tr>
<tr class="excel-262837-media-r2">
<td class="excel-262837-media-c10" colspan="16"><sup>9</sup> Proportion of medical card holders by ED from Geographical Profiles of Income in Ireland 2016, https://www.cso.ie/en/releasesandpublications/ep/p-gpii/geographicalprofilesofincomeinireland2016/</td>
</tr>
<tr class="excel-262837-media-r3">
<td class="excel-262837-media-c10" colspan="16"><sup>10</sup> Unknown is where ED is not available in CIDR</td>
</tr>
<tr class="excel-262837-media-r3">
<td class="excel-262837-media-c10" colspan="16"><sup>11 </sup>Week ending 06/03/2020 includes all cases up to that date, including previous weeks.</td>
</tr>
<tr class="excel-262837-media-r3">
<td class="excel-262837-media-c10" colspan="16"><sup>12</sup> General Population from Census 2016</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL4.xlsx">COVID-19 Deaths and Cases Series 18 - Table 4 (XLS 22KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262837_description").click(function(){
    $("#262837_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262837_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262841_description">
    <span id="#262841_openClose">Show Table</span>: Table 5 Average Contacts per Positive COVID-19 case by Age Group
  </div>

<div style="clear: both"></div>

<div id="262841_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262841-insertexceltable">
<div id="table-262841-1-insertexceltable">
<table class="excel-262841-media-t1">
<colgroup>
<col width="157">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="56">
<col width="56">
<col width="56">
</colgroup>
<tbody>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c1" colspan="15">Table 5: Average Contacts per Positive COVID-19 Case by Age Group <b><sup>1</sup></b></td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c1">&nbsp;</td><td class="excel-262841-media-c2" colspan="14">2020</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c3">&nbsp;</td><td class="excel-262841-media-c4">11/09</td><td class="excel-262841-media-c4">18/09</td><td class="excel-262841-media-c4">25/09</td><td class="excel-262841-media-c4">02/10</td><td class="excel-262841-media-c4">09/10</td><td class="excel-262841-media-c4">16/10</td><td class="excel-262841-media-c4">23/10</td><td class="excel-262841-media-c4">30/10</td><td class="excel-262841-media-c4">06/11</td><td class="excel-262841-media-c4">13/11</td><td class="excel-262841-media-c4">20/11</td><td class="excel-262841-media-c4">27/11</td><td class="excel-262841-media-c4">04/12</td><td class="excel-262841-media-c4">11/12</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c5">0-14 years</td><td class="excel-262841-media-c6">10.61</td><td class="excel-262841-media-c6">9.07</td><td class="excel-262841-media-c6">5.28</td><td class="excel-262841-media-c7">3.45</td><td class="excel-262841-media-c7">3.03</td><td class="excel-262841-media-c7">2.98</td><td class="excel-262841-media-c7">2.23</td><td class="excel-262841-media-c7">2.59</td><td class="excel-262841-media-c7">2.50</td><td class="excel-262841-media-c7">2.80</td><td class="excel-262841-media-c7">2.21</td><td class="excel-262841-media-c7">2.67</td><td class="excel-262841-media-c7">2.67</td><td class="excel-262841-media-c7">2.68</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c5">15-24 years</td><td class="excel-262841-media-c6">7.56</td><td class="excel-262841-media-c6">7.38</td><td class="excel-262841-media-c6">5.90</td><td class="excel-262841-media-c6">6.34</td><td class="excel-262841-media-c6">5.06</td><td class="excel-262841-media-c6">4.03</td><td class="excel-262841-media-c6">3.49</td><td class="excel-262841-media-c6">3.34</td><td class="excel-262841-media-c6">3.82</td><td class="excel-262841-media-c6">4.18</td><td class="excel-262841-media-c6">3.70</td><td class="excel-262841-media-c6">4.17</td><td class="excel-262841-media-c6">3.56</td><td class="excel-262841-media-c6">4.16</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c5">25-44 years</td><td class="excel-262841-media-c6">5.43</td><td class="excel-262841-media-c6">4.84</td><td class="excel-262841-media-c6">4.65</td><td class="excel-262841-media-c6">4.83</td><td class="excel-262841-media-c6">4.35</td><td class="excel-262841-media-c6">3.23</td><td class="excel-262841-media-c6">3.46</td><td class="excel-262841-media-c6">3.25</td><td class="excel-262841-media-c6">3.51</td><td class="excel-262841-media-c6">3.55</td><td class="excel-262841-media-c6">3.67</td><td class="excel-262841-media-c6">3.41</td><td class="excel-262841-media-c6">3.63</td><td class="excel-262841-media-c6">3.62</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c5">45-64 years</td><td class="excel-262841-media-c6">5.25</td><td class="excel-262841-media-c6">4.61</td><td class="excel-262841-media-c6">4.15</td><td class="excel-262841-media-c6">3.72</td><td class="excel-262841-media-c6">3.94</td><td class="excel-262841-media-c6">3.08</td><td class="excel-262841-media-c6">3.22</td><td class="excel-262841-media-c6">2.70</td><td class="excel-262841-media-c6">3.36</td><td class="excel-262841-media-c6">3.13</td><td class="excel-262841-media-c6">3.34</td><td class="excel-262841-media-c6">3.29</td><td class="excel-262841-media-c6">2.94</td><td class="excel-262841-media-c6">3.22</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c5">65-79 years</td><td class="excel-262841-media-c6">4.16</td><td class="excel-262841-media-c6">4.59</td><td class="excel-262841-media-c6">4.10</td><td class="excel-262841-media-c6">2.95</td><td class="excel-262841-media-c6">3.03</td><td class="excel-262841-media-c6">3.07</td><td class="excel-262841-media-c6">3.18</td><td class="excel-262841-media-c6">2.41</td><td class="excel-262841-media-c6">2.48</td><td class="excel-262841-media-c6">2.24</td><td class="excel-262841-media-c6">2.68</td><td class="excel-262841-media-c6">1.98</td><td class="excel-262841-media-c6">2.14</td><td class="excel-262841-media-c6">2.66</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c5">80 years and over</td><td class="excel-262841-media-c6">2.07</td><td class="excel-262841-media-c6">4.20</td><td class="excel-262841-media-c6">2.23</td><td class="excel-262841-media-c6">2.37</td><td class="excel-262841-media-c6">2.16</td><td class="excel-262841-media-c6">2.16</td><td class="excel-262841-media-c6">2.09</td><td class="excel-262841-media-c6">2.44</td><td class="excel-262841-media-c6">2.90</td><td class="excel-262841-media-c6">1.95</td><td class="excel-262841-media-c6">2.34</td><td class="excel-262841-media-c6">2.36</td><td class="excel-262841-media-c6">2.77</td><td class="excel-262841-media-c6">2.96</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c3">All ages</td><td class="excel-262841-media-c8">6.27</td><td class="excel-262841-media-c6">5.58</td><td class="excel-262841-media-c6">4.75</td><td class="excel-262841-media-c8">4.64</td><td class="excel-262841-media-c8">4.23</td><td class="excel-262841-media-c8">3.28</td><td class="excel-262841-media-c8">3.14</td><td class="excel-262841-media-c8">2.97</td><td class="excel-262841-media-c8">3.33</td><td class="excel-262841-media-c8">3.35</td><td class="excel-262841-media-c8">3.34</td><td class="excel-262841-media-c8">3.27</td><td class="excel-262841-media-c8">3.12</td><td class="excel-262841-media-c8">3.44</td>
</tr>
<tr class="excel-262841-media-r1">
<td class="excel-262841-media-c9" colspan="15"><sup>1 </sup>Table includes data as of 16th December 2020 for contacts of positive COVID-19 cases from CCT (COVID Care Tracker) data up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL5.xlsx">COVID-19 Deaths and Cases Series 18 - Table 5 (XLS 11KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262841_description").click(function(){
    $("#262841_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262841_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262824_description">
    <span id="#262824_openClose">Show Table</span>: Table 6 &amp; 6A Weekly Profile of New COVID-19 Cases who are Subsequently Hospitalised 
  </div>

<div style="clear: both"></div>

<div id="262824_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262824-insertexceltable">
<div id="table-262824-1-insertexceltable">
<table class="excel-262824-media-t1">
<colgroup>
<col width="204">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
</colgroup>
<tbody>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c1" colspan="15">Table 6: Weekly Profile of New COVID-19 Cases who are Subsequently Hospitalised <b><sup>1,2,3,4</sup></b></td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c2">&nbsp;</td><td class="excel-262824-media-c3" colspan="14">2020</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c4">&nbsp;</td><td class="excel-262824-media-c4">11/09</td><td class="excel-262824-media-c4">18/09</td><td class="excel-262824-media-c4">25/09</td><td class="excel-262824-media-c4">02/10</td><td class="excel-262824-media-c4">09/10</td><td class="excel-262824-media-c4">16/10</td><td class="excel-262824-media-c4">23/10</td><td class="excel-262824-media-c4">30/10</td><td class="excel-262824-media-c4">06/11</td><td class="excel-262824-media-c4">13/11</td><td class="excel-262824-media-c4">20/11</td><td class="excel-262824-media-c4">27/11</td><td class="excel-262824-media-c4">04/12</td><td class="excel-262824-media-c4">11/12*</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Hospitalised</td><td class="excel-262824-media-c6">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c8">&nbsp;</td><td class="excel-262824-media-c8">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Total</td><td class="excel-262824-media-c9">98</td><td class="excel-262824-media-c9">118</td><td class="excel-262824-media-c9">86</td><td class="excel-262824-media-c9">120</td><td class="excel-262824-media-c9">199</td><td class="excel-262824-media-c9">228</td><td class="excel-262824-media-c9">249</td><td class="excel-262824-media-c9">174</td><td class="excel-262824-media-c9">204</td><td class="excel-262824-media-c9">168</td><td class="excel-262824-media-c9">143</td><td class="excel-262824-media-c9">110</td><td class="excel-262824-media-c9">88</td><td class="excel-262824-media-c10">57</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Gender</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td><td class="excel-262824-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Female</td><td class="excel-262824-media-c12">44</td><td class="excel-262824-media-c12">57</td><td class="excel-262824-media-c12">41</td><td class="excel-262824-media-c12">62</td><td class="excel-262824-media-c12">90</td><td class="excel-262824-media-c12">109</td><td class="excel-262824-media-c12">121</td><td class="excel-262824-media-c12">93</td><td class="excel-262824-media-c12">107</td><td class="excel-262824-media-c12">86</td><td class="excel-262824-media-c12">66</td><td class="excel-262824-media-c12">49</td><td class="excel-262824-media-c12">37</td><td class="excel-262824-media-c13">29</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Male</td><td class="excel-262824-media-c12">53</td><td class="excel-262824-media-c12">61</td><td class="excel-262824-media-c12">45</td><td class="excel-262824-media-c12">58</td><td class="excel-262824-media-c12">109</td><td class="excel-262824-media-c12">118</td><td class="excel-262824-media-c12">128</td><td class="excel-262824-media-c12">81</td><td class="excel-262824-media-c12">95</td><td class="excel-262824-media-c12">82</td><td class="excel-262824-media-c12">77</td><td class="excel-262824-media-c12">61</td><td class="excel-262824-media-c12">51</td><td class="excel-262824-media-c13">28</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c13">0</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Age Group</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">0-24</td><td class="excel-262824-media-c12">19</td><td class="excel-262824-media-c12">14</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">16</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">18</td><td class="excel-262824-media-c12">13</td><td class="excel-262824-media-c12">17</td><td class="excel-262824-media-c12">10</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">25-44</td><td class="excel-262824-media-c12">25</td><td class="excel-262824-media-c12">26</td><td class="excel-262824-media-c12">18</td><td class="excel-262824-media-c12">29</td><td class="excel-262824-media-c12">23</td><td class="excel-262824-media-c12">61</td><td class="excel-262824-media-c12">39</td><td class="excel-262824-media-c12">43</td><td class="excel-262824-media-c12">39</td><td class="excel-262824-media-c12">26</td><td class="excel-262824-media-c12">27</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">12</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">45-64</td><td class="excel-262824-media-c12">30</td><td class="excel-262824-media-c12">40</td><td class="excel-262824-media-c12">22</td><td class="excel-262824-media-c12">40</td><td class="excel-262824-media-c12">67</td><td class="excel-262824-media-c12">54</td><td class="excel-262824-media-c12">69</td><td class="excel-262824-media-c12">39</td><td class="excel-262824-media-c12">43</td><td class="excel-262824-media-c12">44</td><td class="excel-262824-media-c12">24</td><td class="excel-262824-media-c12">28</td><td class="excel-262824-media-c12">23</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">65-79</td><td class="excel-262824-media-c12">17</td><td class="excel-262824-media-c12">30</td><td class="excel-262824-media-c12">24</td><td class="excel-262824-media-c12">22</td><td class="excel-262824-media-c12">53</td><td class="excel-262824-media-c12">51</td><td class="excel-262824-media-c12">75</td><td class="excel-262824-media-c12">39</td><td class="excel-262824-media-c12">53</td><td class="excel-262824-media-c12">54</td><td class="excel-262824-media-c12">45</td><td class="excel-262824-media-c12">34</td><td class="excel-262824-media-c12">29</td><td class="excel-262824-media-c13">21</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">80+</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">14</td><td class="excel-262824-media-c12">13</td><td class="excel-262824-media-c12">33</td><td class="excel-262824-media-c12">44</td><td class="excel-262824-media-c12">53</td><td class="excel-262824-media-c12">36</td><td class="excel-262824-media-c12">59</td><td class="excel-262824-media-c12">36</td><td class="excel-262824-media-c12">40</td><td class="excel-262824-media-c12">33</td><td class="excel-262824-media-c12">18</td><td class="excel-262824-media-c13">9</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c13">0</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td></td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Median Age</td><td class="excel-262824-media-c12">46</td><td class="excel-262824-media-c12">55</td><td class="excel-262824-media-c12">61</td><td class="excel-262824-media-c12">53</td><td class="excel-262824-media-c12">61</td><td class="excel-262824-media-c12">59</td><td class="excel-262824-media-c12">66</td><td class="excel-262824-media-c12">59</td><td class="excel-262824-media-c12">68</td><td class="excel-262824-media-c12">68</td><td class="excel-262824-media-c12">71</td><td class="excel-262824-media-c12">72</td><td class="excel-262824-media-c12">67</td><td class="excel-262824-media-c13">65</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Underlying clinical conditions</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Yes</td><td class="excel-262824-media-c12">38</td><td class="excel-262824-media-c12">65</td><td class="excel-262824-media-c12">53</td><td class="excel-262824-media-c12">67</td><td class="excel-262824-media-c12">88</td><td class="excel-262824-media-c12">82</td><td class="excel-262824-media-c12">76</td><td class="excel-262824-media-c12">68</td><td class="excel-262824-media-c12">113</td><td class="excel-262824-media-c12">111</td><td class="excel-262824-media-c12">93</td><td class="excel-262824-media-c12">81</td><td class="excel-262824-media-c12">63</td><td class="excel-262824-media-c13">42</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">No</td><td class="excel-262824-media-c12">53</td><td class="excel-262824-media-c12">51</td><td class="excel-262824-media-c12">28</td><td class="excel-262824-media-c12">45</td><td class="excel-262824-media-c12">84</td><td class="excel-262824-media-c12">94</td><td class="excel-262824-media-c12">132</td><td class="excel-262824-media-c12">75</td><td class="excel-262824-media-c12">77</td><td class="excel-262824-media-c12">49</td><td class="excel-262824-media-c12">36</td><td class="excel-262824-media-c12">19</td><td class="excel-262824-media-c12">18</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">5</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">27</td><td class="excel-262824-media-c12">52</td><td class="excel-262824-media-c12">41</td><td class="excel-262824-media-c12">31</td><td class="excel-262824-media-c12">14</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">14</td><td class="excel-262824-media-c12">10</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">of which Admitted to ICU</td><td class="excel-262824-media-c13">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Total</td><td class="excel-262824-media-c9">10</td><td class="excel-262824-media-c9">11</td><td class="excel-262824-media-c9">13</td><td class="excel-262824-media-c9">14</td><td class="excel-262824-media-c9">15</td><td class="excel-262824-media-c9">25</td><td class="excel-262824-media-c9">27</td><td class="excel-262824-media-c9">15</td><td class="excel-262824-media-c9">19</td><td class="excel-262824-media-c9">12</td><td class="excel-262824-media-c9">11</td><td class="excel-262824-media-c9">7</td><td class="excel-262824-media-c9">9</td><td class="excel-262824-media-c10">5</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Gender</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Female</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">5</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">6</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Male</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">11</td><td class="excel-262824-media-c12">9</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">18</td><td class="excel-262824-media-c12">21</td><td class="excel-262824-media-c12">13</td><td class="excel-262824-media-c12">12</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">9</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">5</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">0</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Age Group</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">0-24</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c13">0</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">25-44</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">45-64</td><td class="excel-262824-media-c12">5</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">6</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">10</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">6</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">65-79</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">6</td><td class="excel-262824-media-c12">9</td><td class="excel-262824-media-c12">5</td><td class="excel-262824-media-c12">12</td><td class="excel-262824-media-c12">11</td><td class="excel-262824-media-c12">18</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">6</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">5</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">..</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">80+</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">11</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">0</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c13">0</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Median Age</td><td class="excel-262824-media-c12">63</td><td class="excel-262824-media-c12">70</td><td class="excel-262824-media-c12">67</td><td class="excel-262824-media-c12">64</td><td class="excel-262824-media-c12">72</td><td class="excel-262824-media-c12">64</td><td class="excel-262824-media-c12">71</td><td class="excel-262824-media-c12">66</td><td class="excel-262824-media-c12">65</td><td class="excel-262824-media-c12">54</td><td class="excel-262824-media-c12">71</td><td class="excel-262824-media-c12">56</td><td class="excel-262824-media-c12">66</td><td class="excel-262824-media-c13">65</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Underlying clinical conditions</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Yes</td><td class="excel-262824-media-c12">7</td><td class="excel-262824-media-c12">11</td><td class="excel-262824-media-c12">12</td><td class="excel-262824-media-c12">14</td><td class="excel-262824-media-c12">13</td><td class="excel-262824-media-c12">23</td><td class="excel-262824-media-c12">25</td><td class="excel-262824-media-c12">13</td><td class="excel-262824-media-c12">17</td><td class="excel-262824-media-c12">10</td><td class="excel-262824-media-c12">11</td><td class="excel-262824-media-c12">5</td><td class="excel-262824-media-c12">8</td><td class="excel-262824-media-c13">5</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">No</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">0</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c12">..</td><td class="excel-262824-media-c13">0</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c2">Not Specified</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">0</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">0</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">0</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c14">..</td><td class="excel-262824-media-c15">0</td>
</tr>
<tr class="excel-262824-media-r1"></tr>
<tr class="excel-262824-media-r1">
<td></td><td class="excel-262824-media-c6">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c6">&nbsp;</td><td class="excel-262824-media-c6">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c1" colspan="15">Table 6A Weekly Profile of Hospitalisations of Cumulative Confirmed COVID-19 Cases (%) <b><sup>1,2,3</sup></b></td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c2">&nbsp;</td><td class="excel-262824-media-c3" colspan="14">2020</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c4">&nbsp;</td><td class="excel-262824-media-c4">11/09</td><td class="excel-262824-media-c4">18/09</td><td class="excel-262824-media-c4">25/09</td><td class="excel-262824-media-c4">02/10</td><td class="excel-262824-media-c4">09/10</td><td class="excel-262824-media-c4">16/10</td><td class="excel-262824-media-c4">23/10</td><td class="excel-262824-media-c4">30/10</td><td class="excel-262824-media-c4">06/11</td><td class="excel-262824-media-c4">13/11</td><td class="excel-262824-media-c4">20/11</td><td class="excel-262824-media-c4">27/11</td><td class="excel-262824-media-c4">04/12</td><td class="excel-262824-media-c4">11/12*</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Gender</td><td class="excel-262824-media-c6">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c6">&nbsp;</td><td class="excel-262824-media-c6">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Female</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c12">48%</td><td class="excel-262824-media-c13">48%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Male</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c12">52%</td><td class="excel-262824-media-c13">52%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c13">0%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Age Group</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">0-24</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c12">4%</td><td class="excel-262824-media-c13">4%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">25-44</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c12">21%</td><td class="excel-262824-media-c13">21%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">45-64</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c12">29%</td><td class="excel-262824-media-c13">29%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">65-79</td><td class="excel-262824-media-c12">25%</td><td class="excel-262824-media-c12">25%</td><td class="excel-262824-media-c12">25%</td><td class="excel-262824-media-c12">25%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c12">24%</td><td class="excel-262824-media-c13">24%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">80+</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c12">22%</td><td class="excel-262824-media-c13">22%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c13">0%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Underlying clinical conditions</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Yes</td><td class="excel-262824-media-c12">63%</td><td class="excel-262824-media-c12">63%</td><td class="excel-262824-media-c12">63%</td><td class="excel-262824-media-c12">63%</td><td class="excel-262824-media-c12">63%</td><td class="excel-262824-media-c12">62%</td><td class="excel-262824-media-c12">61%</td><td class="excel-262824-media-c12">61%</td><td class="excel-262824-media-c12">61%</td><td class="excel-262824-media-c12">61%</td><td class="excel-262824-media-c12">61%</td><td class="excel-262824-media-c12">61%</td><td class="excel-262824-media-c12">61%</td><td class="excel-262824-media-c13">61%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">No</td><td class="excel-262824-media-c12">17%</td><td class="excel-262824-media-c12">17%</td><td class="excel-262824-media-c12">17%</td><td class="excel-262824-media-c12">17%</td><td class="excel-262824-media-c12">18%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c13">20%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">20%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c12">19%</td><td class="excel-262824-media-c13">19%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">of which Admitted to ICU</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Gender</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Female</td><td class="excel-262824-media-c12">32%</td><td class="excel-262824-media-c12">32%</td><td class="excel-262824-media-c12">32%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c12">31%</td><td class="excel-262824-media-c13">31%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Male</td><td class="excel-262824-media-c12">68%</td><td class="excel-262824-media-c12">68%</td><td class="excel-262824-media-c12">68%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c12">69%</td><td class="excel-262824-media-c13">69%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c13">0%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Age Group</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">0-24</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c12">2%</td><td class="excel-262824-media-c13">2%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">25-44</td><td class="excel-262824-media-c12">11%</td><td class="excel-262824-media-c12">11%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c12">10%</td><td class="excel-262824-media-c13">10%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">45-64</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c12">50%</td><td class="excel-262824-media-c13">50%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">65-79</td><td class="excel-262824-media-c12">32%</td><td class="excel-262824-media-c12">32%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c12">33%</td><td class="excel-262824-media-c13">33%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">80+</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c12">5%</td><td class="excel-262824-media-c13">5%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Not Specified</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c12">0%</td><td class="excel-262824-media-c13">0%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">&nbsp;</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c5">Underlying clinical conditions</td><td class="excel-262824-media-c7">&nbsp;</td><td></td><td></td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c12">&nbsp;</td><td class="excel-262824-media-c13">&nbsp;</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">Yes</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c12">87%</td><td class="excel-262824-media-c13">87%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7">No</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c12">13%</td><td class="excel-262824-media-c13">13%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c2">Not Specified</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c14">0%</td><td class="excel-262824-media-c15">0%</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c16" colspan="15">* latest week is preliminary</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7" colspan="15"><sup>1 </sup>Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7" colspan="15"><sup>2</sup> '..' Indicates a cell number &lt; 5 or a cell number &lt; 5 can be identified</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7" colspan="15"><sup>3 </sup>Week ending 06/03/2020 includes all cases up to that date, including previous weeks.</td>
</tr>
<tr class="excel-262824-media-r1">
<td class="excel-262824-media-c7" colspan="15"><sup>4</sup> Data is defined by epidemiological date which is the earliest of onset date, date of diagnosis, laboratory specimen collection date, laboratory received date, laboratory reported date and event creation/notification date</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL6.xlsx">COVID-19 Deaths and Cases Series 18 - Table 6 (XLS 16KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262824_description").click(function(){
    $("#262824_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262824_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262825_description">
    <span id="#262825_openClose">Show Table</span>: Table 7 &amp; 7A Weekly Profile of Confirmed Cases linked to COVID-19 Outbreaks
  </div>

<div style="clear: both"></div>

<div id="262825_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262825-insertexceltable">
<div id="table-262825-1-insertexceltable">
<table class="excel-262825-media-t1">
<colgroup>
<col width="218">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
<col width="64">
</colgroup>
<tbody>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c1" colspan="15">Table 7: Weekly Profile of Confirmed Cases linked to COVID-19 Outbreaks <b><sup>1,2,3</sup></b></td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c1">&nbsp;</td><td class="excel-262825-media-c2" colspan="14">2020</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c3">&nbsp;</td><td class="excel-262825-media-c4">11/09</td><td class="excel-262825-media-c4">18/09</td><td class="excel-262825-media-c4">25/09</td><td class="excel-262825-media-c4">02/10</td><td class="excel-262825-media-c4">09/10</td><td class="excel-262825-media-c4">16/10</td><td class="excel-262825-media-c4">23/10</td><td class="excel-262825-media-c4">30/10</td><td class="excel-262825-media-c4">06/11</td><td class="excel-262825-media-c4">13/11</td><td class="excel-262825-media-c4">20/11</td><td class="excel-262825-media-c4">27/11</td><td class="excel-262825-media-c4">04/12</td><td class="excel-262825-media-c4">11/12*</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Total </td><td class="excel-262825-media-c6">1,072</td><td class="excel-262825-media-c6">1,399</td><td class="excel-262825-media-c6">1,632</td><td class="excel-262825-media-c6">1,958</td><td class="excel-262825-media-c6">2,685</td><td class="excel-262825-media-c6">3,613</td><td class="excel-262825-media-c6">3,149</td><td class="excel-262825-media-c6">2,294</td><td class="excel-262825-media-c6">1,699</td><td class="excel-262825-media-c6">1,515</td><td class="excel-262825-media-c6">1,558</td><td class="excel-262825-media-c6">1,028</td><td class="excel-262825-media-c6">966</td><td class="excel-262825-media-c7">413</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Gender</td><td class="excel-262825-media-c11">&nbsp;</td><td class="excel-262825-media-c11">&nbsp;</td><td class="excel-262825-media-c11">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c11">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c12">&nbsp;</td><td class="excel-262825-media-c11">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Female</td><td class="excel-262825-media-c9">542</td><td class="excel-262825-media-c9">742</td><td class="excel-262825-media-c9">821</td><td class="excel-262825-media-c9">996</td><td class="excel-262825-media-c9">1,349</td><td class="excel-262825-media-c9">1,906</td><td class="excel-262825-media-c9">1,654</td><td class="excel-262825-media-c9">1,229</td><td class="excel-262825-media-c9">887</td><td class="excel-262825-media-c9">824</td><td class="excel-262825-media-c9">842</td><td class="excel-262825-media-c9">536</td><td class="excel-262825-media-c9">518</td><td class="excel-262825-media-c10">221</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Male</td><td class="excel-262825-media-c9">530</td><td class="excel-262825-media-c9">657</td><td class="excel-262825-media-c9">810</td><td class="excel-262825-media-c9">961</td><td class="excel-262825-media-c9">1,336</td><td class="excel-262825-media-c9">1,706</td><td class="excel-262825-media-c9">1,495</td><td class="excel-262825-media-c9">1,062</td><td class="excel-262825-media-c9">806</td><td class="excel-262825-media-c9">690</td><td class="excel-262825-media-c9">713</td><td class="excel-262825-media-c9">491</td><td class="excel-262825-media-c9">446</td><td class="excel-262825-media-c10">192</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c13">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Age</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">0-24</td><td class="excel-262825-media-c9">377</td><td class="excel-262825-media-c9">474</td><td class="excel-262825-media-c9">556</td><td class="excel-262825-media-c9">694</td><td class="excel-262825-media-c9">1,096</td><td class="excel-262825-media-c9">1,498</td><td class="excel-262825-media-c9">1,279</td><td class="excel-262825-media-c9">869</td><td class="excel-262825-media-c9">567</td><td class="excel-262825-media-c9">496</td><td class="excel-262825-media-c9">517</td><td class="excel-262825-media-c9">341</td><td class="excel-262825-media-c9">324</td><td class="excel-262825-media-c10">145</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">25-44</td><td class="excel-262825-media-c9">321</td><td class="excel-262825-media-c9">402</td><td class="excel-262825-media-c9">497</td><td class="excel-262825-media-c9">591</td><td class="excel-262825-media-c9">745</td><td class="excel-262825-media-c9">966</td><td class="excel-262825-media-c9">804</td><td class="excel-262825-media-c9">617</td><td class="excel-262825-media-c9">470</td><td class="excel-262825-media-c9">413</td><td class="excel-262825-media-c9">479</td><td class="excel-262825-media-c9">316</td><td class="excel-262825-media-c9">269</td><td class="excel-262825-media-c10">120</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">45-64</td><td class="excel-262825-media-c9">271</td><td class="excel-262825-media-c9">345</td><td class="excel-262825-media-c9">428</td><td class="excel-262825-media-c9">473</td><td class="excel-262825-media-c9">595</td><td class="excel-262825-media-c9">831</td><td class="excel-262825-media-c9">755</td><td class="excel-262825-media-c9">555</td><td class="excel-262825-media-c9">408</td><td class="excel-262825-media-c9">374</td><td class="excel-262825-media-c9">349</td><td class="excel-262825-media-c9">230</td><td class="excel-262825-media-c9">220</td><td class="excel-262825-media-c10">80</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">65-79</td><td class="excel-262825-media-c9">72</td><td class="excel-262825-media-c9">136</td><td class="excel-262825-media-c9">113</td><td class="excel-262825-media-c9">118</td><td class="excel-262825-media-c9">160</td><td class="excel-262825-media-c9">199</td><td class="excel-262825-media-c9">183</td><td class="excel-262825-media-c9">150</td><td class="excel-262825-media-c9">129</td><td class="excel-262825-media-c9">108</td><td class="excel-262825-media-c9">100</td><td class="excel-262825-media-c9">65</td><td class="excel-262825-media-c9">69</td><td class="excel-262825-media-c10">26</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">80+</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">82</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">117</td><td class="excel-262825-media-c9">127</td><td class="excel-262825-media-c9">101</td><td class="excel-262825-media-c9">121</td><td class="excel-262825-media-c9">124</td><td class="excel-262825-media-c9">113</td><td class="excel-262825-media-c9">76</td><td class="excel-262825-media-c9">84</td><td class="excel-262825-media-c10">42</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Median Age</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">37</td><td class="excel-262825-media-c10">33</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">County</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Carlow</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">45</td><td class="excel-262825-media-c9">50</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c10">9</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Cavan</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">19</td><td class="excel-262825-media-c9">55</td><td class="excel-262825-media-c9">86</td><td class="excel-262825-media-c9">131</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c10">37</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Clare</td><td class="excel-262825-media-c9">19</td><td class="excel-262825-media-c9">27</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">83</td><td class="excel-262825-media-c9">97</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Cork</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">134</td><td class="excel-262825-media-c9">215</td><td class="excel-262825-media-c9">225</td><td class="excel-262825-media-c9">403</td><td class="excel-262825-media-c9">397</td><td class="excel-262825-media-c9">338</td><td class="excel-262825-media-c9">296</td><td class="excel-262825-media-c9">83</td><td class="excel-262825-media-c9">80</td><td class="excel-262825-media-c9">50</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c10">29</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Donegal</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c9">91</td><td class="excel-262825-media-c9">156</td><td class="excel-262825-media-c9">174</td><td class="excel-262825-media-c9">157</td><td class="excel-262825-media-c9">147</td><td class="excel-262825-media-c9">160</td><td class="excel-262825-media-c9">145</td><td class="excel-262825-media-c9">183</td><td class="excel-262825-media-c9">146</td><td class="excel-262825-media-c9">177</td><td class="excel-262825-media-c9">117</td><td class="excel-262825-media-c9">103</td><td class="excel-262825-media-c10">57</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Dublin</td><td class="excel-262825-media-c9">565</td><td class="excel-262825-media-c9">697</td><td class="excel-262825-media-c9">670</td><td class="excel-262825-media-c9">637</td><td class="excel-262825-media-c9">773</td><td class="excel-262825-media-c9">1100</td><td class="excel-262825-media-c9">969</td><td class="excel-262825-media-c9">817</td><td class="excel-262825-media-c9">569</td><td class="excel-262825-media-c9">458</td><td class="excel-262825-media-c9">646</td><td class="excel-262825-media-c9">426</td><td class="excel-262825-media-c9">344</td><td class="excel-262825-media-c10">65</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Galway</td><td class="excel-262825-media-c9">23</td><td class="excel-262825-media-c9">43</td><td class="excel-262825-media-c9">79</td><td class="excel-262825-media-c9">100</td><td class="excel-262825-media-c9">238</td><td class="excel-262825-media-c9">287</td><td class="excel-262825-media-c9">269</td><td class="excel-262825-media-c9">151</td><td class="excel-262825-media-c9">89</td><td class="excel-262825-media-c9">77</td><td class="excel-262825-media-c9">95</td><td class="excel-262825-media-c9">63</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c10">32</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Kerry</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">22</td><td class="excel-262825-media-c9">46</td><td class="excel-262825-media-c9">64</td><td class="excel-262825-media-c9">90</td><td class="excel-262825-media-c9">76</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">69</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">8</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Kildare</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">65</td><td class="excel-262825-media-c9">65</td><td class="excel-262825-media-c9">70</td><td class="excel-262825-media-c9">126</td><td class="excel-262825-media-c9">224</td><td class="excel-262825-media-c9">178</td><td class="excel-262825-media-c9">107</td><td class="excel-262825-media-c9">57</td><td class="excel-262825-media-c9">78</td><td class="excel-262825-media-c9">50</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c10">6</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Kilkenny</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">50</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">50</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">37</td><td class="excel-262825-media-c10">16</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Laois</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">62</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c10">18</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Leitrim</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Limerick</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">93</td><td class="excel-262825-media-c9">68</td><td class="excel-262825-media-c9">127</td><td class="excel-262825-media-c9">104</td><td class="excel-262825-media-c9">51</td><td class="excel-262825-media-c9">70</td><td class="excel-262825-media-c9">65</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">28</td><td class="excel-262825-media-c9">49</td><td class="excel-262825-media-c10">7</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Longford</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Louth</td><td class="excel-262825-media-c9">66</td><td class="excel-262825-media-c9">49</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">22</td><td class="excel-262825-media-c9">13</td><td class="excel-262825-media-c9">46</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">28</td><td class="excel-262825-media-c9">65</td><td class="excel-262825-media-c9">74</td><td class="excel-262825-media-c9">49</td><td class="excel-262825-media-c9">47</td><td class="excel-262825-media-c10">26</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Mayo</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c9">50</td><td class="excel-262825-media-c9">109</td><td class="excel-262825-media-c9">91</td><td class="excel-262825-media-c9">70</td><td class="excel-262825-media-c9">76</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">53</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">54</td><td class="excel-262825-media-c10">65</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Meath</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c9">29</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">68</td><td class="excel-262825-media-c9">71</td><td class="excel-262825-media-c9">151</td><td class="excel-262825-media-c9">121</td><td class="excel-262825-media-c9">75</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c9">46</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Monaghan</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">40</td><td class="excel-262825-media-c9">58</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Offaly</td><td class="excel-262825-media-c9">19</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c9">45</td><td class="excel-262825-media-c9">29</td><td class="excel-262825-media-c9">22</td><td class="excel-262825-media-c9">27</td><td class="excel-262825-media-c9">45</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c10">8</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Roscommon</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c9">39</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">39</td><td class="excel-262825-media-c9">72</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c9">63</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c10">5</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Sligo</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c9">55</td><td class="excel-262825-media-c9">77</td><td class="excel-262825-media-c9">80</td><td class="excel-262825-media-c9">27</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c10">12</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Tipperary</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">23</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">52</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">55</td><td class="excel-262825-media-c9">47</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c10">5</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Waterford</td><td class="excel-262825-media-c9">49</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">13</td><td class="excel-262825-media-c9">13</td><td class="excel-262825-media-c9">29</td><td class="excel-262825-media-c9">74</td><td class="excel-262825-media-c9">93</td><td class="excel-262825-media-c9">67</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Westmeath</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">84</td><td class="excel-262825-media-c9">76</td><td class="excel-262825-media-c9">66</td><td class="excel-262825-media-c9">37</td><td class="excel-262825-media-c9">44</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Wexford</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">122</td><td class="excel-262825-media-c9">156</td><td class="excel-262825-media-c9">96</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">25</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Wicklow</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c9">40</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">64</td><td class="excel-262825-media-c9">66</td><td class="excel-262825-media-c9">43</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">37</td><td class="excel-262825-media-c9">86</td><td class="excel-262825-media-c9">57</td><td class="excel-262825-media-c9">64</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Outbreak Location</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Childcare Facility</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">19</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c9">68</td><td class="excel-262825-media-c9">68</td><td class="excel-262825-media-c9">47</td><td class="excel-262825-media-c9">45</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">19</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c10">10</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Community Hospital / Long-stay unit</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Community Outbreak</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c9">25</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c9">152</td><td class="excel-262825-media-c9">260</td><td class="excel-262825-media-c9">193</td><td class="excel-262825-media-c9">150</td><td class="excel-262825-media-c9">116</td><td class="excel-262825-media-c9">86</td><td class="excel-262825-media-c9">69</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c10">13</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Extended Family</td><td class="excel-262825-media-c9">51</td><td class="excel-262825-media-c9">54</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c9">178</td><td class="excel-262825-media-c9">204</td><td class="excel-262825-media-c9">240</td><td class="excel-262825-media-c9">162</td><td class="excel-262825-media-c9">77</td><td class="excel-262825-media-c9">52</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c9">52</td><td class="excel-262825-media-c9">45</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c10">54</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Guest B &amp; B</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Hospital</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">44</td><td class="excel-262825-media-c9">55</td><td class="excel-262825-media-c9">66</td><td class="excel-262825-media-c9">93</td><td class="excel-262825-media-c9">202</td><td class="excel-262825-media-c9">235</td><td class="excel-262825-media-c9">232</td><td class="excel-262825-media-c9">181</td><td class="excel-262825-media-c9">117</td><td class="excel-262825-media-c10">47</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Hotel</td><td class="excel-262825-media-c9">19</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Nursing Home </td><td class="excel-262825-media-c9">51</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c9">117</td><td class="excel-262825-media-c9">143</td><td class="excel-262825-media-c9">208</td><td class="excel-262825-media-c9">181</td><td class="excel-262825-media-c9">138</td><td class="excel-262825-media-c9">152</td><td class="excel-262825-media-c9">208</td><td class="excel-262825-media-c9">60</td><td class="excel-262825-media-c9">62</td><td class="excel-262825-media-c9">100</td><td class="excel-262825-media-c10">70</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Other</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c9">25</td><td class="excel-262825-media-c9">55</td><td class="excel-262825-media-c9">23</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">56</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">5</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Other healthcare service</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">13</td><td class="excel-262825-media-c9">22</td><td class="excel-262825-media-c9">19</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c10">5</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Other recreation activity</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Personal grooming service</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Private House</td><td class="excel-262825-media-c9">690</td><td class="excel-262825-media-c9">896</td><td class="excel-262825-media-c9">1047</td><td class="excel-262825-media-c9">1123</td><td class="excel-262825-media-c9">1,467</td><td class="excel-262825-media-c9">2204</td><td class="excel-262825-media-c9">1995</td><td class="excel-262825-media-c9">1469</td><td class="excel-262825-media-c9">879</td><td class="excel-262825-media-c9">663</td><td class="excel-262825-media-c9">820</td><td class="excel-262825-media-c9">471</td><td class="excel-262825-media-c9">462</td><td class="excel-262825-media-c10">94</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Public House </td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">27</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Religious/Other ceremony</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">40</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c9">27</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">7</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Residential Institution</td><td class="excel-262825-media-c9">21</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c9">16</td><td class="excel-262825-media-c9">33</td><td class="excel-262825-media-c9">66</td><td class="excel-262825-media-c9">97</td><td class="excel-262825-media-c9">74</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">27</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Retail Outlet</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Restaurant / Café</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">72</td><td class="excel-262825-media-c9">52</td><td class="excel-262825-media-c9">25</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">13</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">School</td><td class="excel-262825-media-c9">29</td><td class="excel-262825-media-c9">51</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">77</td><td class="excel-262825-media-c9">190</td><td class="excel-262825-media-c9">171</td><td class="excel-262825-media-c9">86</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">48</td><td class="excel-262825-media-c9">52</td><td class="excel-262825-media-c9">55</td><td class="excel-262825-media-c9">76</td><td class="excel-262825-media-c10">49</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Social gathering</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">53</td><td class="excel-262825-media-c9">71</td><td class="excel-262825-media-c9">119</td><td class="excel-262825-media-c9">79</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Sporting activity/fitness</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">25</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">20</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">27</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">6</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Transport</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Travel Related</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">9</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">University/College</td><td class="excel-262825-media-c9">0</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">18</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">39</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">9</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">..</td><td class="excel-262825-media-c10">0</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Workplace</td><td class="excel-262825-media-c9">93</td><td class="excel-262825-media-c9">69</td><td class="excel-262825-media-c9">71</td><td class="excel-262825-media-c9">94</td><td class="excel-262825-media-c9">92</td><td class="excel-262825-media-c9">124</td><td class="excel-262825-media-c9">115</td><td class="excel-262825-media-c9">74</td><td class="excel-262825-media-c9">71</td><td class="excel-262825-media-c9">89</td><td class="excel-262825-media-c9">102</td><td class="excel-262825-media-c9">80</td><td class="excel-262825-media-c9">54</td><td class="excel-262825-media-c10">39</td>
</tr>
<tr class="excel-262825-media-r1">
<td></td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Health Care Worker (HCW)</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Yes</td><td class="excel-262825-media-c9">82</td><td class="excel-262825-media-c9">80</td><td class="excel-262825-media-c9">92</td><td class="excel-262825-media-c9">135</td><td class="excel-262825-media-c9">183</td><td class="excel-262825-media-c9">211</td><td class="excel-262825-media-c9">168</td><td class="excel-262825-media-c9">149</td><td class="excel-262825-media-c9">236</td><td class="excel-262825-media-c9">1,151</td><td class="excel-262825-media-c9">265</td><td class="excel-262825-media-c9">175</td><td class="excel-262825-media-c9">153</td><td class="excel-262825-media-c10">61</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">No</td><td class="excel-262825-media-c9">946</td><td class="excel-262825-media-c9">1,245</td><td class="excel-262825-media-c9">1,436</td><td class="excel-262825-media-c9">1,701</td><td class="excel-262825-media-c9">2,239</td><td class="excel-262825-media-c9">2,628</td><td class="excel-262825-media-c9">2,414</td><td class="excel-262825-media-c9">1,777</td><td class="excel-262825-media-c9">1,339</td><td class="excel-262825-media-c9">296</td><td class="excel-262825-media-c9">1,155</td><td class="excel-262825-media-c9">762</td><td class="excel-262825-media-c9">735</td><td class="excel-262825-media-c10">286</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">44</td><td class="excel-262825-media-c9">74</td><td class="excel-262825-media-c9">104</td><td class="excel-262825-media-c9">122</td><td class="excel-262825-media-c9">263</td><td class="excel-262825-media-c9">774</td><td class="excel-262825-media-c9">567</td><td class="excel-262825-media-c9">368</td><td class="excel-262825-media-c9">124</td><td class="excel-262825-media-c9">68</td><td class="excel-262825-media-c9">138</td><td class="excel-262825-media-c9">91</td><td class="excel-262825-media-c9">78</td><td class="excel-262825-media-c10">66</td>
</tr>
<tr class="excel-262825-media-r1">
<td></td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Underlying Condition</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Yes</td><td class="excel-262825-media-c9">314</td><td class="excel-262825-media-c9">434</td><td class="excel-262825-media-c9">500</td><td class="excel-262825-media-c9">422</td><td class="excel-262825-media-c9">469</td><td class="excel-262825-media-c9">289</td><td class="excel-262825-media-c9">159</td><td class="excel-262825-media-c9">203</td><td class="excel-262825-media-c9">449</td><td class="excel-262825-media-c9">431</td><td class="excel-262825-media-c9">900</td><td class="excel-262825-media-c9">594</td><td class="excel-262825-media-c9">327</td><td class="excel-262825-media-c10">121</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">No</td><td class="excel-262825-media-c9">692</td><td class="excel-262825-media-c9">886</td><td class="excel-262825-media-c9">1,050</td><td class="excel-262825-media-c9">1,416</td><td class="excel-262825-media-c9">1,966</td><td class="excel-262825-media-c9">2,516</td><td class="excel-262825-media-c9">2,371</td><td class="excel-262825-media-c9">1,657</td><td class="excel-262825-media-c9">1,126</td><td class="excel-262825-media-c9">1,013</td><td class="excel-262825-media-c9">508</td><td class="excel-262825-media-c9">335</td><td class="excel-262825-media-c9">579</td><td class="excel-262825-media-c10">252</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">66</td><td class="excel-262825-media-c9">79</td><td class="excel-262825-media-c9">82</td><td class="excel-262825-media-c9">120</td><td class="excel-262825-media-c9">250</td><td class="excel-262825-media-c9">808</td><td class="excel-262825-media-c9">619</td><td class="excel-262825-media-c9">434</td><td class="excel-262825-media-c9">124</td><td class="excel-262825-media-c9">71</td><td class="excel-262825-media-c9">150</td><td class="excel-262825-media-c9">99</td><td class="excel-262825-media-c9">60</td><td class="excel-262825-media-c10">40</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Median Household Income <b><sup>5</sup></b></td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c6">&nbsp;</td><td class="excel-262825-media-c7">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&lt; 30k</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">44</td><td class="excel-262825-media-c9">40</td><td class="excel-262825-media-c9">51</td><td class="excel-262825-media-c9">76</td><td class="excel-262825-media-c9">98</td><td class="excel-262825-media-c9">85</td><td class="excel-262825-media-c9">62</td><td class="excel-262825-media-c9">46</td><td class="excel-262825-media-c9">41</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">28</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c10">11</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">30k - 40k </td><td class="excel-262825-media-c9">292</td><td class="excel-262825-media-c9">367</td><td class="excel-262825-media-c9">407</td><td class="excel-262825-media-c9">525</td><td class="excel-262825-media-c9">703</td><td class="excel-262825-media-c9">1,106</td><td class="excel-262825-media-c9">964</td><td class="excel-262825-media-c9">702</td><td class="excel-262825-media-c9">520</td><td class="excel-262825-media-c9">464</td><td class="excel-262825-media-c9">477</td><td class="excel-262825-media-c9">315</td><td class="excel-262825-media-c9">296</td><td class="excel-262825-media-c10">126</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">40k - 50k</td><td class="excel-262825-media-c9">241</td><td class="excel-262825-media-c9">339</td><td class="excel-262825-media-c9">393</td><td class="excel-262825-media-c9">476</td><td class="excel-262825-media-c9">642</td><td class="excel-262825-media-c9">1,076</td><td class="excel-262825-media-c9">938</td><td class="excel-262825-media-c9">683</td><td class="excel-262825-media-c9">506</td><td class="excel-262825-media-c9">451</td><td class="excel-262825-media-c9">464</td><td class="excel-262825-media-c9">306</td><td class="excel-262825-media-c9">288</td><td class="excel-262825-media-c10">123</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">50k - 60k</td><td class="excel-262825-media-c9">214</td><td class="excel-262825-media-c9">275</td><td class="excel-262825-media-c9">354</td><td class="excel-262825-media-c9">396</td><td class="excel-262825-media-c9">578</td><td class="excel-262825-media-c9">604</td><td class="excel-262825-media-c9">526</td><td class="excel-262825-media-c9">383</td><td class="excel-262825-media-c9">284</td><td class="excel-262825-media-c9">253</td><td class="excel-262825-media-c9">260</td><td class="excel-262825-media-c9">172</td><td class="excel-262825-media-c9">161</td><td class="excel-262825-media-c10">69</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">60k - 70k </td><td class="excel-262825-media-c9">187</td><td class="excel-262825-media-c9">241</td><td class="excel-262825-media-c9">283</td><td class="excel-262825-media-c9">317</td><td class="excel-262825-media-c9">463</td><td class="excel-262825-media-c9">459</td><td class="excel-262825-media-c9">400</td><td class="excel-262825-media-c9">292</td><td class="excel-262825-media-c9">216</td><td class="excel-262825-media-c9">192</td><td class="excel-262825-media-c9">197</td><td class="excel-262825-media-c9">130</td><td class="excel-262825-media-c9">122</td><td class="excel-262825-media-c10">52</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">70k - 80k</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">54</td><td class="excel-262825-media-c9">67</td><td class="excel-262825-media-c9">75</td><td class="excel-262825-media-c9">84</td><td class="excel-262825-media-c9">119</td><td class="excel-262825-media-c9">104</td><td class="excel-262825-media-c9">76</td><td class="excel-262825-media-c9">56</td><td class="excel-262825-media-c9">50</td><td class="excel-262825-media-c9">51</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c10">14</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">80k - 90k</td><td class="excel-262825-media-c9">25</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c9">46</td><td class="excel-262825-media-c9">52</td><td class="excel-262825-media-c9">51</td><td class="excel-262825-media-c9">44</td><td class="excel-262825-media-c9">32</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">22</td><td class="excel-262825-media-c9">23</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c9">14</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">90k +</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">12</td><td class="excel-262825-media-c9">10</td><td class="excel-262825-media-c9">17</td><td class="excel-262825-media-c9">15</td><td class="excel-262825-media-c9">11</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">7</td><td class="excel-262825-media-c9">8</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c9">5</td><td class="excel-262825-media-c10">..</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Unknown</td><td class="excel-262825-media-c9">29</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">60</td><td class="excel-262825-media-c9">77</td><td class="excel-262825-media-c9">83</td><td class="excel-262825-media-c9">72</td><td class="excel-262825-media-c9">53</td><td class="excel-262825-media-c9">39</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">22</td><td class="excel-262825-media-c10">10</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Urban / Rural <b><sup>6</sup></b></td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Cities</td><td class="excel-262825-media-c9">455</td><td class="excel-262825-media-c9">675</td><td class="excel-262825-media-c9">758</td><td class="excel-262825-media-c9">997</td><td class="excel-262825-media-c9">1,311</td><td class="excel-262825-media-c9">1,610</td><td class="excel-262825-media-c9">1,403</td><td class="excel-262825-media-c9">1,022</td><td class="excel-262825-media-c9">757</td><td class="excel-262825-media-c9">674</td><td class="excel-262825-media-c9">693</td><td class="excel-262825-media-c9">457</td><td class="excel-262825-media-c9">431</td><td class="excel-262825-media-c10">184</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Satellite urban towns</td><td class="excel-262825-media-c9">210</td><td class="excel-262825-media-c9">213</td><td class="excel-262825-media-c9">359</td><td class="excel-262825-media-c9">387</td><td class="excel-262825-media-c9">524</td><td class="excel-262825-media-c9">921</td><td class="excel-262825-media-c9">803</td><td class="excel-262825-media-c9">585</td><td class="excel-262825-media-c9">433</td><td class="excel-262825-media-c9">386</td><td class="excel-262825-media-c9">397</td><td class="excel-262825-media-c9">262</td><td class="excel-262825-media-c9">246</td><td class="excel-262825-media-c10">105</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Independent urban towns</td><td class="excel-262825-media-c9">168</td><td class="excel-262825-media-c9">222</td><td class="excel-262825-media-c9">233</td><td class="excel-262825-media-c9">269</td><td class="excel-262825-media-c9">459</td><td class="excel-262825-media-c9">481</td><td class="excel-262825-media-c9">419</td><td class="excel-262825-media-c9">305</td><td class="excel-262825-media-c9">226</td><td class="excel-262825-media-c9">201</td><td class="excel-262825-media-c9">207</td><td class="excel-262825-media-c9">136</td><td class="excel-262825-media-c9">128</td><td class="excel-262825-media-c10">55</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Rural areas with high urban influence</td><td class="excel-262825-media-c9">91</td><td class="excel-262825-media-c9">118</td><td class="excel-262825-media-c9">122</td><td class="excel-262825-media-c9">153</td><td class="excel-262825-media-c9">201</td><td class="excel-262825-media-c9">300</td><td class="excel-262825-media-c9">261</td><td class="excel-262825-media-c9">190</td><td class="excel-262825-media-c9">141</td><td class="excel-262825-media-c9">126</td><td class="excel-262825-media-c9">130</td><td class="excel-262825-media-c9">87</td><td class="excel-262825-media-c9">80</td><td class="excel-262825-media-c10">34</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Rural areas with moderate urban influence</td><td class="excel-262825-media-c9">72</td><td class="excel-262825-media-c9">94</td><td class="excel-262825-media-c9">81</td><td class="excel-262825-media-c9">62</td><td class="excel-262825-media-c9">77</td><td class="excel-262825-media-c9">125</td><td class="excel-262825-media-c9">109</td><td class="excel-262825-media-c9">80</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c9">53</td><td class="excel-262825-media-c9">55</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">34</td><td class="excel-262825-media-c10">14</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Highly rural / remote areas</td><td class="excel-262825-media-c9">31</td><td class="excel-262825-media-c9">39</td><td class="excel-262825-media-c9">37</td><td class="excel-262825-media-c9">30</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">94</td><td class="excel-262825-media-c9">82</td><td class="excel-262825-media-c9">59</td><td class="excel-262825-media-c9">44</td><td class="excel-262825-media-c9">39</td><td class="excel-262825-media-c9">40</td><td class="excel-262825-media-c9">26</td><td class="excel-262825-media-c9">25</td><td class="excel-262825-media-c10">11</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Unknown</td><td class="excel-262825-media-c9">29</td><td class="excel-262825-media-c9">38</td><td class="excel-262825-media-c9">42</td><td class="excel-262825-media-c9">60</td><td class="excel-262825-media-c9">77</td><td class="excel-262825-media-c9">83</td><td class="excel-262825-media-c9">72</td><td class="excel-262825-media-c9">53</td><td class="excel-262825-media-c9">39</td><td class="excel-262825-media-c9">35</td><td class="excel-262825-media-c9">36</td><td class="excel-262825-media-c9">24</td><td class="excel-262825-media-c9">22</td><td class="excel-262825-media-c10">10</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td><td class="excel-262825-media-c15">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td></td><td></td><td></td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td><td class="excel-262825-media-c16">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c1" colspan="15">Table 7A: Weekly Profile of Cumulative Confirmed Cases linked to COVID-19 Outbreaks (%) <b><sup>1,2,3</sup></b></td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c1">&nbsp;</td><td class="excel-262825-media-c2" colspan="14">2020</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c3">&nbsp;</td><td class="excel-262825-media-c4">11/09</td><td class="excel-262825-media-c4">18/09</td><td class="excel-262825-media-c4">25/09</td><td class="excel-262825-media-c4">02/10</td><td class="excel-262825-media-c4">09/10</td><td class="excel-262825-media-c4">16/10</td><td class="excel-262825-media-c4">23/10</td><td class="excel-262825-media-c4">30/10</td><td class="excel-262825-media-c4">06/11</td><td class="excel-262825-media-c4">13/11</td><td class="excel-262825-media-c4">20/11</td><td class="excel-262825-media-c4">27/11</td><td class="excel-262825-media-c4">04/12</td><td class="excel-262825-media-c4">11/12*</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Gender</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Female</td><td class="excel-262825-media-c9">54%</td><td class="excel-262825-media-c9">54%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c9">52%</td><td class="excel-262825-media-c9">52%</td><td class="excel-262825-media-c9">53%</td><td class="excel-262825-media-c10">53%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Male</td><td class="excel-262825-media-c9">46%</td><td class="excel-262825-media-c9">46%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">46%</td><td class="excel-262825-media-c9">46%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c10">47%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c13">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c17">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Age</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c18">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">0-24</td><td class="excel-262825-media-c9">14%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">22%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c10">27%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">25-44</td><td class="excel-262825-media-c9">30%</td><td class="excel-262825-media-c9">30%</td><td class="excel-262825-media-c9">30%</td><td class="excel-262825-media-c9">30%</td><td class="excel-262825-media-c9">30%</td><td class="excel-262825-media-c9">30%</td><td class="excel-262825-media-c9">29%</td><td class="excel-262825-media-c9">29%</td><td class="excel-262825-media-c9">29%</td><td class="excel-262825-media-c9">29%</td><td class="excel-262825-media-c9">28%</td><td class="excel-262825-media-c9">28%</td><td class="excel-262825-media-c9">29%</td><td class="excel-262825-media-c10">29%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">45-64</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c10">24%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">65-79</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c10">9%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">80+</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c10">11%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c17">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">County</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c18">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Carlow</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Cavan</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Clare</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Cork</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c10">8%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Donegal</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c10">5%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Dublin</td><td class="excel-262825-media-c9">43%</td><td class="excel-262825-media-c9">43%</td><td class="excel-262825-media-c9">43%</td><td class="excel-262825-media-c9">43%</td><td class="excel-262825-media-c9">41%</td><td class="excel-262825-media-c9">40%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c10">38%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Galway</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c10">4%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Kerry</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Kildare</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c10">6%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Kilkenny</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Laois</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Leitrim</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Limerick</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Longford</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Louth</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Mayo</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Meath</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Monaghan</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Offaly</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Roscommon</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Sligo</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Tipperary</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Waterford</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Westmeath</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Wexford</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Wicklow</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Outbreak Location</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Childcare Facility</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Community Hospital / Long-stay unit</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Community Outbreak</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c10">4%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Extended Family</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c10">5%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Guest B &amp; B</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Hospital</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c10">6%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Hotel</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Nursing Home </td><td class="excel-262825-media-c9">36%</td><td class="excel-262825-media-c9">35%</td><td class="excel-262825-media-c9">32%</td><td class="excel-262825-media-c9">31%</td><td class="excel-262825-media-c9">29%</td><td class="excel-262825-media-c9">28%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">22%</td><td class="excel-262825-media-c9">22%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c10">19%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Other</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Other healthcare service</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Other recreation activity</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Personal grooming service</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Private House</td><td class="excel-262825-media-c9">29%</td><td class="excel-262825-media-c9">30%</td><td class="excel-262825-media-c9">33%</td><td class="excel-262825-media-c9">34%</td><td class="excel-262825-media-c9">36%</td><td class="excel-262825-media-c9">37%</td><td class="excel-262825-media-c9">39%</td><td class="excel-262825-media-c9">39%</td><td class="excel-262825-media-c9">42%</td><td class="excel-262825-media-c9">42%</td><td class="excel-262825-media-c9">44%</td><td class="excel-262825-media-c9">44%</td><td class="excel-262825-media-c9">45%</td><td class="excel-262825-media-c10">45%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Public House </td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Religious/Other ceremony</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Residential Institution</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c10">4%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Retail Outlet</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Restaurant / Café</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">School</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Social gathering</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Sporting activity/fitness</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Transport</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c10">0%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Travel Related</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">University/College</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">0%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Workplace</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c10">7%</td>
</tr>
<tr class="excel-262825-media-r1">
<td></td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Health Care Worker (HCW)</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Yes</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">23%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c10">17%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">No</td><td class="excel-262825-media-c9">64%</td><td class="excel-262825-media-c9">64%</td><td class="excel-262825-media-c9">66%</td><td class="excel-262825-media-c9">67%</td><td class="excel-262825-media-c9">68%</td><td class="excel-262825-media-c9">69%</td><td class="excel-262825-media-c9">70%</td><td class="excel-262825-media-c9">70%</td><td class="excel-262825-media-c9">71%</td><td class="excel-262825-media-c9">71%</td><td class="excel-262825-media-c9">70%</td><td class="excel-262825-media-c9">70%</td><td class="excel-262825-media-c9">71%</td><td class="excel-262825-media-c10">71%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">11%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">13%</td><td class="excel-262825-media-c9">12%</td><td class="excel-262825-media-c10">12%</td>
</tr>
<tr class="excel-262825-media-r1">
<td></td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c17">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Underlying Condition</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Yes</td><td class="excel-262825-media-c9">35%</td><td class="excel-262825-media-c9">35%</td><td class="excel-262825-media-c9">34%</td><td class="excel-262825-media-c9">34%</td><td class="excel-262825-media-c9">32%</td><td class="excel-262825-media-c9">31%</td><td class="excel-262825-media-c9">28%</td><td class="excel-262825-media-c9">31%</td><td class="excel-262825-media-c9">28%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c9">25%</td><td class="excel-262825-media-c10">25%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">No</td><td class="excel-262825-media-c9">44%</td><td class="excel-262825-media-c9">44%</td><td class="excel-262825-media-c9">46%</td><td class="excel-262825-media-c9">47%</td><td class="excel-262825-media-c9">49%</td><td class="excel-262825-media-c9">50%</td><td class="excel-262825-media-c9">54%</td><td class="excel-262825-media-c9">50%</td><td class="excel-262825-media-c9">54%</td><td class="excel-262825-media-c9">56%</td><td class="excel-262825-media-c9">57%</td><td class="excel-262825-media-c9">57%</td><td class="excel-262825-media-c9">57%</td><td class="excel-262825-media-c10">57%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Not Specified</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c10">18%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Median Household Income <b><sup>5</sup></b></td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&lt; 30k</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">30k - 40k </td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">27%</td><td class="excel-262825-media-c9">28%</td><td class="excel-262825-media-c10">28%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">40k - 50k</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">24%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c9">26%</td><td class="excel-262825-media-c10">26%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">50k - 60k</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c10">19%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">60k - 70k </td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">16%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c9">15%</td><td class="excel-262825-media-c10">15%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">70k - 80k</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">80k - 90k</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c9">2%</td><td class="excel-262825-media-c10">2%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">90k +</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c9">1%</td><td class="excel-262825-media-c10">1%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Unknown</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c5">&nbsp;</td><td class="excel-262825-media-c17">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c5">Urban / Rural <b><sup>6</sup></b></td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c9">&nbsp;</td><td class="excel-262825-media-c10">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Cities</td><td class="excel-262825-media-c9">37%</td><td class="excel-262825-media-c9">37%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">38%</td><td class="excel-262825-media-c9">40%</td><td class="excel-262825-media-c9">40%</td><td class="excel-262825-media-c9">41%</td><td class="excel-262825-media-c9">41%</td><td class="excel-262825-media-c9">42%</td><td class="excel-262825-media-c9">42%</td><td class="excel-262825-media-c9">41%</td><td class="excel-262825-media-c9">41%</td><td class="excel-262825-media-c9">42%</td><td class="excel-262825-media-c10">42%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Satellite urban towns</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">22%</td><td class="excel-262825-media-c10">22%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Independent urban towns</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">21%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">20%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">19%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">18%</td><td class="excel-262825-media-c9">17%</td><td class="excel-262825-media-c10">17%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Rural areas with high urban influence</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">10%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">8%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c9">9%</td><td class="excel-262825-media-c10">9%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Rural areas with moderate urban influence</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">7%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">6%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">5%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c10">4%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Highly rural / remote areas</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">4%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8">Unknown</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c9">3%</td><td class="excel-262825-media-c10">3%</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td><td class="excel-262825-media-c14">&nbsp;</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c16" colspan="15">* latest week is preliminary</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8" colspan="15"><sup>1 </sup>Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8" colspan="15"><sup>2 </sup>Data is defined by epidemiological date case which is the earliest of onset date, date of diagnosis, laboratory specimen collection date, laboratory received date, laboratory reported date, event creation/notification date</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8" colspan="15"><sup>3</sup> '..' Indicates a cell number &lt; 5 or a cell number &lt; 5 can be identified</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8" colspan="15"><sup>4 </sup>Week ending 06/03/2020 includes all cases up to that date, including previous weeks.</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8" colspan="15"><sup>5</sup> Median Household Income per Electoral Division from Geographical Profiles of Income in Ireland 2016, https://www.cso.ie/en/releasesandpublications/ep/p-gpii/geographicalprofilesofincomeinireland2016/</td>
</tr>
<tr class="excel-262825-media-r1">
<td class="excel-262825-media-c8" colspan="15"><sup>6</sup> Urban Rural definitions from Urban and Rural Life in Ireland 2019, https://www.cso.ie/en/releasesandpublications/ep/p-urli/urbanandrurallifeinireland2019/</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL7.xlsx">COVID-19 Deaths and Cases Series 18 - Table 7 (XLS 27KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262825_description").click(function(){
    $("#262825_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262825_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262828_description">
    <span id="#262828_openClose">Show Table</span>: Table 8 Profile of COVID-19 Patients with Underlying Conditions up to and including Friday December 11 2020
  </div>

<div style="clear: both"></div>

<div id="262828_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262828-insertexceltable">
<div id="table-262828-1-insertexceltable">
<table class="excel-262828-media-t1">
<colgroup>
<col width="257">
<col width="124">
<col width="12">
<col width="124">
<col width="124">
<col width="12">
<col width="121">
</colgroup>
<tbody>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c1" colspan="7">Table 8: Profile of COVID-19 Patients with Underlying Conditions up to and including Friday December 11 2020 <b><sup>1, 4</sup></b></td>
</tr>
<tr class="excel-262828-media-r2">
<td class="excel-262828-media-c2">&nbsp;</td><td class="excel-262828-media-c3">Total Confirmed Deaths <b><sup>2</sup></b></td><td class="excel-262828-media-c4">&nbsp;</td><td class="excel-262828-media-c4">Median Age of Deaths</td><td class="excel-262828-media-c4">Total Confirmed Cases <b><sup>3</sup></b></td><td class="excel-262828-media-c4">&nbsp;</td><td class="excel-262828-media-c4">Median Age of Cases</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c5">Total</td><td class="excel-262828-media-c6">1,739</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">83</td><td class="excel-262828-media-c6">19,653</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">54</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c5" colspan="7">Profile of the confirmed cases with underlying conditions follows:</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c5">Sex</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Female</td><td class="excel-262828-media-c6">821</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">85</td><td class="excel-262828-media-c6">10,701</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">52</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Male</td><td class="excel-262828-media-c6">918</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">81</td><td class="excel-262828-media-c6">8,950</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">55</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Not Specified</td><td class="excel-262828-media-c6">0</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">0</td><td class="excel-262828-media-c6">..</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">..</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c5">Age</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">0-24</td><td class="excel-262828-media-c6">..</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">..</td><td class="excel-262828-media-c6">2,219</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">21</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">25-44</td><td class="excel-262828-media-c6">15</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">38</td><td class="excel-262828-media-c6">4,654</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">35</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">45-64</td><td class="excel-262828-media-c6">106</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">58</td><td class="excel-262828-media-c6">6,255</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">54</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">65-79</td><td class="excel-262828-media-c6">509</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">75</td><td class="excel-262828-media-c6">3,341</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">73</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">80+</td><td class="excel-262828-media-c6">1,108</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">87</td><td class="excel-262828-media-c6">3,180</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">86</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Not Specified</td><td class="excel-262828-media-c6">..</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">..</td><td class="excel-262828-media-c6">..</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">..</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c5">Underlying Conditions</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">1 underlying condition</td><td class="excel-262828-media-c6">905</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">83</td><td class="excel-262828-media-c6">12,541</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">54</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">2 underlying  conditions</td><td class="excel-262828-media-c6">516</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">83</td><td class="excel-262828-media-c6">4,327</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">73</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">3 or More underlying conditions</td><td class="excel-262828-media-c6">318</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">84</td><td class="excel-262828-media-c6">2,785</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">78</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c5">Count of Underlying Conditions</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Chronic heart disease</td><td class="excel-262828-media-c6">771</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">84</td><td class="excel-262828-media-c6">3,865</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">71</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Hypertension</td><td class="excel-262828-media-c6">364</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">84</td><td class="excel-262828-media-c6">3,941</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">63</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Chronic kidney disease</td><td class="excel-262828-media-c6">221</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">82</td><td class="excel-262828-media-c6">921</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">73</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Chronic liver disease</td><td class="excel-262828-media-c6">35</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">74</td><td class="excel-262828-media-c6">293</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">64</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Chronic neurological disease</td><td class="excel-262828-media-c6">602</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">85</td><td class="excel-262828-media-c6">1,837</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">80</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Chronic respiratory disease</td><td class="excel-262828-media-c6">339</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">80</td><td class="excel-262828-media-c6">4,955</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">54</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Cancer/malignancy</td><td class="excel-262828-media-c6">295</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">78</td><td class="excel-262828-media-c6">1,323</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">70</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Diabetes</td><td class="excel-262828-media-c6">286</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">81</td><td class="excel-262828-media-c6">2,265</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">64</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">BMI &gt;= 40</td><td class="excel-262828-media-c6">36</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">63</td><td class="excel-262828-media-c6">341</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">52</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7">Other co-morbidity</td><td class="excel-262828-media-c6">1,065</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">83</td><td class="excel-262828-media-c6">8,135</td><td class="excel-262828-media-c6">&nbsp;</td><td class="excel-262828-media-c6">62</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c8">&nbsp;</td><td class="excel-262828-media-c9">&nbsp;</td><td class="excel-262828-media-c9">&nbsp;</td><td class="excel-262828-media-c9">&nbsp;</td><td class="excel-262828-media-c9">&nbsp;</td><td class="excel-262828-media-c9">&nbsp;</td><td class="excel-262828-media-c9">&nbsp;</td>
</tr>
<tr class="excel-262828-media-r2">
<td class="excel-262828-media-c10" colspan="7"><sup>1 </sup>Table includes data as of 16th December 2020 for events created on CIDR (Computerised Infectious Disease Reporting) up to midnight Friday 11th December 2020 and is subject to revision</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7" colspan="7"><sup>2 </sup>Data is defined by date of death</td>
</tr>
<tr class="excel-262828-media-r3">
<td class="excel-262828-media-c7" colspan="7"><sup>3 </sup>Data is defined by epidemiological date case which is the earliest of onset date, date of diagnosis, laboratory specimen collection date, laboratory received date, laboratory reported date, event creation/notification date</td>
</tr>
<tr class="excel-262828-media-r1">
<td class="excel-262828-media-c7" colspan="7"><sup>4</sup> '..' Indicates a cell number &lt; 5 or a cell number &lt; 5 can be identified</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBL8.xlsx">COVID-19 Deaths and Cases Series 18 - Table 8 (XLS 13KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262828_description").click(function(){
    $("#262828_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262828_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script><div style="clear: both;"></div>
<div class="pubOpenCloseTable">
  <div class="pubOpenCloseTableTitle" id="262836_description">
    <span id="#262836_openClose">Show Table</span>: Table 9: Weekly Referrals for Community COVID-19 Tests, Tests Completed and Positivity Rate
  </div>

<div style="clear: both"></div>

<div id="262836_text" style="display: none" class="indicatorHeadlineTable">
<div id="excel-262836-insertexceltable">
<div id="table-262836-1-insertexceltable">
<table class="excel-262836-media-t1">
<colgroup>
<col width="228">
<col width="55">
<col width="55">
<col width="55">
<col width="55">
<col width="55">
<col width="55">
<col width="55">
<col width="55">
<col width="55">
<col width="55">
</colgroup>
<tbody>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c1" colspan="11">Table 9: Weekly Referrals for Community Covid-19 Tests, Tests Completed and Positivity Rate <b><sup>1,2</sup></b></td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c1">&nbsp;</td><td class="excel-262836-media-c2" colspan="10">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c3">&nbsp;</td><td class="excel-262836-media-c4">09/10</td><td class="excel-262836-media-c4">16/10</td><td class="excel-262836-media-c4">23/10</td><td class="excel-262836-media-c4">30/10</td><td class="excel-262836-media-c4">06/11</td><td class="excel-262836-media-c4">13/11</td><td class="excel-262836-media-c4">20/11</td><td class="excel-262836-media-c4">27/11</td><td class="excel-262836-media-c4">04/12</td><td class="excel-262836-media-c4">11/12</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c5">Weekly Referrals for Community Covid-19 test by Age category </td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td><td class="excel-262836-media-c6">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">0 - 14 years</td><td class="excel-262836-media-c8">13,011</td><td class="excel-262836-media-c8">15,587</td><td class="excel-262836-media-c8">18,634</td><td class="excel-262836-media-c8">10,988</td><td class="excel-262836-media-c8">7,880</td><td class="excel-262836-media-c8">7,773</td><td class="excel-262836-media-c8">8,629</td><td class="excel-262836-media-c8">8,347</td><td class="excel-262836-media-c8">9,112</td><td class="excel-262836-media-c8">9,124</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">15 - 24 years</td><td class="excel-262836-media-c8">16,137</td><td class="excel-262836-media-c8">18,881</td><td class="excel-262836-media-c8">17,943</td><td class="excel-262836-media-c8">11,381</td><td class="excel-262836-media-c8">8,918</td><td class="excel-262836-media-c8">8,602</td><td class="excel-262836-media-c8">8,382</td><td class="excel-262836-media-c8">8,023</td><td class="excel-262836-media-c8">7,944</td><td class="excel-262836-media-c8">9,541</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">25 - 44 years</td><td class="excel-262836-media-c8">29,358</td><td class="excel-262836-media-c8">32,332</td><td class="excel-262836-media-c8">33,887</td><td class="excel-262836-media-c8">26,872</td><td class="excel-262836-media-c8">24,527</td><td class="excel-262836-media-c8">23,607</td><td class="excel-262836-media-c8">23,097</td><td class="excel-262836-media-c8">20,376</td><td class="excel-262836-media-c8">24,541</td><td class="excel-262836-media-c8">23,504</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">45-64 years</td><td class="excel-262836-media-c8">21,952</td><td class="excel-262836-media-c8">24,875</td><td class="excel-262836-media-c8">25,904</td><td class="excel-262836-media-c8">21,365</td><td class="excel-262836-media-c8">18,816</td><td class="excel-262836-media-c8">18,212</td><td class="excel-262836-media-c8">18,198</td><td class="excel-262836-media-c8">16,025</td><td class="excel-262836-media-c8">19,324</td><td class="excel-262836-media-c8">17,826</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">65-79 years</td><td class="excel-262836-media-c8">3,761</td><td class="excel-262836-media-c8">4,263</td><td class="excel-262836-media-c8">4,648</td><td class="excel-262836-media-c8">3,434</td><td class="excel-262836-media-c8">3,000</td><td class="excel-262836-media-c8">2,652</td><td class="excel-262836-media-c8">2,678</td><td class="excel-262836-media-c8">2,323</td><td class="excel-262836-media-c8">2,760</td><td class="excel-262836-media-c8">2,720</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">80 years and over</td><td class="excel-262836-media-c8">1,110</td><td class="excel-262836-media-c8">1,871</td><td class="excel-262836-media-c8">1,985</td><td class="excel-262836-media-c8">1,756</td><td class="excel-262836-media-c8">1,517</td><td class="excel-262836-media-c8">1,153</td><td class="excel-262836-media-c8">1,199</td><td class="excel-262836-media-c8">1,352</td><td class="excel-262836-media-c8">1,409</td><td class="excel-262836-media-c8">1,346</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Total</td><td class="excel-262836-media-c8">85,329</td><td class="excel-262836-media-c8">97,809</td><td class="excel-262836-media-c8">103,001</td><td class="excel-262836-media-c8">75,796</td><td class="excel-262836-media-c8">64,658</td><td class="excel-262836-media-c8">61,999</td><td class="excel-262836-media-c8">62,183</td><td class="excel-262836-media-c8">56,446</td><td class="excel-262836-media-c8">65,090</td><td class="excel-262836-media-c8">64,061</td>
</tr>
<tr class="excel-262836-media-r1">
<td></td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c1">Weekly Referrals for Community Covid-19 test by Source</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">GPs</td><td class="excel-262836-media-c8">56,410</td><td class="excel-262836-media-c8">63,416</td><td class="excel-262836-media-c8">68,214</td><td class="excel-262836-media-c8">43,432</td><td class="excel-262836-media-c8">34,115</td><td class="excel-262836-media-c8">29,599</td><td class="excel-262836-media-c8">30,249</td><td class="excel-262836-media-c8">27,397</td><td class="excel-262836-media-c8">28,213</td><td class="excel-262836-media-c8">29,684</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Other Source <sup>3</sup></td><td class="excel-262836-media-c8">28,919</td><td class="excel-262836-media-c8">34,393</td><td class="excel-262836-media-c8">34,787</td><td class="excel-262836-media-c8">32,364</td><td class="excel-262836-media-c8">30,543</td><td class="excel-262836-media-c8">32,400</td><td class="excel-262836-media-c8">31,934</td><td class="excel-262836-media-c8">29,049</td><td class="excel-262836-media-c8">36,877</td><td class="excel-262836-media-c8">34,377</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">All sources</td><td class="excel-262836-media-c8">85,329</td><td class="excel-262836-media-c8">97,809</td><td class="excel-262836-media-c8">103,001</td><td class="excel-262836-media-c8">75,796</td><td class="excel-262836-media-c8">64,658</td><td class="excel-262836-media-c8">61,999</td><td class="excel-262836-media-c8">62,183</td><td class="excel-262836-media-c8">56,446</td><td class="excel-262836-media-c8">65,090</td><td class="excel-262836-media-c8">64,061</td>
</tr>
<tr class="excel-262836-media-r1">
<td></td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c1">Weekly Referrals for Community Covid-19 test by Speciality Type</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Contact testing/ At risk groups</td><td class="excel-262836-media-c8">21,678</td><td class="excel-262836-media-c8">25,187</td><td class="excel-262836-media-c8">32,196</td><td class="excel-262836-media-c8">22,467</td><td class="excel-262836-media-c8">15,592</td><td class="excel-262836-media-c8">12,116</td><td class="excel-262836-media-c8">11,439</td><td class="excel-262836-media-c8">9,663</td><td class="excel-262836-media-c8">8,997</td><td class="excel-262836-media-c8">9,392</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">General COVID-19 testing</td><td class="excel-262836-media-c8">36,520</td><td class="excel-262836-media-c8">41,162</td><td class="excel-262836-media-c8">37,407</td><td class="excel-262836-media-c8">24,170</td><td class="excel-262836-media-c8">19,483</td><td class="excel-262836-media-c8">21,474</td><td class="excel-262836-media-c8">20,723</td><td class="excel-262836-media-c8">20,763</td><td class="excel-262836-media-c8">23,227</td><td class="excel-262836-media-c8">25,449</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Healthcare/ Essential worker testing</td><td class="excel-262836-media-c8">21,212</td><td class="excel-262836-media-c8">22,336</td><td class="excel-262836-media-c8">23,928</td><td class="excel-262836-media-c8">21,731</td><td class="excel-262836-media-c8">24,063</td><td class="excel-262836-media-c8">23,069</td><td class="excel-262836-media-c8">24,485</td><td class="excel-262836-media-c8">21,073</td><td class="excel-262836-media-c8">27,574</td><td class="excel-262836-media-c8">24,692</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Residential settings/ Institutions/ Schools</td><td class="excel-262836-media-c8">5,919</td><td class="excel-262836-media-c8">9,124</td><td class="excel-262836-media-c8">9,470</td><td class="excel-262836-media-c8">7,428</td><td class="excel-262836-media-c8">5,520</td><td class="excel-262836-media-c8">5,340</td><td class="excel-262836-media-c8">5,536</td><td class="excel-262836-media-c8">4,947</td><td class="excel-262836-media-c8">5,292</td><td class="excel-262836-media-c8">4,528</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Total</td><td class="excel-262836-media-c8">85,329</td><td class="excel-262836-media-c8">97,809</td><td class="excel-262836-media-c8">103,001</td><td class="excel-262836-media-c8">75,796</td><td class="excel-262836-media-c8">64,658</td><td class="excel-262836-media-c8">61,999</td><td class="excel-262836-media-c8">62,183</td><td class="excel-262836-media-c8">56,446</td><td class="excel-262836-media-c8">65,090</td><td class="excel-262836-media-c8">64,061</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c1">Weekly Tests Completed and Positivity Rate</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td><td class="excel-262836-media-c8">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Weekly Tests Completed</td><td class="excel-262836-media-c8">95,672</td><td class="excel-262836-media-c8">100,183</td><td class="excel-262836-media-c8">116,606</td><td class="excel-262836-media-c8">99,657</td><td class="excel-262836-media-c8">83,178</td><td class="excel-262836-media-c8">77,518</td><td class="excel-262836-media-c8">78,092</td><td class="excel-262836-media-c8">75,601</td><td class="excel-262836-media-c8">75,462</td><td class="excel-262836-media-c8">78,416</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7">Weekly Positivity Rate</td><td class="excel-262836-media-c8">4.50</td><td class="excel-262836-media-c8">7.00</td><td class="excel-262836-media-c8">6.60</td><td class="excel-262836-media-c8">5.30</td><td class="excel-262836-media-c8">4.30</td><td class="excel-262836-media-c8">3.50</td><td class="excel-262836-media-c8">3.50</td><td class="excel-262836-media-c8">2.60</td><td class="excel-262836-media-c8">2.60</td><td class="excel-262836-media-c8">2.50</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td><td class="excel-262836-media-c9">&nbsp;</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c10" colspan="11"><sup>1 </sup>Table includes data as of 16th December 2020 for Referrals for Community Covid-19 test from SwiftQueue system and is subject to revision</td>
</tr>
<tr class="excel-262836-media-r1">
<td class="excel-262836-media-c7" colspan="11"><sup>2</sup> Table includes referrals where valid reservation for test is made</td>
</tr>
<tr class="excel-262836-media-r2">
<td class="excel-262836-media-c11" colspan="11"><sup>3</sup> Other Source includes ;  Contact Tracing Team
                                          Public Health GP
                                          Public Health Nurse
                                          Residential Setting</td>
</tr>
</tbody>
</table>
</div>
</div>

   <div class="OpenInExcel">Open in Excel: <a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL9.xlsx">COVID-19 Deaths and Cases Series 18 - Table 9 (XLS 13KB)</a> </div>
  
  
  
  





  
  
  
  
  
  
  
  
  
</div>
  </div>
<div style="clear: both;"></div>
<br>

<script>
  
  //$(document).ready(function(){
  
  
$("#262836_description").click(function(){
    $("#262836_text").slideToggle(1000);  
  
  
  //var spanValue = $("#262836_openClose").val();
  //alert(spanValue);
  
  
  
  
   
  });
  
  //});
  
</script>
<a name="d.en.262839"></a>
<p>Full statistical tables can be downloaded here:</p>
<p>Table 2:&nbsp;<a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBL2-2A.xlsx">COVID-19 Deaths and Cases Series 18 - Table 2-2A (XLS 30KB)</a> </p>
<p>Table 3:&nbsp;<a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDC18TBL3-1.xlsx">COVID-19 Deaths and Cases Series 18 - Table 3-3A (XLS 21KB)</a> </p>
<p>Table 4:&nbsp;<a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBL4-4A.xlsx">COVID-19 Deaths and Cases Series 18 - Table 4-4A (XLS 38KB)</a> </p>
<p>Table 6:&nbsp;<a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBL6-6A.xlsx">COVID-19 Deaths and Cases Series 18 - Table 6-6A (XLS 24KB)</a> </p>
<p>Table 7:&nbsp;<a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBL7-7A.xlsx">COVID-19 Deaths and Cases Series 18 - Table 7-7A (XLS 50KB)</a> </p>
<p>Table&nbsp;9:&nbsp;<a href="https://www.cso.ie/en/media/csoie/releasespublications/documents/br/covid-19deathsandcases/covid-19deathsandcases11thdecember/P-CDCBULLETIN18TBL9.xlsx">COVID-19 Deaths and Cases Series 18 - Table 9 (XLS 17KB)</a> </p>
<p>&nbsp;</p>
</div> <!--closes br_lhs column -->
<div class="br_rhs"> <!-- open sidebar column -->

<div id="RHStoggle">
<div class="bulletin-release-rhs">

  <div class="br-rhs-column-related">

      <div class="br-column-header">
          <h4>Related Content</h4>
      </div>

      <div id="topRelatedContent">
        <ul>
          
          
          
          
        </ul>
      </div>


      <div id="relatedDataTables">
        <h5>StatBank  tables</h5>
        <ul>
          

          

          

          

          

          
        </ul>

      </div> <!-- /relatedDataTables -->


      <div id="relatedReleases">
        <h5>Related releases</h5>  
        <ul>
          
          
        </ul>
      </div> <!-- /relatedReleases -->

     <div id="intlReference">
        <h5>International reference</h5>
        <ul>
                

                
        </ul>
      </div> <!-- /intlReference -->
      <div id="otherRelatedContent">
        <h5>See also</h5>   
        <ul>
          
            

          <li><a href="https://www.hpsc.ie/a-z/respiratory/coronavirus/novelcoronavirus/casesinireland/epidemiologyofcovid-19inireland/" target="_blank">Epidemiology of COVID-19 in Ireland - daily reports from Health Protection Surveillance Centre
</a></li>       
        </ul>
      </div> <!-- /otherRelatedContent -->
  
  </div> <!-- /related sidebar -->

  <div class="br-rhs-column-furtherinfo">

      <div class="br-column-header">
          <h4>Further Information</h4>
      </div>

      <h5>Contact</h5>
        <dl>
        <dt>E-mail: <a href="mailto:">Steven.Conroy@cso.ie</a></dt>

          <dt></dt>
          <dd></dd>

               

               
      </dl>

    <div class="br-column-metaData">
    	
    </div>

  </div> <!-- /further info -->

</div>
</div>


         
</div> <!-- closes sidebar column
</div> <!-- closes br_container wrapper -->
        
        
<a name="d.en.262829"></a>
<!--start Code only (admin)-->
<style>
.ERtable table tr:hover, .indicatorHeadlineTable table tr:hover
{

  /*background: #EDEDED;*/
  background: #CCCCCC;
}

/* styles for pdfLinks - required? */

div.pdfLinks {
    background: #e6edf2;
    border: 1px solid #adbecc;
    border-radius: 0;
}

/* end pdf styles */

/* Bulletin Release structure styles */
.br_container {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}
.br_lhs {
    width:65%;
}
.br_rhs {
    width:25%;
}
.bulletin-banner h3 {
    font-weight: 300;
}

.bulletin-banner h4 {
    font: 14px "Roboto Slab", Times, serif;
    font-weight: 700;
    color: #283f73;
    margin-top: 0;
}
.pubOpenCloseTable {
border: 2px solid #399A9A;
border-radius: 5px;
color: #545353;
width: 800px;
padding: 10px;
margin-top: 10px;
}
@media only screen and (max-width: 1000px), only screen and (max-device-width: 1000px)
{
    .br_container {
        display: block;
    }
    .br_lhs, .br_rhs {
        width: 100%;
    }
}


/* RHS styles */
.bulletin-release-rhs
{
    background: none;
    border: none;
    padding: 0 0 8px;
    min-height: 70px;
    margin: 0 10px 10px;
    font-size: 13px;
}

@media only screen and (max-width: 1000px), only screen and (max-device-width: 1000px)
{
    .bulletin-release-rhs
    {
        background: none;
        border: none;
    }
    
}

/* set container styles for divs which are children of the rhs */
.bulletin-release-rhs > div {
    background: #e6edf2;
    padding:20px;
    border: none;
    font-family: 'Roboto Sans', Arial, Helvetica, sans-serif;
    line-height: 1.4;
    border-radius: 0;
    margin-bottom: 2rem;
}
/* style the headers with overrides */
.bulletin-release-rhs h5 {
  	padding: 0;
  	margin: 0 0 0.3rem;
    font-size: 15px;
    font-weight: bold;
    text-transform: none;
    letter-spacing: normal;
}
@media only screen and (max-width: 1000px), only screen and (max-device-width: 1000px)
{
    .bulletin-release-rhs h5
    {
        background: none;
        border: none;
        color: #07101a;
        padding: 0;
    }
    
}

.br-column-header {
    background-color: #283f73;
    color: #fff;
    margin: -20px -20px 10px;
    padding: 10px 20px;
}
.br-column-header h4 {
    color:#fff;
    margin:0;
    font-family: 'Roboto Slab', Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    font-size: 20px;
    font-weight: 300;
}
.br-rhs-column-related .br-column-header {
    background-color: #283f73;
}
.br-rhs-column-furtherinfo.br-column-header {
    background-color: #286b73;
}

/* style the lists of related content */
.bulletin-release-rhs > div ul,
.bulletin-release-rhs > div dl {
	margin: 0 0 10px;
  	padding: 0;
}

.bulletin-release-rhs > div ul li {
	margin: 0 0 0.3rem;
  	padding: 0;
  	list-style: none;
}

.bulletin-release-rhs > div ul li.rhs-infographic {
    max-width: 300px;
}

/* definition list used for contact details */
.bulletin-release-rhs > div dl dt {
	margin: 0 0 0.3rem 0;
}

.bulletin-release-rhs > div dl dt+dt {
	margin: 0;
}

.bulletin-release-rhs > div dl dt+dd {
	margin: 0 0 0.3rem 0.3rem;
}

/* ISSN, etc */
.bulletin-release-rhs .br-column-metaData {
	margin: 0.5rem 0 0 0;
    padding: 0.5rem 0 0;
  	border-top: 1px solid #adbecc;
}


/* Header Block styles */

.br_title h1 {
    background-color: #008faa;
    color: #fff;
    font-size: 24px;
    font-weight: 400;
    padding: 15px 20px;
    margin: 10px 0 0;
}

/* override ER styles for LHS */
.br_headline {
  margin: 30px 0 15px;
}

  .br_headline h2 {
    color: #024972;
    font-size: 20px;
    border-bottom-style: solid;
    border-bottom-width: 1px;
    border-bottom-color: #CCCDCD;
    padding: 5px 0px 2px 0px;
    margin: 0px 15px 0px 0px;
    font-weight: 400;
        
  }

.br-keypoints {
    margin-bottom: 2rem;
}
  
.br_instance h3 {
    color: #024972;
    font-size: 20px;
    font-weight: 400;
  	background-color: #cad6e0;
      padding: 8px 20px;
      margin: 0;
}

.br_date {
    font-style: italic;
    font-size: 14px;
    text-align: right;
    background-color: #e6edf2;
    margin: 0;
    padding: 5px 20px;
}


/* styles for series banner */

.bulletin-banner {
    background-color: #e6edf2;
    color: #283f73;
    height: 100px;
    padding: 20px 140px 20px 20px;
    margin: 2rem 0 1rem;
    position: relative;
    overflow: hidden;
}

.bulletin-banner img {
    position:absolute;
    top:0;
    right: 0;
    margin-left: 20px;
    width: 140px;
    height: 140px;

}

.bulletin-banner h2 {
	font: 32px "Roboto Slab", Times, serif;
	font-weight: 300;
	color: #283f73;
    margin-bottom: 0;
}


@media only screen and (max-width: 1000px), only screen and (max-device-width: 1000px)
{
	.bulletin-banner {
        max-width: 100%;
        max-height: auto;
      	padding: 10px;
      	box-sizing: border-box;
      	margin: 1rem 0;
    }
  
  	.bulletin-banner img {
    	display:none;
    }
  	
  	.bulletin-banner h2 {
    	font-size: 24px;
    }
  	.bulletin-banner h4 {
    	font-size: 18px;
    }
}
</style>
<!--end Code only (admin)--><a name="d.en.262838"></a>
<!--start Code only (admin)-->
<style>
.pubOpenCloseTable {
    border: 2px solid #399A9A;
    border-radius: 5px;
    color: #545353;
    width: 800px;
    padding: 10px;
    margin-top: 10px;
}
</style>
<!--end Code only (admin)--><a name="d.en.262833"></a>
<!--start Code only (admin)-->
<style>
.copy ul li, .copy ol li {font-size: 15px;
line-height: 22px;}
</style>
<!--end Code only (admin)-->	</div><!--/copy-->
				</div>
			</div><!--/row-->
		</div><!--/content-->

<!-- start footer -->
<!-- navigation object : Footer code --><a name="d.en.86134"></a>
<!--start Code only (admin)-->
<!-- ********** FOOTER ********** -->
<div class="footer container">
   <div class="row">
      <div class="col span4 contactDetails">
         <h2>Contact: </h2>
         <p><b>Central Statistics Office</b><br>
            Skehard Road, Cork T12 X00E, Ireland
         </p>
         <div class="divFooterTable">
            <div class="divFooterTableBody">
               <div class="divFooterTableRow">
                  <div class="divFooterTableCell"><b>Tel:</b></div>
                  <div class="divFooterTableCell"><a href="tel:+353214535000">(+353) 21 453 5000</a></div>
               </div>
               
               <div class="divFooterTableRow">
                  <div class="divFooterTableCell"><b>E-Mail:</b></div>
                  <div class="divFooterTableCell"><a href="mailto:information@cso.ie">information@cso.ie</a></div>
               </div>
            </div>
         </div>
         <!-- divFooterTable.com -->
      </div>
      <!--/col-->
      <div class="col span4 footerLinks">
         <h2>Links: </h2>
<ul class="footerNavList">
			<li><a href="https://www.cso.ie/en/aboutus/whoweare/copyrightpolicy/">© 2020</a></li>
			<li><a href="https://www.cso.ie/en/freedomofinformation/">Freedom of Information</a></li>
			<li><a href="https://www.cso.ie/en/silc/sitemap/">Sitemap</a></li>
			<li><a href="https://www.cso.ie/en/accessibility/accessibilitystatement/">Accessibility</a></li>
                        <li><a href="https://www.cso.ie/en/aboutus/lgdp/dataprotectionprivacytransparency/">Data Protection &amp; Transparency</a></li>
			<li><a href="https://www.cso.ie/en/aboutus/lgdp/dataprotectionprivacytransparency/websiteprivacystatement/">Privacy Statement</a></li>
			<li><a href="https://www.cso.ie/process_feedback/feedback.aspx">Feedback</a></li>
                        <!-- navigation object : Path: Contact us -->
                        <li><a href="https://www.cso.ie/en/aboutus/contactus/">Contact us</a></li>
			</ul>
      </div>
      <!--/col-->
      <div class="col span4 footerSocial">
         <h2>Follow: </h2>
         <ul class="socialNavList inverted">
            <li class="youtube">
               <a href="https://www.youtube.com/user/CSOIrelandMedia" title="Follow us on YouTube" target="_blank"><i class="fa fa-youtube-play fa-2x"></i></a>
            </li>
            <li class="twitter">
               <a href="https://twitter.com/csoIreland" title="Follow us on Twitter" target="_blank"><i class="fa fa-twitter fa-2x"></i></a>
            </li>
            <li class="facebook">
               <a href="https://www.facebook.com/CSOIreland" title="Like us on Facebook"><i class="fa fa-facebook-official fa-2x"></i></a>
            </li>
            <li class="instagram">
               <a href="https://www.instagram.com/csoireland/" title="Follow us on Instagram"><i class="fa fa-instagram fa-2x"></i></a>
            </li>
            <li class="rss">
               <a href="https://www.cso.ie/rss/en/latestreleasesandpublications/index.xml" title="Subscribe to RSS feeds"><i class="fa fa-rss fa-2x"></i></a>
            </li>
         </ul>
      </div>
      <!--/col-->
   </div>
   <!--/row-->
</div>
<!--/footer-->



<!--end Code only (admin)-->	
<!-- end footer --></div><div class="highslide-container" style="padding: 0px; border: none; margin: 0px; position: absolute; left: 0px; top: 0px; width: 100%; z-index: 1001; direction: ltr;"><a class="highslide-loading" title="Click to cancel" href="javascript:;" style="position: absolute; top: -9999px; opacity: 0.75; z-index: 1;">Loading...</a><div style="display: none;"></div><div class="highslide-viewport highslide-viewport-size" style="padding: 0px; border: none; margin: 0px; visibility: hidden;"></div><table cellspacing="0" style="padding: 0px; border: none; margin: 0px; visibility: hidden; position: absolute; border-collapse: collapse; width: 0px;"><tbody style="padding: 0px; border: none; margin: 0px;"><tr style="padding: 0px; border: none; margin: 0px; height: auto;"><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) 0px 0px; height: 20px; width: 20px;"></td><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) 0px -40px; height: 20px; width: 20px;"></td><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) -20px 0px; height: 20px; width: 20px;"></td></tr><tr style="padding: 0px; border: none; margin: 0px; height: auto;"><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) 0px -80px; height: 20px; width: 20px;"></td><td class="rounded-white highslide-outline" style="padding: 0px; border: none; margin: 0px; position: relative;"></td><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) -20px -80px; height: 20px; width: 20px;"></td></tr><tr style="padding: 0px; border: none; margin: 0px; height: auto;"><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) 0px -20px; height: 20px; width: 20px;"></td><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) 0px -60px; height: 20px; width: 20px;"></td><td style="padding: 0px; border: none; margin: 0px; line-height: 0; font-size: 0px; background: url(&quot;https://cdn.cso.ie/static/img/highslide/outlines/rounded-white.png&quot;) -20px -20px; height: 20px; width: 20px;"></td></tr></tbody></table></div></body></html>