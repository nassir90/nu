<!DOCTYPE html>

<head>
	<title>The maybevirus nondemic</title>
	<link rel="stylesheet" href="../simple.css">
</head>

<body>
	<h1>The maybevirus nondemic</h1>
	
	<p>Last night I had a crazy dream. There was a new virus in town: virulent and contagious. It could kill anybody, be they young, old, fat or healthy - the virus was uncompromising. I had to judge the quality of our governments by how much they limited the capabilities of their citezens, all for the good of public health. The only thing capable of stoping the pandemic was a new vaccine that was to be developed and administered on the population by benevolent pharmacutical companies, in the meantime, masks and isolation were absolutely necessary. Except it wasn't just last night, and it wasn't a dream per se: this is the form of reality seeping into most forms of media, new and old, like histeria among patients sharing a spiked IV tube [0]. Is it true? Can the times I'm living through be described as a "coronavirus pandemic" or is it more of a "maybevirus nondemic". It's my belief, based on observation and experimentation that I'm living through the latter.</p>
	
	<h4>The locality argument</h4>
	<p>The population has been dreaming about a pandemic for almost ten months now, however, in that timeframe, the only evidence I've seen have been the restrictions introduced because there's supposedly a pandemic. none of my direct associates have contracted and fallen ill with the 'novel' coronavirus. Of course, I know people who know others who have 'tested positive' for the virus, however, that's hearsay: this is the <em>locality</em> argument. Disragarding for now the (negligible) mortality rate, if the 'novel' coronavirus causes a disease lethal and contagious enought to be considered, why haven't the people I interact with daily contracted it and fallen ill? The 'novel' coronavirus can't be relevant in my locality, because nobody I know or interact with on a regular basis has contracted it and fallen ill.</p>
	
	<p>Somebody like me, especially, would have been hard hit by a pandemic, if there were such a thing. I've exposed my self to situations where contagious disease should have struck me down, alas, that didn't happen. During the summer, when there was rumours of a 'second wave', I played basketball at an open court, about three times per week, with no mask. You could bet on the fact that each time you went there'd be a different cohort of people to play with. Now, did I contract this 'novel' coronavirus and die despite being a young and healthy individual? Of course not. If this anecdote isn't good enough (becaue anecdotes are all that can support or deny the locality argument), I'll give you another one. Between september and early december, I once again played basketball almost every day, inisde this time, though with the same cohort of people each time. That said, they'd have their own associates, who had their own, thus, the contagious 'novel' coronavirus should have had a noticable influence. But did I contract the virus and die? You know the answer, no.</p>
	
	<p>Now, you might claim that, based on your experince, the pandemic is undeniable. And that may be true. I can't deny your reality. However, you must live in a place so distant that nothing there could influence my daily life. It's aberational to be consumed with the malfortunes of others, in my opinion. As you read this page, people are dying in yemen, children are starving in sudan and farmers are commiting suicide in India. Their plights and yours deserve my pity, but other than that I don't care. Your locality is not mine.</p>
	
	<h4>The statistical argument</h4>
	<p>On top of the locality argument, which I feel is almost bulletproof, there's the statistical argument. If this 'novel' coronavirus causes a disease so deadly, such that not even the young are spared, why does it only seem to be lethal for elderly people with preexisting conditions [1]. The disease caused by the 'novel' corona virus, if any [2], can't be lethal for the general population as it only kills elderly people with preexisting conditions.</p>
	
	<p>It's true that illness functions as a low pass filter, culling the frail and the old and keeping the young, and that what I really should be how much the 'novel' coronavirus impacts the young compared to other diseases. This would be true, and is something I am yet to do. I'm waiting for the sample of people under 64 who 'died of coronavirus' with no underlying conditions becomes large enough to study, if that ever happens, because at the moment, the number is a shocking ten [1].</p>
	
	<p>Furthermore, if you are reading this to be convinced of something, and not write off the ideas discussed here immediately, you'll have to trust that I'm bringing up the <em>cso.ie</em> figures not because I only look for what I want to see, but because what I'm presenting is the only thing to be seen. In any argument going against what you have been led to believe, both the veracity of the presenter and the veracity of the content have to be considered, that said, the veracity of the content is primary [3].</p>
	
	<h4>The consparitorial arguments</h4>
	<p>These two arguments, in my case, are rock solid. My locality speaks for itself, and the statistics also support the view that I'm living through a maybevirus nondemic. However, on top of these two arguments, there may be a conspiracy at hand. You may chock the whole thing down to negligence. That's fine. Either way, the conspiracy and negligence differ only in the intent of the perpetrator. The effects are the same.</p>
	
	<h5>The role of the media</h5>
	<p>The role of the media in this scamdemic is evidence of a conspiracy. Almost everywhere you go, in real life or online, you'll hear and see mantras done to infinity, that can only described as propaganda. You probably know them as well as the Lord's Prayer: "Protect each other", "Masking for a friend", "Prevent the spread", "We're in this together", "COVID19 is an emerging, evolving situation". If there was really a significant pandemic in my locality, nobody would need to stick the yellow signs up everywhere remunding us of that, or rather, there would be more evidence for a pandemic than pandemic propaganda.</p>
	
	<p>Niel postman had it right when he claimed that when the media changes from text based propositional exposition to slogans and mantras, the reader is becoming a consumer, and facts are becoming fiction.</p>
	
	<h5>The restructuring of reality</h5>
	<p>The apparent restructuring or reality also suggests consparicy. A few weeks ago, I listened to an essay on the woefully indadequate public health system that exists in Ireland - that essay was written more that five years ago. However, in the scamdemic era, this fact is not being presented as something that occured due to government laziness or apathy, but as a simple fact of life. The hospitals aren't overloaded because our public health system is faulty, but because of the 'novel' coronavirus. There's probably multiple cases of ideas that have been reintroduced to the populous as being caused by the coronavirus, when anybody who looks deeper will discover that viri can't pass legislation.</p>
	
	<h5>The uselessness of 'lockdowns'</h5>
	<p>Lockdowns are useless. This is a pretty easy thesis to defend. First of all, what is a lockdown, in the current parlance? A lockdown is where the whole population limits their contacts as to avoid the spread of a contagious disease. Now, here's the rub. If this is done to protect the old and the frail, why can't they just lockdown? If the purpose of lockdown is to prevent coming into contact with somebody who is likely to die from a contagious disease, only they should have to quarantine - the nature of a lockdown necessitates that the actions of others have no bearing on you, and if the people locking you down tell you that the actions of others can impact you, then the lockdown is a scam.</p>
	
	<p>That said, the mythos being established by media mantras, it doens't need to be questioned. It's posssible (and pitiable) that there exists somebody willingly shutting down their business for the third time and believing that it's all for the greater good. There's also the discusting ads talking about a 'mental health pandemic', because even critique of the lockdown has to be dashed with affirmations of the hoax.</p>
	
	<p>So what's the purpose of the lockdown. It may be to reorganise wealth and control. If there is a conspiracy, the easiest way to execute it is to have all businesses under your thumb. How do you do this? You cut off their source of income on and off for ten months, and then abolish their independence of income by giving them stipend.</p>
	
	<h5>Contact tracing and vaccines</h5>
	<p>The phrase 'social credit system' immediately conjures up images of China. However, here in Ireland, we're actually moving closer to our own 'social credit system'. It would be naïve to say that I have no form of digital identity: I have a reddit, instagram and gmail account. That said, its aberational to say that just because it's bad, it should be allowed to get worse. I don't think contact tracing will ever go away, and I think that biometrics will be introduced alongside the vaccine under the pretence of making sure those pesky 'anti-masking anti-vaxxers' don't kill the conformists.</p>
	
	<h5>Germ theory</h5>
	<p>I don't actually deny germ theory, but it's interesting to see how all of the elements of germ theory have been frankensteined to create the scamdemic. We have vaccines that aren't vaccines, and modes of spread that go unproven. Are the symptoms of the 'novel' coronavirus actually caused by something else, given the low ratio of symptomatic to asymptomatic individuals with 'novel coronavirus DNA'[4] combined with the broadness of the symptoms associated with the disease? I don't know.</p>
	
	<hr>
	
	<p>[0] Or falsehood among outlets owned by the same entity...</p>
	<p>[1] see cso.ie</p>
	<p>[2] Not even the mass media will claim that the 'novel' coronavirus will 'cause' a disease in most people. The ratio of symptom showing to symptom lacking individuals is so low that the 'asymptomatic superspreader' had to be created. In this wicked burlesque of germ theory, healthy people are made sick, and clean hands made dirty.</p>
	<p>[3] Read Niel Postman's essay 'amusing ourselves to death'</p>
	<p>[4] People who's biological material can be amplified in a polymerase chain reaction such that either DNA strands the same length as those 'isolated' from sars-cov-2 are observed, or adiquate flourescence can be observed if RT-rtPCR is being employed. The PCR, detatched from the scamdemic is actually pretty cool biology, and you'll learn the fundamentals if you study it.</p>
	
	<hr>
	
	<a href="index.html">Back to index</a>
</body>
