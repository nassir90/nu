<!DOCTYPE html>
<head>
	<link rel="stylesheet" href="../style.css">
	<title>Out There</title>
</head>
<body>
	<header><h1>Articles</h1></header>
	
	<section>
	
	<h2>Consparicy theories</h2>
	<ul>
		<li><a href="maybe.html">The maybevirus nondemic</a></li>
	</ul>
	
	</section>
	<footer><a href="../index.html">Back to mediocrity</a></footer>
</body>
