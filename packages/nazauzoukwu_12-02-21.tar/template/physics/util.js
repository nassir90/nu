function vec2 (x,y) {
	return { x: x, y: y };
}
